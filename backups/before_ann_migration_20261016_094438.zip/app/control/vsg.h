#ifndef VSG_H_
#define VSG_H_
#include "app/inverter_settings.h"

typedef struct
{
    float omega0, omega_m, omega_sync, omega_m_pu;
    float v_nom, v_delta_pu;
    uint16_t power_loop_cnt;
} VSG_DEF;
extern volatile VSG_DEF VSG_CTRL;
void VSG_Init(volatile VSG_DEF *v);
void VSG_Reset(volatile VSG_DEF *v);
void VSG_EnterGrid(volatile VSG_DEF *v, const volatile VSG_PARAM *cfg, float omega0, float omegaSync, float voltage, float qError);
// pu P/Q in; physical phase-peak voltage reference out.
float VSG_PowerLoop(volatile VSG_DEF *v, const volatile VSG_PARAM *cfg, float pRef, float qRef, float pe, float qe, float voltageMax, float Ts);
#endif
