#ifndef ADC_MEASUREMENT_H_
#define ADC_MEASUREMENT_H_

#include <stdbool.h>
#include <stdint.h>

extern volatile uint16_t adcA0Raw, adcA5Raw, adcA12Raw;
extern volatile uint16_t adcB1Raw, adcB8Raw, adcB10Raw;
extern volatile uint16_t adcC4Raw, adcC8Raw;
extern volatile uint16_t adcD12Raw, adcD14Raw;
extern volatile uint16_t adcE12Raw, adcE15Raw;

extern volatile float Va_cap, Vb_cap, Vc_cap;
extern volatile float PCC_ua, PCC_ub, PCC_uc;
extern volatile float Ia_inv, Ib_inv, Ic_inv;
extern volatile float Ia_filter, Ib_filter, Ic_filter;

// Read raw results and apply the twelve fixed offsets/scales.
void AdcMeasurement_Acquire(void);

#endif
