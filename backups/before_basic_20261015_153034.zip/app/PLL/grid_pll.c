#include "grid_pll.h"
#include <math.h>

SPLL_3ph_DDSRF_F gridPll;
ABC_DQ0_POS_F gridDqPos;
ABC_DQ0_NEG_F gridDqNeg;

volatile uint16_t gridPllEnable = 0U;
volatile uint32_t gridPllRunCount = 0U;

void GridPll_Init(void)
{
    ABC_DQ0_POS_F_init(&gridDqPos);
    ABC_DQ0_NEG_F_init(&gridDqNeg);

    SPLL_3ph_DDSRF_F_init(50,0.0001f,0.00933678f,-0.9813264f,&gridPll);

    gridPll.fo = 50.0f;
    gridPll.sin_2theta = 0.0f;
    gridPll.cos_2theta = 1.0f;
}

void GridPll_Update(float ua, float ub, float uc)
{
    float theta;
    float sinTheta;
    float cosTheta;

    theta = gridPll.theta[0];
    sinTheta = sinf(theta);
    cosTheta = cosf(theta);

    // 正序坐标变换
    gridDqPos.a = ua;
    gridDqPos.b = ub;
    gridDqPos.c = uc;
    gridDqPos.sin_val = sinTheta;
    gridDqPos.cos_val = cosTheta;
    ABC_DQ0_POS_F_FUNC(&gridDqPos);

    // 负序坐标变换
    gridDqNeg.a = ua;
    gridDqNeg.b = ub;
    gridDqNeg.c = uc;
    gridDqNeg.sin_val = sinTheta;
    gridDqNeg.cos_val = cosTheta;
    ABC_DQ0_NEG_F_FUNC(&gridDqNeg);

    gridPll.d_p = gridDqPos.d;
    gridPll.q_p = gridDqPos.q;
    gridPll.d_n = gridDqNeg.d;
    gridPll.q_n = gridDqNeg.q;

    gridPll.sin_2theta = 2.0f * sinTheta * cosTheta;
    gridPll.cos_2theta = cosTheta * cosTheta - sinTheta * sinTheta;

    SPLL_3ph_DDSRF_F_FUNC(&gridPll);
    gridPllRunCount++;
}
