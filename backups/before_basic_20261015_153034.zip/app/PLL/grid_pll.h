#ifndef GRID_PLL_H_
#define GRID_PLL_H_

#include <stdint.h>
#include "ABC_DQ0_POS_F.h"
#include "ABC_DQ0_NEG_F.h"
#include "SPLL_3ph_DDSRF_F.h"

extern SPLL_3ph_DDSRF_F gridPll;
extern ABC_DQ0_POS_F gridDqPos;
extern ABC_DQ0_NEG_F gridDqNeg;
extern volatile uint16_t gridPllEnable;
extern volatile uint32_t gridPllRunCount;

void GridPll_Init(void);
// Inputs are physical volts; normalization remains inside the existing PLL.
void GridPll_Update(float ua, float ub, float uc);

#endif
