# 应用代码说明

当前已接入离网双闭环，启动、参数和故障码详见 `control/OFFGRID_START.md`。
下面的模块说明保留了早期调试模块位置；实际 ISR 以离网控制流程为准。

`empty_driverlib_main.c` 只负责设备启动、应用初始化和慢速后台任务。
外设参数仍由工程根目录的 `c2000.syscfg` 管理；不要手工修改生成的 `board.c`。

| 文件 | 职责 |
| --- | --- |
| `measurement/adc_calibration.h` | 12 路固定零偏、电压和电流比例系数 |
| `measurement/adc_measurement.c/.h` | 五个 ADC 的完成/溢出检查、16 路原始值读取、12 路物理量换算、完成标志清除 |
| `PLL/grid_pll.c/.h` | PLL 对象、初始化、PCC 正负序变换及 PLL 更新 |
| `control/feedback_dq.c/.h` | 电容电压、逆变侧电流、滤波器侧电流的 dq 变换 |
| `control/pi_controller.c/.h` | 位置式 PI 核心，保留旧工程积分限幅和输出限幅规则 |
| `control/current_loop.c/.h` | d/q 电流 PI 计算测试，默认关闭，输出未连接 PWM |
| `control/offgrid_control.c/.h` | 独立离网角度、软启动、电压/电流双环、解耦和矢量限幅 |
| `control/offgrid_config.h` | 半实物模型参数、初始增益和保护阈值 |
| `control/three_level_modulation.c/.h` | 三电平载波层叠占空比映射 |
| `control/pwm_output.c/.h` | 六组桥臂PWM更新、端点处理、软件封锁和截止时间检查 |
| `isr/control_isr.c/.h` | Timer1 和 PWM1 中断注册、中断入口、采样及算法调用顺序 |
| `debug/trip_test.c/.h` | 已有的 PWM1 软件 One-Shot Trip 测试命令 |
| `PLL/ABC_DQ0_*.c/.h`、`PLL/SPLL_3ph_DDSRF_F.c/.h` | 原有数学算法，保持本次拆分前的实现 |

## 每个 PWM1 中断的处理顺序

1. `AdcMeasurement_Acquire()` 检查五个 ADC 是否全部完成且没有溢出。
2. 读取16路原始值后立即清除本轮ADC标志，再做物理量换算；失败帧也会消费标志但不更新测量值。
3. 可选地更新 PCC PLL；离网运行不依赖此 PLL。
4. `OffgridControl_Update()` 用独立角度执行dq反馈和双环，输出三相调制指令。
5. `PwmOutput_Update()` 根据状态更新影子寄存器或封锁输出。
6. 记录计时及首次故障快照，清除PWM1中断标志并应答PIE第3组。ADC标志已经在读取阶段清除。

离网反馈与调制时点的角度关系见启动说明。离网运行期间采样失败会锁存故障并封锁PWM。

## 调试和维护

- 原有原始值、物理量、PLL、dq 对象、采样诊断和 Trip 测试变量名保留，可继续在监视窗口使用。
- 固定零偏启动即有效，不再需要在线标定命令；`adcZeroCalState` 初值为 2。
- `gridPllEnable` 初值仍为 0，需要在合适的交流输入条件下手动使能。
- 早期 `currentLoopTestEnable`、`id_ref/iq_ref`、`ud_pi/uq_pi` 仅属于旧计算测试模块，现 ISR 不调用它。
- 离网使用 `offgrid*` 变量和 `offgridPi*` 对象，旧 `tripTestCommand` 后台调用也已停用，避免独立解锁PWM。
- 移除了未注册、未使用的旧 `adc_a1_isr` 和它的 `adcAIntCount`；实际采集仍由 PWM1 ISR 执行。
- 修改零偏、比例系数时编辑 `adc_calibration.h`；修改算法调用顺序时编辑 `control_isr.c`。
- 头文件只声明共享变量（`extern`），变量本体仅在对应 `.c` 中定义一次。
- 简短函数调用保持单行书写。
- 两个RAM配置已设置 `-O2 --fp_mode=relaxed` 并保留TMU1。Timer2用于ISR计时，不可同时分配给其他任务。
- 实时性复测步骤见 `control/OFFGRID_START.md` 的“ADC溢出与时序修正”部分。

## 构建与硬件复测

CCS 工程的源文件范围包含 `app` 子目录。新增文件后刷新工程并执行 Clean/Build，确认新模块均参与编译。
编译生成目录中的 makefile 是自动生成文件，不需要手工维护。

下载新的程序后检查 `adcReadyMask == 31`、采样失败/溢出计数稳定，以及原来的换算、PLL 和 dq 结果。
离网版本对PWM增加运行时影子装载、端点强制及软件封锁；ADC映射和固定标定保持不变。
