# 离网电压、电流双闭环：半实物测试说明

本模块使用独立的离网角度和电压给定。PCC 可以没有交流输入；`gridPllEnable` 只控制可选的 PCC 监视 PLL。
`offgridEnable` 初值为 0，下载和复位后全部 EPWM1～7 输出由软件 One-Shot Trip 封锁。
底板PWM缓冲器使用 `enPWM48`/GPIO48 和 `enPWM47`/GPIO47，均低有效：启动解除六组桥臂OST后拉低；停机/故障先拉高禁用缓冲器，再封锁全部PWM。
GPIO21（`Breaker`）保持高电平，断路器保持断开，本版本不随运行命令闭合。若模型断路器位于负载支路，断开时只能验证断路器前的电压，不能验证该支路带载。
电流环旧测试模块保留文件，但不再从 ISR 调用；旧 `tripTestCommand` 后台测试也不再调用，避免绕过统一的输出管理。

## 模型与输出映射

实现使用三电平调制和开关编号，C相按新板改为EPWM5/6；不是只有三对 PWM 的两电平逆变器。

| 半实物开关输入 | 控制板输出 |
| --- | --- |
| Sa1 / Sa3 | EPWM1A / EPWM1B |
| Sa2 / Sa4 | EPWM2A / EPWM2B |
| Sb1 / Sb3 | EPWM3A / EPWM3B |
| Sb2 / Sb4 | EPWM4A / EPWM4B |
| Sc1 / Sc3 | EPWM5A / EPWM5B |
| Sc2 / Sc4 | EPWM6A / EPWM6B |

EPWM7 未参与三相调制，始终保持封锁。EPWM3 的板载路由需继续保持此前验证过的 PWM 位置。
电流方向假设：`ia_inv/ib_inv/ic_inv` 从逆变桥经电感流向电容节点；`ia_filter/ib_filter/ic_filter` 从电容节点流向负载。
后者用作电压环的负载侧电流前馈。若半实物采用相反方向，应先修正对应采样符号。

ADC 必须接半实物模型实时计算的反馈；独立手动给定的正弦信号只能检查计算，不能构成闭环。

## 默认参数

在 `offgrid_config.h` 集中设置；运行中的同名可调参数保留在全局监视变量中。建议在停机状态修改。

| 项目 | 默认值 |
| --- | --- |
| 控制频率 / PWM频率 | 10 kHz / 10 kHz |
| 电感 / 电阻 / 电容 | 2 mH / 0.0001 Ω / 12 µF |
| 总直流母线电压 | 400 V，假设上下半母线平衡 |
| 输出频率 | 50 Hz |
| 相电压给定 | 峰值155.56 V，约110 V有效值；不是线电压有效值 |
| 软启动 | 100 V/s，标称给定约1.56秒升完 |
| 电流参考矢量上限 | 30 A峰值 |
| 软件逐相过流阈值 | 40 A瞬时值 |
| 电容电压逐相过压阈值 | 220 V瞬时值 |
| 调制矢量上限 | 0.95，对应400 V母线下190 V相电压峰值指令 |

`offgridDcBusVoltage` 是配置值，尚无对应 ADC 母线测量；它不会自动跟随半实物母线变化。
初始 PI 增益按当前 L/C 和带宽计算，而不是直接复制旧工程的0.7/0.5、1.5/0：

- `offgridCurrentKp=6.2831853`，`offgridCurrentKi=0.31415927`，按500 Hz电流带宽起步。
- `offgridVoltageKp=0.0053314595`，`offgridVoltageKi=1.1843525`，按50 Hz电压自然频率、阻尼0.7071起步。

这些是已做平均模型测试的初值。半实物若包含额外输出电感、测量滤波、不同延迟或不同参数，仍需复测和调参。
本版本未实现中点电位平衡、并网继电器、VSG/功率环或快速硬件过流链路。

## 控制公式和时序

所有 d/q 变量使用实际单位 V、A，时间单位 s。

```
id_ref = PI_ud(vd_ref-vd) + id_load - omega*C*vq
iq_ref = PI_uq(vq_ref-vq) + iq_load + omega*C*vd
ud_ref = PI_id(id_ref-id) + vd + R*id - omega*L*iq
uq_ref = PI_iq(iq_ref-iq) + vq + R*iq + omega*L*id
```

先对电流参考进行矢量限幅，再对电压指令进行矢量限幅，两级均回算积分状态。
电流环 d 轴解耦使用 q 轴电流，修正旧代码同轴引用的问题。

ADC 在 TBCTR=0 采样，ISR 在 TBCTR=TBPRD 计算，新比较值在下一次 TBCTR=0 装载。
反馈使用 `offgridThetaSample`，反变换使用预测到下一装载时点的 `offgridThetaPwm`。
启动先进入 ARMING 并准备完整影子寄存器数据，下次中断进入 RUNNING 才解除六组桥臂的 OST。ARMING和RUNNING都检查更新窗口。
0%/100% 调制使用 AQ 连续软件强制并在零点装载，保留原死区路径。
PWM 写入前检查剩余时间；`pwmOutputFault=3` 表示本次未赶上下一零点装载窗口，立即封锁输出。

## 首次半实物启动

1. CCS 刷新工程并 Clean/Build。`tests` 已从四个 C2000 构建配置排除；若 IDE 尚未重载 `.cproject`，先重新打开工程。
2. 确认模型与上述拓扑、母线、L/C、反馈符号一致，模型的 PWM 输入来自上述六对输出。
3. 下载运行，保持 `offgridEnable=0`。确认 `adcReadyMask=31`，未就绪/溢出计数稳定，12路反馈单位正确；固定零偏已有效，无需再次标定。
4. 第一次将 `offgridVoltagePeakSet=20`（约14.14 V相电压有效值），`gridPllEnable=0`。
5. 设置 `offgridEnable=1`。状态应为0→1→2，GPIO48/47在状态2时输出低电平，`pwmBufferEnabled=1`；GPIO21始终高。观察模型电压软启动、`offgridVdRef`、`capVoltageDq.d/q`。
6. 确认无持续振荡、无故障、`pwmDeadlineMissCount=0`，再逐步提高给定到模型所需电压，最后验证负载阶跃。

停止：设 `offgridEnable=0`，GPIO48/47先变高、缓冲器禁止，六组桥臂和未用的 EPWM7 全部封锁，PI状态及软启动清零。
故障恢复：先 `offgridEnable=0`，排除原因后设 `offgridFaultReset=1`，确认状态回到0，再重新使能。
不要把编译通过或平均模型测试通过当成实机功率级已经验证；现有软件跳闸不能替代快速硬件保护。

## 建议监视变量

`offgridEnable`、`offgridState`、`offgridFaultCode`、`offgridRunCount`、`offgridVoltagePeakRamp`、
`capVoltageDq.d/q`、`invCurrentDq.d/q`、`filterCurrentDq.d/q`、`offgridIdRef/IqRef`、
`offgridUdRef/UqRef`、`offgridMa/Mb/Mc`、`pwmOutputEnabled`、`pwmOutputFault`、`pwmDeadlineMissCount`。
`pwmBufferEnabled` 为缓冲器软件使能状态，0=GPIO48/47高，1=GPIO48/47低；不代表已测量到物理电平。

当前命令入口是 `offgridEnable`，可由调试器设置。CAN接收协议尚未实现；后续收到启动/停止命令时赋值该变量即可，不应绕过输出管理直接拉低GPIO。

状态：0停机、1准备、2运行、3故障。主故障码：1参数、2采样、3母线配置、4过流/电流非有限值、5过压/电压非有限值、6PWM。
PWM子故障：1周期或调制无效、2检测到意外Trip、3计算/写入超时。PWM子故障保留到下一次启动尝试或复位。

## 已执行的软件测试

运行 `tests/run_host_tests.ps1`，需要本机 MSVC。测试编译并执行实际控制器、坐标变换和调制 C 文件，PWM寄存器用桩模拟。
覆盖启动、停机、故障锁存/复位、非法输入、dq解耦符号、限幅、三电平映射、端点强制、EPWM7封锁和PWM超时。
LC平均模型含一个采样周期的指令延迟、RK4积分、50 Ω→12 Ω负载阶跃。
本次默认参数测试结果：最终相电压有效值110.1571 V，末段最大幅值误差0.2275 V。
该测试不包含 ADC量化、实际驱动死区、开关纹波、真实三电平中点动态或目标CPU执行时间。

## ADC溢出与时序修正

针对“每次启动只执行一次控制，随后ADC溢出”的问题，已作以下修改：

- `AdcMeasurement_Acquire()` 在完成16路结果复制后立即清除本轮ADCINT标志，再做换算和控制。原来ISR末尾的延迟清除已移除。
- 真正的溢出或未完成帧仍返回失败并触发故障，没有放宽采样保护。
- `CPU1_RAM`、`CPU1_LAUNCHXL_RAM` 使用 `-O2 --fp_mode=relaxed`，结合已有的TMU1加速浮点运算。FLASH配置未调整。
- Timer2以SYSCLK计数，仅用于计时，不启用Timer2中断。ARMING准备阶段也执行PWM截止检查。
- 锁存首次故障的ADC完成/溢出掩码和计时数据，避免后续正常采样覆盖故障现场。

操作步骤：

1. 保持停机，刷新或重新打开CCS工程，再Clean/Build。构建日志必须出现 `-O2` 和 `--fp_mode=relaxed`；如果仍为 `-Ooff`，说明IDE未重载项目设置，请在项目属性的C2000 Compiler优化设置中确认。
2. 下载运行，保持 `offgridEnable=0`。若有故障先复位，设置 `controlTimingReset=1`，等它自动回0；确认采样失败/溢出计数不再增长。
3. 设置 `offgridVoltagePeakSet=20`、`gridPllEnable=0`，再设置 `offgridEnable=1`，整个过程连续运行、不单步。

建议监视：

| 变量 | 含义 |
| --- | --- |
| `controlIsrLastUs` | 最近一次ISR函数体耗时，故障后通常只剩停机处理，不代表之前的控制耗时 |
| `controlRunMaxUs` | 本次统计以来，启动/运行尝试中的最大ISR函数体耗时 |
| `controlPwmMaxUs` | 从ISR函数体入口到PWM处理完成的最大耗时 |
| `controlEntryIntervalTicks` | 相邻ISR入口间隔；150 MHz、10 kHz时正常约15000计数 |
| `controlAdcTicks` | 本轮采样检查、复制、清标志及换算耗时，单位为SYSCLK计数 |
| `controlComputeTicks` | 本轮可选PLL及离网算法计算耗时，单位为SYSCLK计数 |
| `controlFaultSnapshot` | 首次故障快照，`valid=1`后保持，直到停机时发出计时复位命令 |

当前150 MHz下，计数除以150得到微秒。计时不含进入ISR之前的延迟及最后的返回现场开销，物理PWM截止检查仍为准。
从计数顶点到下一零点约50微秒，写入前还需留出4微秒余量。建议`controlPwmMaxUs`明显低于50微秒，不能仅满足总ISR小于100微秒。

如果再次故障，记录完整快照：`code`、`previousState`、`readyMask`、`overflowMask`、`entryCounter/entryDirection`、`previousIsrTicks`、`previousRunMaxTicks`、`adcTicks`、`ticksAtFault`、`pwmFault`。
掩码位0～4分别对应ADCA～ADCE。故障6且PWM子故障3表示仍未赶上更新窗口，需要根据实际计时继续处理，不能通过跳过保护来启动。
