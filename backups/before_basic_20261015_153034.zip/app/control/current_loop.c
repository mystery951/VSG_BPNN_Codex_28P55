#include "current_loop.h"

PI_POS_DEF PI_ID;
PI_POS_DEF PI_IQ;
volatile uint16_t currentLoopTestEnable = 0U;
volatile uint32_t currentLoopRunCount = 0U;
volatile float Kpi = 1.5f;
volatile float Kii = 0.0f;
volatile float id_ref = 0.0f, iq_ref = 0.0f;
volatile float id_error = 0.0f, iq_error = 0.0f;
volatile float ud_pi = 0.0f, uq_pi = 0.0f;

void CurrentLoop_Init(void)
{
    // Old current-PI output limits: +/-100 V, before feed-forward/decoupling.
    PI_Pos_Init(&PI_ID, Kpi, Kii, 100.0f, -100.0f);
    PI_Pos_Init(&PI_IQ, Kpi, Kii, 100.0f, -100.0f);
}

void CurrentLoop_Update(bool feedbackReady, float idFeedback, float iqFeedback, float sampleTime)
{
    if((currentLoopTestEnable != 1U) || !feedbackReady)
    {
        PI_Pos_Reset(&PI_ID);
        PI_Pos_Reset(&PI_IQ);
        id_error = 0.0f;
        iq_error = 0.0f;
        ud_pi = 0.0f;
        uq_pi = 0.0f;
        return;
    }

    PI_ID.kp = Kpi;
    PI_ID.ki = Kii;
    PI_IQ.kp = Kpi;
    PI_IQ.ki = Kii;
    id_error = id_ref - idFeedback;
    iq_error = iq_ref - iqFeedback;
    ud_pi = PI_Pos_Cal(&PI_ID, id_error, sampleTime);
    uq_pi = PI_Pos_Cal(&PI_IQ, iq_error, sampleTime);
    currentLoopRunCount++;
}
