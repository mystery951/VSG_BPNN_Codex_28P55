#ifndef CURRENT_LOOP_H_
#define CURRENT_LOOP_H_

#include <stdbool.h>
#include <stdint.h>
#include "pi_controller.h"

extern PI_POS_DEF PI_ID;
extern PI_POS_DEF PI_IQ;
extern volatile uint16_t currentLoopTestEnable;
extern volatile uint32_t currentLoopRunCount;
extern volatile float Kpi, Kii;
extern volatile float id_ref, iq_ref;
extern volatile float id_error, iq_error;
extern volatile float ud_pi, uq_pi;

void CurrentLoop_Init(void);
// Calculation test only: output is in volts and has no PWM connection.
void CurrentLoop_Update(bool feedbackReady, float idFeedback, float iqFeedback, float sampleTime);

#endif
