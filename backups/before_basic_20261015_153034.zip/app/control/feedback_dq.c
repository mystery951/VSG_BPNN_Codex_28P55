#include "feedback_dq.h"
#include "app/measurement/adc_measurement.h"
#include <math.h>

ABC_DQ0_POS_F capVoltageDq;
ABC_DQ0_POS_F invCurrentDq;
ABC_DQ0_POS_F filterCurrentDq;

void FeedbackDq_Init(void)
{
    ABC_DQ0_POS_F_init(&capVoltageDq);
    ABC_DQ0_POS_F_init(&invCurrentDq);
    ABC_DQ0_POS_F_init(&filterCurrentDq);
}

void FeedbackDq_Update(float theta)
{
    float sinTheta;
    float cosTheta;

    sinTheta = sinf(theta);
    cosTheta = cosf(theta);

    // 电容电压
    capVoltageDq.a = ua_cap;
    capVoltageDq.b = ub_cap;
    capVoltageDq.c = uc_cap;
    capVoltageDq.sin_val = sinTheta;
    capVoltageDq.cos_val = cosTheta;
    ABC_DQ0_POS_F_FUNC(&capVoltageDq);

    // 逆变侧电流
    invCurrentDq.a = ia_inv;
    invCurrentDq.b = ib_inv;
    invCurrentDq.c = ic_inv;
    invCurrentDq.sin_val = sinTheta;
    invCurrentDq.cos_val = cosTheta;
    ABC_DQ0_POS_F_FUNC(&invCurrentDq);

    // 滤波器侧电流
    filterCurrentDq.a = ia_filter;
    filterCurrentDq.b = ib_filter;
    filterCurrentDq.c = ic_filter;
    filterCurrentDq.sin_val = sinTheta;
    filterCurrentDq.cos_val = cosTheta;
    ABC_DQ0_POS_F_FUNC(&filterCurrentDq);
}
