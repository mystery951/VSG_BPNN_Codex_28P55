#ifndef FEEDBACK_DQ_H_
#define FEEDBACK_DQ_H_

#include "app/pll/ABC_DQ0_POS_F.h"

extern ABC_DQ0_POS_F capVoltageDq;
extern ABC_DQ0_POS_F invCurrentDq;
extern ABC_DQ0_POS_F filterCurrentDq;

void FeedbackDq_Init(void);
void FeedbackDq_Update(float theta);

#endif
