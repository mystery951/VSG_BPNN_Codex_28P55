#ifndef OFFGRID_CONFIG_H_
#define OFFGRID_CONFIG_H_

// Plant defaults from the old project. Confirm against the HIL model.
#define OFFGRID_TS_S                 0.0001f
#define OFFGRID_LF_H                 0.002f
#define OFFGRID_RF_OHM               0.0001f
#define OFFGRID_CF_F                 0.000012f
#define OFFGRID_VDC_V                400.0f
#define OFFGRID_FREQ_HZ              50.0f
#define OFFGRID_VOLTAGE_PEAK_V        155.56f
#define OFFGRID_VOLTAGE_RAMP_V_S      100.0f
#define OFFGRID_CURRENT_LIMIT_A      30.0f
#define OFFGRID_OVERCURRENT_A        40.0f
#define OFFGRID_OVERVOLTAGE_V         220.0f
#define OFFGRID_MODULATION_LIMIT     0.95f
#define OFFGRID_TWO_PI               6.28318530718f

// Initial tuning: current bandwidth 500 Hz; voltage natural frequency 50 Hz.
// Kpi=L*wci, Kii=R*wci; Kpu=2*zeta*C*wv, Kiu=C*wv*wv, zeta=0.7071.
// These are initial HIL tuning values, not a validated physical inverter tuning.
#define OFFGRID_CURRENT_KP           6.2831853f
#define OFFGRID_CURRENT_KI           0.31415927f
#define OFFGRID_VOLTAGE_KP           0.0053314595f
#define OFFGRID_VOLTAGE_KI           1.1843525f

// PWM1/2=A upper/lower, PWM3/4=B, PWM5/6=C. PWM7 remains tripped.
#define OFFGRID_PWM_PERIOD           7500U
#define OFFGRID_PWM_WRITE_MARGIN     600U

#endif
