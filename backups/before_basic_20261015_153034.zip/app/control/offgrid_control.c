#include "offgrid_control.h"
#include "offgrid_config.h"
#include "feedback_dq.h"
#include "app/measurement/adc_measurement.h"
#include <math.h>

volatile uint16_t offgridEnable = 0U, offgridFaultReset = 0U;
volatile uint16_t offgridState = OFFGRID_STOPPED, offgridFaultCode = OFFGRID_FAULT_NONE, offgridPwmPermit = 0U;
volatile uint32_t offgridRunCount = 0U;
volatile float offgridFrequencyHz = OFFGRID_FREQ_HZ, offgridVoltagePeakSet = OFFGRID_VOLTAGE_PEAK_V;
volatile float offgridVoltageRamp = OFFGRID_VOLTAGE_RAMP_V_S;
volatile float offgridDcBusVoltage = OFFGRID_VDC_V, offgridLf = OFFGRID_LF_H, offgridRf = OFFGRID_RF_OHM, offgridCf = OFFGRID_CF_F;
volatile float offgridCurrentLimit = OFFGRID_CURRENT_LIMIT_A, offgridOvercurrent = OFFGRID_OVERCURRENT_A, offgridOvervoltage = OFFGRID_OVERVOLTAGE_V;
volatile float offgridModulationLimit = OFFGRID_MODULATION_LIMIT;
volatile float offgridVoltageKp = OFFGRID_VOLTAGE_KP, offgridVoltageKi = OFFGRID_VOLTAGE_KI;
volatile float offgridCurrentKp = OFFGRID_CURRENT_KP, offgridCurrentKi = OFFGRID_CURRENT_KI;
volatile float offgridTheta = 0.0f, offgridThetaSample = 0.0f, offgridThetaPwm = 0.0f;
volatile float offgridVoltagePeakRamp = 0.0f, offgridVdRef = 0.0f, offgridVqRef = 0.0f;
volatile float offgridIdRef = 0.0f, offgridIqRef = 0.0f, offgridUdRef = 0.0f, offgridUqRef = 0.0f;
volatile float offgridMa = 0.0f, offgridMb = 0.0f, offgridMc = 0.0f;
volatile uint16_t offgridCurrentLimited = 0U, offgridVoltageLimited = 0U;
PI_POS_DEF offgridPiUd, offgridPiUq, offgridPiId, offgridPiIq;

static bool InRange(float x, float lower, float upper)
{
    // Comparisons also reject NaN and infinity.
    return (x >= lower) && (x <= upper);
}

static bool ConfigValid(void)
{
    return InRange(offgridFrequencyHz, 45.0f, 65.0f) && InRange(offgridVoltagePeakSet, 0.0f, 1000.0f)
        && InRange(offgridVoltageRamp, 0.1f, 10000.0f) && InRange(offgridLf, 0.000001f, 1.0f)
        && InRange(offgridCf, 0.00000001f, 0.1f) && InRange(offgridRf, 0.0f, 100.0f)
        && InRange(offgridCurrentLimit, 0.1f, 1000.0f) && InRange(offgridOvercurrent, offgridCurrentLimit, 2000.0f)
        && InRange(offgridOvervoltage, offgridVoltagePeakSet, 2000.0f) && InRange(offgridModulationLimit, 0.05f, 0.95f)
        && InRange(offgridVoltageKp, 0.0f, 1000.0f) && InRange(offgridVoltageKi, 0.0f, 1000000.0f)
        && InRange(offgridCurrentKp, 0.0f, 1000.0f) && InRange(offgridCurrentKi, 0.0f, 1000000.0f);
}

static void ResetDynamics(void)
{
    PI_Pos_Reset(&offgridPiUd);
    PI_Pos_Reset(&offgridPiUq);
    PI_Pos_Reset(&offgridPiId);
    PI_Pos_Reset(&offgridPiIq);
    offgridPwmPermit = 0U;
    offgridTheta = 0.0f;
    offgridThetaSample = 0.0f;
    offgridThetaPwm = 0.0f;
    offgridVoltagePeakRamp = 0.0f;
    offgridVdRef = 0.0f;
    offgridVqRef = 0.0f;
    offgridIdRef = 0.0f;
    offgridIqRef = 0.0f;
    offgridUdRef = 0.0f;
    offgridUqRef = 0.0f;
    offgridMa = 0.0f;
    offgridMb = 0.0f;
    offgridMc = 0.0f;
    offgridCurrentLimited = 0U;
    offgridVoltageLimited = 0U;
}

void OffgridControl_Init(void)
{
    PI_Pos_Init(&offgridPiUd, offgridVoltageKp, offgridVoltageKi, offgridCurrentLimit, -offgridCurrentLimit);
    PI_Pos_Init(&offgridPiUq, offgridVoltageKp, offgridVoltageKi, offgridCurrentLimit, -offgridCurrentLimit);
    PI_Pos_Init(&offgridPiId, offgridCurrentKp, offgridCurrentKi, 200.0f, -200.0f);
    PI_Pos_Init(&offgridPiIq, offgridCurrentKp, offgridCurrentKi, 200.0f, -200.0f);
    offgridEnable = 0U;
    offgridFaultReset = 0U;
    offgridFaultCode = OFFGRID_FAULT_NONE;
    offgridState = OFFGRID_STOPPED;
    offgridRunCount = 0U;
    ResetDynamics();
}

void OffgridControl_ForceFault(uint16_t code)
{
    if(offgridState != OFFGRID_FAULT) offgridFaultCode = code;
    offgridState = OFFGRID_FAULT;
    ResetDynamics();
}

static void LimitVector(float *d, float *q, float limit, PI_POS_DEF *piD, PI_POS_DEF *piQ, volatile uint16_t *limited)
{
    float magnitudeSquared = *d * *d + *q * *q;
    *limited = 0U;
    if(magnitudeSquared > limit * limit)
    {
        float scale = limit / sqrtf(magnitudeSquared);
        float beforeD = *d;
        float beforeQ = *q;
        *d *= scale;
        *q *= scale;
        PI_Pos_TrackVectorLimit(piD, beforeD, *d);
        PI_Pos_TrackVectorLimit(piQ, beforeQ, *q);
        *limited = 1U;
    }
}

void OffgridControl_Update(bool sampleReady)
{
    float omega, voltageLimit, referenceStep;
    float vd, vq, id, iq, loadD, loadQ;
    float currentD, currentQ, voltageD, voltageQ;
    float thetaPwm, sine, cosine, alpha, beta, normalization;
    bool wasArming;

    if(offgridFaultReset == 1U)
    {
        offgridFaultReset = 0U;
        if(offgridEnable == 0U)
        {
            offgridFaultCode = OFFGRID_FAULT_NONE;
            offgridState = OFFGRID_STOPPED;
            ResetDynamics();
        }
    }
    if(offgridState == OFFGRID_FAULT) return;
    if(offgridEnable != 1U)
    {
        if(offgridState != OFFGRID_STOPPED) ResetDynamics();
        offgridState = OFFGRID_STOPPED;
        return;
    }
    if(!ConfigValid()) { OffgridControl_ForceFault(OFFGRID_FAULT_CONFIG); return; }
    if(!InRange(offgridDcBusVoltage, 50.0f, 1200.0f)) { OffgridControl_ForceFault(OFFGRID_FAULT_VDC); return; }
    voltageLimit = offgridDcBusVoltage * 0.5f * offgridModulationLimit;
    if(offgridVoltagePeakSet > voltageLimit) { OffgridControl_ForceFault(OFFGRID_FAULT_CONFIG); return; }
    if(!sampleReady) { OffgridControl_ForceFault(OFFGRID_FAULT_ADC); return; }

    if(!InRange(ia_inv, -offgridOvercurrent, offgridOvercurrent) || !InRange(ib_inv, -offgridOvercurrent, offgridOvercurrent) || !InRange(ic_inv, -offgridOvercurrent, offgridOvercurrent)
        || !InRange(ia_filter, -offgridOvercurrent, offgridOvercurrent) || !InRange(ib_filter, -offgridOvercurrent, offgridOvercurrent) || !InRange(ic_filter, -offgridOvercurrent, offgridOvercurrent))
    { OffgridControl_ForceFault(OFFGRID_FAULT_CURRENT); return; }
    if(!InRange(ua_cap, -offgridOvervoltage, offgridOvervoltage) || !InRange(ub_cap, -offgridOvervoltage, offgridOvervoltage) || !InRange(uc_cap, -offgridOvervoltage, offgridOvervoltage))
    { OffgridControl_ForceFault(OFFGRID_FAULT_VOLTAGE); return; }

    wasArming = (offgridState == OFFGRID_ARMING);
    if(offgridState == OFFGRID_STOPPED)
    {
        ResetDynamics();
        offgridState = OFFGRID_ARMING;
    }
    offgridThetaSample = offgridTheta;
    FeedbackDq_Update(offgridThetaSample);
    vd = capVoltageDq.d;
    vq = capVoltageDq.q;
    id = invCurrentDq.d;
    iq = invCurrentDq.q;
    loadD = filterCurrentDq.d;
    loadQ = filterCurrentDq.q;
    omega = OFFGRID_TWO_PI * offgridFrequencyHz;
    referenceStep = offgridVoltageRamp * OFFGRID_TS_S;
    if(offgridVoltagePeakRamp < offgridVoltagePeakSet)
    {
        offgridVoltagePeakRamp += referenceStep;
        if(offgridVoltagePeakRamp > offgridVoltagePeakSet) offgridVoltagePeakRamp = offgridVoltagePeakSet;
    }
    else
    {
        offgridVoltagePeakRamp -= referenceStep;
        if(offgridVoltagePeakRamp < offgridVoltagePeakSet) offgridVoltagePeakRamp = offgridVoltagePeakSet;
    }
    offgridVdRef = offgridVoltagePeakRamp;
    offgridVqRef = 0.0f;
    offgridPiUd.kp = offgridVoltageKp;
    offgridPiUd.ki = offgridVoltageKi;
    offgridPiUq.kp = offgridVoltageKp;
    offgridPiUq.ki = offgridVoltageKi;
    offgridPiId.kp = offgridCurrentKp;
    offgridPiId.ki = offgridCurrentKi;
    offgridPiIq.kp = offgridCurrentKp;
    offgridPiIq.ki = offgridCurrentKi;

    // C*dv_d/dt = i_d-load_d+w*C*v_q, and q has the opposite cross term.
    currentD = PI_Pos_CalFeedforward(&offgridPiUd, offgridVdRef - vd, OFFGRID_TS_S, loadD - omega * offgridCf * vq, offgridCurrentLimit);
    currentQ = PI_Pos_CalFeedforward(&offgridPiUq, offgridVqRef - vq, OFFGRID_TS_S, loadQ + omega * offgridCf * vd, offgridCurrentLimit);
    LimitVector(&currentD, &currentQ, offgridCurrentLimit, &offgridPiUd, &offgridPiUq, &offgridCurrentLimited);
    offgridIdRef = currentD;
    offgridIqRef = currentQ;

    // L*di_d/dt = u_d-v_d-R*i_d+w*L*i_q. Note the q current in d feed-forward.
    voltageD = PI_Pos_CalFeedforward(&offgridPiId, currentD - id, OFFGRID_TS_S, vd + offgridRf * id - omega * offgridLf * iq, voltageLimit);
    voltageQ = PI_Pos_CalFeedforward(&offgridPiIq, currentQ - iq, OFFGRID_TS_S, vq + offgridRf * iq + omega * offgridLf * id, voltageLimit);
    LimitVector(&voltageD, &voltageQ, voltageLimit, &offgridPiId, &offgridPiIq, &offgridVoltageLimited);
    offgridUdRef = voltageD;
    offgridUqRef = voltageQ;

    // Samples are taken at zero; new PWM shadow values load at the next zero.
    thetaPwm = offgridThetaSample + omega * OFFGRID_TS_S;
    if(thetaPwm >= OFFGRID_TWO_PI) thetaPwm -= OFFGRID_TWO_PI;
    offgridThetaPwm = thetaPwm;
    sine = sinf(thetaPwm);
    cosine = cosf(thetaPwm);
    alpha = voltageD * cosine - voltageQ * sine;
    beta = voltageD * sine + voltageQ * cosine;
    normalization = 2.0f / offgridDcBusVoltage;
    offgridMa = alpha * normalization;
    offgridMb = (-0.5f * alpha + 0.86602540378f * beta) * normalization;
    offgridMc = (-0.5f * alpha - 0.86602540378f * beta) * normalization;
    offgridTheta = thetaPwm;
    offgridRunCount++;
    if(wasArming) offgridState = OFFGRID_RUNNING;
    offgridPwmPermit = (offgridState == OFFGRID_RUNNING) ? 1U : 0U;
}
