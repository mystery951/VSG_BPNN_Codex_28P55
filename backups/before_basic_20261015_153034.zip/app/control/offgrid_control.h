#ifndef OFFGRID_CONTROL_H_
#define OFFGRID_CONTROL_H_

#include <stdbool.h>
#include <stdint.h>
#include "pi_controller.h"

enum { OFFGRID_STOPPED = 0, OFFGRID_ARMING = 1, OFFGRID_RUNNING = 2, OFFGRID_FAULT = 3 };
enum { OFFGRID_FAULT_NONE = 0, OFFGRID_FAULT_CONFIG = 1, OFFGRID_FAULT_ADC = 2, OFFGRID_FAULT_VDC = 3, OFFGRID_FAULT_CURRENT = 4, OFFGRID_FAULT_VOLTAGE = 5, OFFGRID_FAULT_PWM = 6 };

extern volatile uint16_t offgridEnable, offgridFaultReset;
extern volatile uint16_t offgridState, offgridFaultCode, offgridPwmPermit;
extern volatile uint32_t offgridRunCount;
extern volatile float offgridFrequencyHz, offgridVoltagePeakSet, offgridVoltageRamp;
extern volatile float offgridDcBusVoltage, offgridLf, offgridRf, offgridCf;
extern volatile float offgridCurrentLimit, offgridOvercurrent, offgridOvervoltage;
extern volatile float offgridModulationLimit;
extern volatile float offgridVoltageKp, offgridVoltageKi, offgridCurrentKp, offgridCurrentKi;
extern volatile float offgridTheta, offgridThetaSample, offgridThetaPwm;
extern volatile float offgridVoltagePeakRamp, offgridVdRef, offgridVqRef;
extern volatile float offgridIdRef, offgridIqRef, offgridUdRef, offgridUqRef;
extern volatile float offgridMa, offgridMb, offgridMc;
extern volatile uint16_t offgridCurrentLimited, offgridVoltageLimited;
extern PI_POS_DEF offgridPiUd, offgridPiUq, offgridPiId, offgridPiIq;

void OffgridControl_Init(void);
void OffgridControl_Update(bool sampleReady);
void OffgridControl_ForceFault(uint16_t code);

#endif
