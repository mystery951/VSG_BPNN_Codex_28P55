#include "pi_controller.h"

void PI_Pos_Reset(PI_POS_DEF *v)
{
    v->ek = 0.0f;
    v->uk = 0.0f;
    v->ui = 0.0f;
}

void PI_Pos_Init(PI_POS_DEF *v, float kp, float ki, float upper, float lower)
{
    PI_Pos_Reset(v);
    v->kp = kp;
    v->ki = ki;
    v->uplimit = upper;
    v->lolimit = lower;
}

float PI_Pos_Cal(PI_POS_DEF *v, float error, float sampleTime)
{
    v->ek = error;
    v->ui += v->ki * sampleTime * v->ek;

    if(v->ui > 2.0f * v->uplimit)
    {
        v->ui = 2.0f * v->uplimit;
    }
    if(v->ui < 2.0f * v->lolimit)
    {
        v->ui = 2.0f * v->lolimit;
    }

    v->uk = v->kp * v->ek + v->ui;
    if(v->uk > v->uplimit)
    {
        v->uk = v->uplimit;
    }
    if(v->uk < v->lolimit)
    {
        v->uk = v->lolimit;
    }
    return v->uk;
}

float PI_Pos_CalFeedforward(PI_POS_DEF *v, float error, float sampleTime, float feedforward, float limit)
{
    float proportional;
    float beforeLimit;
    float output;

    v->ek = error;
    proportional = v->kp * error;
    v->ui += v->ki * sampleTime * error;
    beforeLimit = proportional + v->ui + feedforward;
    output = beforeLimit;
    if(output > limit) output = limit;
    if(output < -limit) output = -limit;
    if(v->ki > 0.0f) v->ui += output - beforeLimit;
    v->uk = output - feedforward;
    return output;
}

void PI_Pos_TrackVectorLimit(PI_POS_DEF *v, float beforeLimit, float afterLimit)
{
    if(v->ki > 0.0f) v->ui += afterLimit - beforeLimit;
    v->uk += afterLimit - beforeLimit;
}
