#ifndef PI_CONTROLLER_H_
#define PI_CONTROLLER_H_

// Positional PI, preserving the old project's integral/output limiting rules.
typedef struct
{
    float ek;
    float uk;
    float ui;
    float ki;
    float kp;
    float uplimit;
    float lolimit;
} PI_POS_DEF;

void PI_Pos_Init(PI_POS_DEF *v, float kp, float ki, float upper, float lower);
void PI_Pos_Reset(PI_POS_DEF *v);
float PI_Pos_Cal(PI_POS_DEF *v, float error, float sampleTime);
// Off-grid controller: limit the total output including feed-forward.
float PI_Pos_CalFeedforward(PI_POS_DEF *v, float error, float sampleTime, float feedforward, float limit);
void PI_Pos_TrackVectorLimit(PI_POS_DEF *v, float beforeLimit, float afterLimit);

#endif
