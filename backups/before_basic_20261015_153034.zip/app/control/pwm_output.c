#include "pwm_output.h"
#include "three_level_modulation.h"
#include "offgrid_config.h"
#include "driverlib.h"
#include "board.h"

volatile uint16_t pwmOutputEnabled = 0U, pwmOutputFault = 0U;
volatile uint16_t pwmBufferEnabled = 0U;
volatile uint16_t pwmWriteCounter = 0U;
volatile uint32_t pwmWriteCount = 0U, pwmDeadlineMissCount = 0U;

static const uint32_t allPwm[7] = { EPWM1_BASE, EPWM2_BASE, EPWM3_BASE, EPWM4_BASE, EPWM5_BASE, EPWM6_BASE, EPWM7_BASE };
static const uint32_t bridgePwm[6] = { EPWM1_BASE, EPWM2_BASE, EPWM3_BASE, EPWM4_BASE, EPWM5_BASE, EPWM6_BASE };
static bool periodValid = false;

static void SetBufferEnabled(bool enable)
{
    // Baseboard buffer enables are active low. GPIO21 is not a run enable.
    GPIO_writePin(enPWM48, enable ? 0U : 1U);
    GPIO_writePin(enPWM47, enable ? 0U : 1U);
    pwmBufferEnabled = enable ? 1U : 0U;
}

void PwmOutput_Disable(void)
{
    uint16_t i;
    SetBufferEnabled(false);
    for(i = 0U; i < 7U; i++) EPWM_forceTripZoneEvent(allPwm[i], EPWM_TZ_FORCE_EVENT_OST);
    pwmOutputEnabled = 0U;
}

static void SetDuty(uint32_t base, float duty)
{
    uint16_t compare;
    EPWM_ActionQualifierSWOutput force;

    // Force the pre-deadband A waveform at endpoints. Do not depend on
    // coincident CMPA=0/TBPRD events for exact zero/full duty.
    if(duty <= 0.0f)
    {
        compare = 1U;
        force = EPWM_AQ_SW_OUTPUT_LOW;
    }
    else if(duty >= 1.0f)
    {
        compare = OFFGRID_PWM_PERIOD - 1U;
        force = EPWM_AQ_SW_OUTPUT_HIGH;
    }
    else
    {
        compare = (uint16_t)(duty * (float)OFFGRID_PWM_PERIOD + 0.5f);
        if(compare < 1U) compare = 1U;
        if(compare >= OFFGRID_PWM_PERIOD) compare = OFFGRID_PWM_PERIOD - 1U;
        force = EPWM_AQ_SW_DISABLED;
    }
    EPWM_setCounterCompareValue(base, EPWM_COUNTER_COMPARE_A, compare);
    EPWM_setCounterCompareValue(base, EPWM_COUNTER_COMPARE_B, compare);
    EPWM_setActionQualifierContSWForceAction(base, EPWM_AQ_OUTPUT_A, force);
}

void PwmOutput_Init(void)
{
    uint16_t i;
    SetBufferEnabled(false);
    GPIO_writePin(Breaker, 1U); // Breaker remains open; no automatic closure.
    periodValid = true;
    for(i = 0U; i < 7U; i++)
    {
        EPWM_setTripZoneAction(allPwm[i], EPWM_TZ_ACTION_EVENT_TZA, EPWM_TZ_ACTION_LOW);
        EPWM_setTripZoneAction(allPwm[i], EPWM_TZ_ACTION_EVENT_TZB, EPWM_TZ_ACTION_LOW);
        EPWM_forceTripZoneEvent(allPwm[i], EPWM_TZ_FORCE_EVENT_OST);
        if(EPWM_getTimeBasePeriod(allPwm[i]) != OFFGRID_PWM_PERIOD) periodValid = false;
        EPWM_setCounterCompareShadowLoadMode(allPwm[i], EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);
        EPWM_setCounterCompareShadowLoadMode(allPwm[i], EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);
        EPWM_setActionQualifierContSWForceShadowMode(allPwm[i], EPWM_AQ_SW_SH_LOAD_ON_CNTR_ZERO);
        EPWM_setRisingEdgeDeadBandDelayInput(allPwm[i], EPWM_DB_INPUT_EPWMA);
        EPWM_setFallingEdgeDeadBandDelayInput(allPwm[i], EPWM_DB_INPUT_EPWMA);
    }
    pwmOutputEnabled = 0U;
    pwmOutputFault = 0U;
    pwmWriteCount = 0U;
    pwmDeadlineMissCount = 0U;
    (void)PwmOutput_Update(false, 0.0f, 0.0f, 0.0f);
}

bool PwmOutput_CheckUpdateWindow(void)
{
    pwmWriteCounter = EPWM_getTimeBaseCounterValue(EPWM1_BASE);
    if(EPWM_getTimeBaseCounterDirection(EPWM1_BASE) != EPWM_TIME_BASE_STATUS_COUNT_DOWN || pwmWriteCounter < OFFGRID_PWM_WRITE_MARGIN)
    {
        pwmOutputFault = 3U;
        pwmDeadlineMissCount++;
        PwmOutput_Disable();
        return false;
    }
    return true;
}

bool PwmOutput_Update(bool enable, float ma, float mb, float mc)
{
    uint16_t i;
    ThreeLevelDuty dutyA, dutyB, dutyC;
    uint16_t tripFlags;

    if(!enable) PwmOutput_Disable();
    if(enable)
    {
        pwmOutputFault = 0U;
        if(!periodValid || !(ma >= -1.0f && ma <= 1.0f) || !(mb >= -1.0f && mb <= 1.0f) || !(mc >= -1.0f && mc <= 1.0f))
        { pwmOutputFault = 1U; PwmOutput_Disable(); return false; }
        for(i = 0U; i < 6U; i++)
        {
            tripFlags = EPWM_getTripZoneFlagStatus(bridgePwm[i]);
            if((pwmOutputEnabled != 0U && tripFlags != 0U) || ((tripFlags & (uint16_t)~(EPWM_TZ_FLAG_OST | EPWM_TZ_INTERRUPT)) != 0U))
            { pwmOutputFault = 2U; PwmOutput_Disable(); return false; }
        }
        if(!PwmOutput_CheckUpdateWindow()) return false;
    }

    ThreeLevelModulation_Map(ma, &dutyA);
    ThreeLevelModulation_Map(mb, &dutyB);
    ThreeLevelModulation_Map(mc, &dutyC);
    SetDuty(EPWM1_BASE, dutyA.upper);
    SetDuty(EPWM2_BASE, dutyA.lower);
    SetDuty(EPWM3_BASE, dutyB.upper);
    SetDuty(EPWM4_BASE, dutyB.lower);
    SetDuty(EPWM5_BASE, dutyC.upper);
    SetDuty(EPWM6_BASE, dutyC.lower);

    if(enable)
    {
        if(EPWM_getTimeBaseCounterDirection(EPWM1_BASE) != EPWM_TIME_BASE_STATUS_COUNT_DOWN)
        { pwmOutputFault = 3U; pwmDeadlineMissCount++; PwmOutput_Disable(); return false; }
        if(pwmOutputEnabled == 0U)
        {
            // ARMING has already loaded one complete set at the preceding zero.
            for(i = 0U; i < 6U; i++) EPWM_clearTripZoneFlag(bridgePwm[i], EPWM_TZ_FLAG_OST | EPWM_TZ_INTERRUPT);
            pwmOutputEnabled = 1U;
            SetBufferEnabled(true);
        }
        pwmWriteCount++;
    }
    return true;
}
