#ifndef PWM_OUTPUT_H_
#define PWM_OUTPUT_H_

#include <stdbool.h>
#include <stdint.h>

extern volatile uint16_t pwmOutputEnabled, pwmOutputFault;
extern volatile uint16_t pwmBufferEnabled;
extern volatile uint16_t pwmWriteCounter;
extern volatile uint32_t pwmWriteCount, pwmDeadlineMissCount;

void PwmOutput_Init(void);
void PwmOutput_Disable(void);
bool PwmOutput_CheckUpdateWindow(void);
bool PwmOutput_Update(bool enable, float ma, float mb, float mc);

#endif
