#include "three_level_modulation.h"

void ThreeLevelModulation_Map(float modulation, ThreeLevelDuty *duty)
{
    // Existing three-level carrier disposition: upper=max(m,0), lower=min(m+1,1).
    if(modulation > 1.0f) modulation = 1.0f;
    if(modulation < -1.0f) modulation = -1.0f;
    duty->upper = (modulation > 0.0f) ? modulation : 0.0f;
    duty->lower = (modulation < 0.0f) ? modulation + 1.0f : 1.0f;
}
