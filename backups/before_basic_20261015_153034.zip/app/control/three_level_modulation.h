#ifndef THREE_LEVEL_MODULATION_H_
#define THREE_LEVEL_MODULATION_H_

typedef struct { float upper; float lower; } ThreeLevelDuty;
void ThreeLevelModulation_Map(float modulation, ThreeLevelDuty *duty);

#endif
