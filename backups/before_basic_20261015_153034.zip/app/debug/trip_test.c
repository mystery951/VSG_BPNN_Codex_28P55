#include "trip_test.h"
#include "driverlib.h"
#include "board.h"

volatile uint16_t tripTestCommand = 0U; // 1 = force PWM1 OST, 2 = clear.
volatile uint16_t tripTestStatus = 0U;

void TripTest_Process(void)
{
    if(tripTestCommand == 1U)
    {
        EPWM_forceTripZoneEvent(PWM1_BASE, EPWM_TZ_FORCE_EVENT_OST);
        tripTestStatus = EPWM_getTripZoneFlagStatus(PWM1_BASE);
        tripTestCommand = 0U;
    }
    else if(tripTestCommand == 2U)
    {
        EPWM_clearTripZoneFlag(PWM1_BASE, EPWM_TZ_FLAG_OST);
        tripTestStatus = EPWM_getTripZoneFlagStatus(PWM1_BASE);
        tripTestCommand = 0U;
    }
}
