#ifndef TRIP_TEST_H_
#define TRIP_TEST_H_

#include <stdint.h>

extern volatile uint16_t tripTestCommand;
extern volatile uint16_t tripTestStatus;

void TripTest_Process(void);

#endif
