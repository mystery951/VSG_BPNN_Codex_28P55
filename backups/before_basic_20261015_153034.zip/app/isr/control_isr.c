#include "control_isr.h"
#include "board.h"
#include "device.h"
#include "app/measurement/adc_measurement.h"
#include "app/pll/grid_pll.h"
#include "app/control/feedback_dq.h"
#include "app/control/offgrid_control.h"
#include "app/control/pwm_output.h"

volatile uint32_t timer1Count = 0;
volatile uint32_t pwm1IntCount = 0;
volatile ControlFaultSnapshot controlFaultSnapshot = {0};
volatile uint16_t controlTimingReset = 0U;
volatile uint32_t controlIsrLastTicks = 0U, controlIsrMaxTicks = 0U, controlRunMaxTicks = 0U;
volatile uint32_t controlAdcTicks = 0U, controlComputeTicks = 0U, controlEntryIntervalTicks = 0U;
volatile float controlIsrLastUs = 0.0f, controlIsrMaxUs = 0.0f, controlRunMaxUs = 0.0f, controlPwmMaxUs = 0.0f;
static uint32_t previousEntryTick = 0U;
static bool previousEntryValid = false;

static void ResetTiming(void)
{
    controlIsrLastTicks = 0U;
    controlIsrMaxTicks = 0U;
    controlRunMaxTicks = 0U;
    controlAdcTicks = 0U;
    controlComputeTicks = 0U;
    controlEntryIntervalTicks = 0U;
    controlIsrLastUs = 0.0f;
    controlIsrMaxUs = 0.0f;
    controlRunMaxUs = 0.0f;
    controlPwmMaxUs = 0.0f;
    controlFaultSnapshot.valid = 0U;
    previousEntryValid = false;
}

void ControlIsr_Init(void)
{
    // Reserve Timer2 as a free-running SYSCLK down-counter; no Timer2 IRQ.
    CPUTimer_stopTimer(CPUTIMER2_BASE);
    CPUTimer_disableInterrupt(CPUTIMER2_BASE);
    SysCtl_setCputimer2Clk(SYSCTL_TMR2CLKPRESCALE_1, SYSCTL_TMR2CLKSRCSEL_SYSCLK);
    CPUTimer_setPreScaler(CPUTIMER2_BASE, 0U);
    CPUTimer_setPeriod(CPUTIMER2_BASE, 0xFFFFFFFFUL);
    CPUTimer_reloadTimerCounter(CPUTIMER2_BASE);
    CPUTimer_setEmulationMode(CPUTIMER2_BASE, CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
    CPUTimer_startTimer(CPUTIMER2_BASE);
    ResetTiming();
    Interrupt_register(INT_TIMER1, &cpu_timer1_isr);
    Interrupt_enable(INT_TIMER1);
    Interrupt_register(INT_EPWM1, &epwm1_isr);
    Interrupt_enable(INT_EPWM1);
}

__interrupt void cpu_timer1_isr(void)
{
    timer1Count++;
}

__interrupt void epwm1_isr(void)
{
    bool sampleReady;
    bool activeAttempt;
    uint16_t stateBefore;
    uint16_t entryCounter;
    uint16_t entryDirection;
    uint32_t entryTick;
    uint32_t computeStart;
    uint32_t elapsed;
    const float ticksToUs = 1000000.0f / (float)DEVICE_SYSCLK_FREQ;

    entryTick = CPUTimer_getTimerCount(CPUTIMER2_BASE);
    entryCounter = EPWM_getTimeBaseCounterValue(PWM1_BASE);
    entryDirection = EPWM_getTimeBaseCounterDirection(PWM1_BASE);
    stateBefore = offgridState;
    activeAttempt = (offgridEnable == 1U) && (stateBefore != OFFGRID_FAULT);
    if((controlTimingReset == 1U) && (offgridEnable == 0U))
    {
        ResetTiming();
        controlTimingReset = 0U;
    }
    if(previousEntryValid) controlEntryIntervalTicks = previousEntryTick - entryTick;
    previousEntryTick = entryTick;
    previousEntryValid = true;
    pwm1IntCount++;

    // Acquire consumes the old completion flags before any control calculations.
    sampleReady = AdcMeasurement_Acquire() && (adcZeroCalState == 2U);
    computeStart = CPUTimer_getTimerCount(CPUTIMER2_BASE);
    controlAdcTicks = entryTick - computeStart;
    if(sampleReady)
    {
        if((adcZeroCalState == 2U) && (gridPllEnable == 1U))
        {
            // PCC PLL is optional monitoring, never the islanded control angle.
            if(offgridEnable == 0U) FeedbackDq_Update(gridPll.theta[0]);
            GridPll_Update(PCC_ua, PCC_ub, PCC_uc);
        }
    }

    OffgridControl_Update(sampleReady);
    controlComputeTicks = computeStart - CPUTimer_getTimerCount(CPUTIMER2_BASE);
    // ARMING also has to prepare all shadows before the upcoming counter zero.
    if((offgridState == OFFGRID_ARMING) && !PwmOutput_CheckUpdateWindow())
    {
        OffgridControl_ForceFault(OFFGRID_FAULT_PWM);
    }
    if(!PwmOutput_Update(offgridPwmPermit == 1U, offgridMa, offgridMb, offgridMc))
    {
        OffgridControl_ForceFault(OFFGRID_FAULT_PWM);
    }
    elapsed = entryTick - CPUTimer_getTimerCount(CPUTIMER2_BASE);
    if(activeAttempt && elapsed * ticksToUs > controlPwmMaxUs) controlPwmMaxUs = elapsed * ticksToUs;
    if((stateBefore != OFFGRID_FAULT) && (offgridState == OFFGRID_FAULT) && (controlFaultSnapshot.valid == 0U))
    {
        controlFaultSnapshot.code = offgridFaultCode;
        controlFaultSnapshot.previousState = stateBefore;
        controlFaultSnapshot.readyMask = adcReadyMask;
        controlFaultSnapshot.overflowMask = adcOverflowMask;
        controlFaultSnapshot.zeroCalState = adcZeroCalState;
        controlFaultSnapshot.entryCounter = entryCounter;
        controlFaultSnapshot.entryDirection = entryDirection;
        controlFaultSnapshot.pwmFault = pwmOutputFault;
        controlFaultSnapshot.previousIsrTicks = controlIsrLastTicks;
        controlFaultSnapshot.previousRunMaxTicks = controlRunMaxTicks;
        controlFaultSnapshot.adcTicks = controlAdcTicks;
        controlFaultSnapshot.ticksAtFault = elapsed;
        controlFaultSnapshot.valid = 1U; // Publish last; keep until reset command.
    }
    EPWM_clearEventTriggerInterruptFlag(PWM1_BASE);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP3);
    elapsed = entryTick - CPUTimer_getTimerCount(CPUTIMER2_BASE);
    controlIsrLastTicks = elapsed;
    controlIsrLastUs = elapsed * ticksToUs;
    if(elapsed > controlIsrMaxTicks)
    {
        controlIsrMaxTicks = elapsed;
        controlIsrMaxUs = elapsed * ticksToUs;
    }
    if(activeAttempt && elapsed > controlRunMaxTicks)
    {
        controlRunMaxTicks = elapsed;
        controlRunMaxUs = elapsed * ticksToUs;
    }
}
