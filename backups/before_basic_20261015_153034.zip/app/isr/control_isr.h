#ifndef CONTROL_ISR_H_
#define CONTROL_ISR_H_

#include "driverlib.h"

extern volatile uint32_t timer1Count;
extern volatile uint32_t pwm1IntCount;

typedef struct
{
    uint16_t valid;
    uint16_t code;
    uint16_t previousState;
    uint16_t readyMask;
    uint16_t overflowMask;
    uint16_t zeroCalState;
    uint16_t entryCounter;
    uint16_t entryDirection;
    uint16_t pwmFault;
    uint32_t previousIsrTicks;
    uint32_t previousRunMaxTicks;
    uint32_t adcTicks;
    uint32_t ticksAtFault;
} ControlFaultSnapshot;

extern volatile ControlFaultSnapshot controlFaultSnapshot;
extern volatile uint16_t controlTimingReset;
extern volatile uint32_t controlIsrLastTicks, controlIsrMaxTicks, controlRunMaxTicks;
extern volatile uint32_t controlAdcTicks, controlComputeTicks, controlEntryIntervalTicks;
extern volatile float controlIsrLastUs, controlIsrMaxUs, controlRunMaxUs, controlPwmMaxUs;

void ControlIsr_Init(void);
__interrupt void cpu_timer1_isr(void);
__interrupt void epwm1_isr(void);

#endif
