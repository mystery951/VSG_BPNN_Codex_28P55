#include "adc_measurement.h"
#include "adc_calibration.h"
#include "driverlib.h"
#include "board.h"

volatile uint16_t adcB0Raw = 0, adcB1Raw = 0;
volatile uint16_t adcB8Raw = 0, adcB10Raw = 0;
volatile uint16_t adcC4Raw = 0, adcC8Raw = 0, adcC14Raw = 0;
volatile uint16_t adcD11Raw = 0, adcD12Raw = 0, adcD14Raw = 0;
volatile uint16_t adcE12Raw = 0, adcE15Raw = 0;
volatile uint16_t adcA0Raw = 0, adcA5Raw = 0, adcA9Raw = 0, adcA12Raw = 0;

volatile float ua_cap = 0, ub_cap = 0, uc_cap = 0;
volatile float PCC_ua = 0, PCC_ub = 0, PCC_uc = 0;
volatile float ia_inv = 0, ib_inv = 0, ic_inv = 0;
volatile float ia_filter = 0, ib_filter = 0, ic_filter = 0;

volatile uint32_t adcReadyCount = 0;
volatile uint32_t adcNotReadyCount = 0;
volatile uint32_t adcOverflowCount = 0;
volatile uint16_t adcReadyMask = 0;
volatile uint16_t adcZeroCalState = 2U; // Fixed calibration is ready at startup.

static const uint32_t adcBases[5] =
{
    ADC_A_BASE, ADC_B_BASE, ADC_C_BASE, ADC_D_BASE, ADC_E_BASE
};
volatile uint16_t adcOverflowMask = 0U;
static void ClearCompletionFlags(void);

bool AdcMeasurement_Acquire(void)
{
    uint16_t i;
    uint16_t readyMask = 0U;

    adcOverflowMask = 0U;
    for(i = 0U; i < 5U; i++)
    {
        if(ADC_getInterruptStatus(adcBases[i], ADC_INT_NUMBER1))
        {
            readyMask |= (uint16_t)(1U << i);
        }
        if(ADC_getInterruptOverflowStatus(adcBases[i], ADC_INT_NUMBER1))
        {
            adcOverflowMask |= (uint16_t)(1U << i);
        }
    }

    adcReadyMask = readyMask;
    if(adcOverflowMask != 0U)
    {
        adcOverflowCount++;
    }
    if((readyMask != 0x1FU) || (adcOverflowMask != 0U))
    {
        adcNotReadyCount++;
        ClearCompletionFlags();
        return false;
    }

    adcA0Raw  = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER0);
    adcA5Raw  = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER1);
    adcA9Raw  = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER2);
    adcA12Raw = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER3);

    adcB0Raw  = ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER0);
    adcB1Raw  = ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER1);
    adcB8Raw  = ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER2);
    adcB10Raw = ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER3);

    adcC4Raw  = ADC_readResult(ADCCRESULT_BASE, ADC_SOC_NUMBER0);
    adcC8Raw  = ADC_readResult(ADCCRESULT_BASE, ADC_SOC_NUMBER1);
    adcC14Raw = ADC_readResult(ADCCRESULT_BASE, ADC_SOC_NUMBER2);

    adcD11Raw = ADC_readResult(ADCDRESULT_BASE, ADC_SOC_NUMBER0);
    adcD12Raw = ADC_readResult(ADCDRESULT_BASE, ADC_SOC_NUMBER1);
    adcD14Raw = ADC_readResult(ADCDRESULT_BASE, ADC_SOC_NUMBER2);

    adcE12Raw = ADC_readResult(ADCERESULT_BASE, ADC_SOC_NUMBER0);
    adcE15Raw = ADC_readResult(ADCERESULT_BASE, ADC_SOC_NUMBER1);

    // Results are in RAM now. Release ADCINT flags before conversion/control.
    ClearCompletionFlags();

    if(adcZeroCalState == 2U)
    {
        ua_cap = ((float)adcA0Raw  - adcZeroOffset[0]) * VOL_SCALE;
        PCC_ua = ((float)adcA5Raw  - adcZeroOffset[1]) * VOL_SCALE;
        ia_inv = ((float)adcA12Raw - adcZeroOffset[2]) * CUR_SCALE;
        
        ub_cap = ((float)adcB1Raw  - adcZeroOffset[3]) * VOL_SCALE;
        PCC_ub = ((float)adcB8Raw  - adcZeroOffset[4]) * VOL_SCALE;
        ib_inv = ((float)adcB10Raw - adcZeroOffset[5]) * CUR_SCALE;
        
        uc_cap = ((float)adcC4Raw  - adcZeroOffset[6]) * VOL_SCALE;
        PCC_uc = ((float)adcC8Raw  - adcZeroOffset[7]) * VOL_SCALE;
        
        ic_inv    = ((float)adcD12Raw - adcZeroOffset[8])  * CUR_SCALE;
        ia_filter = ((float)adcD14Raw - adcZeroOffset[9])  * CUR_SCALE;
        ib_filter = ((float)adcE12Raw - adcZeroOffset[10]) * CUR_SCALE;
        ic_filter = ((float)adcE15Raw - adcZeroOffset[11]) * CUR_SCALE;
    }
    adcReadyCount++;
    return true;
}

static void ClearCompletionFlags(void)
{
    uint16_t i;

    for(i = 0U; i < 5U; i++)
    {
        ADC_clearInterruptStatus(adcBases[i], ADC_INT_NUMBER1);
        if((adcOverflowMask & (uint16_t)(1U << i)) != 0U)
        {
            ADC_clearInterruptOverflowStatus(adcBases[i], ADC_INT_NUMBER1);
            ADC_clearInterruptStatus(adcBases[i], ADC_INT_NUMBER1);
        }
    }
}
