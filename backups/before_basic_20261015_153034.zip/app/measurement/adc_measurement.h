#ifndef ADC_MEASUREMENT_H_
#define ADC_MEASUREMENT_H_

#include <stdbool.h>
#include <stdint.h>

extern volatile uint16_t adcA0Raw, adcA5Raw, adcA9Raw, adcA12Raw;
extern volatile uint16_t adcB0Raw, adcB1Raw, adcB8Raw, adcB10Raw;
extern volatile uint16_t adcC4Raw, adcC8Raw, adcC14Raw;
extern volatile uint16_t adcD11Raw, adcD12Raw, adcD14Raw;
extern volatile uint16_t adcE12Raw, adcE15Raw;

extern volatile float ua_cap, ub_cap, uc_cap;
extern volatile float PCC_ua, PCC_ub, PCC_uc;
extern volatile float ia_inv, ib_inv, ic_inv;
extern volatile float ia_filter, ib_filter, ic_filter;

extern volatile uint16_t adcReadyMask;
extern volatile uint16_t adcOverflowMask;
extern volatile uint16_t adcZeroCalState;
extern volatile uint32_t adcReadyCount, adcNotReadyCount, adcOverflowCount;

// Consumes completion flags immediately after the result snapshot, before math.
// A false return leaves measurements unchanged but clears the rejected flags.
bool AdcMeasurement_Acquire(void);

#endif
