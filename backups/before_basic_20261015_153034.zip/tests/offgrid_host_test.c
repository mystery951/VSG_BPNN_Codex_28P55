#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stubs/driverlib.h"
#include "app/control/offgrid_control.h"
#include "app/control/offgrid_config.h"
#include "app/control/feedback_dq.h"
#include "app/control/three_level_modulation.h"
#include "app/control/pwm_output.h"
#include "app/measurement/adc_measurement.h"

// Real measurement/controller code, with ADC and PWM registers simulated below.
static bool adcFlags[5], adcOverflows[5];
static uint16_t adcResults[5][4];
static unsigned adcResultReads, adcFlagClears;
bool ADC_getInterruptStatus(uint32_t base, unsigned interrupt) { (void)interrupt; return adcFlags[base - 10U]; }
bool ADC_getInterruptOverflowStatus(uint32_t base, unsigned interrupt) { (void)interrupt; return adcOverflows[base - 10U]; }
void ADC_clearInterruptStatus(uint32_t base, unsigned interrupt)
{
    (void)interrupt;
    assert(adcResultReads == 0U || adcResultReads == 16U);
    adcFlags[base - 10U] = false;
    adcFlagClears++;
}
void ADC_clearInterruptOverflowStatus(uint32_t base, unsigned interrupt) { (void)interrupt; adcOverflows[base - 10U] = false; }
uint16_t ADC_readResult(uint32_t base, unsigned soc)
{
    assert(adcFlagClears == 0U); // Do not clear flags before the full result copy.
    adcResultReads++;
    return adcResults[base - 20U][soc];
}

typedef struct { uint16_t period, compare[2], force, flags, counter, direction; } FakePwm;
static FakePwm hw[8];
static uint32_t gpioValue[64];
void GPIO_writePin(uint32_t pin, uint32_t value)
{
    unsigned i;
    assert(pin < 64U);
    if(pin == 21U) assert(value == 1U); // No breaker closure in this version.
    if((pin == 47U || pin == 48U) && value == 0U)
    {
        // Both buffers may only be enabled after every used bridge is released.
        for(i = 1U; i <= 6U; i++) assert(hw[i].flags == 0U);
        assert(hw[7].flags & EPWM_TZ_FLAG_OST);
    }
    gpioValue[pin] = value;
}
void EPWM_setTripZoneAction(uint32_t b, unsigned e, unsigned a) { (void)b; (void)e; assert(a == EPWM_TZ_ACTION_LOW); }
void EPWM_forceTripZoneEvent(uint32_t b, uint16_t e) { assert(gpioValue[47] == 1U && gpioValue[48] == 1U); hw[b].flags |= e; }
uint16_t EPWM_getTimeBasePeriod(uint32_t b) { return hw[b].period; }
void EPWM_setCounterCompareShadowLoadMode(uint32_t b, unsigned c, unsigned m) { (void)b; (void)c; assert(m == 0U); }
void EPWM_setActionQualifierContSWForceShadowMode(uint32_t b, unsigned m) { (void)b; assert(m == 0U); }
void EPWM_setRisingEdgeDeadBandDelayInput(uint32_t b, uint16_t i) { (void)b; assert(i == 0U); }
void EPWM_setFallingEdgeDeadBandDelayInput(uint32_t b, uint16_t i) { (void)b; assert(i == 0U); }
void EPWM_setCounterCompareValue(uint32_t b, unsigned c, uint16_t v) { hw[b].compare[c] = v; }
void EPWM_setActionQualifierContSWForceAction(uint32_t b, unsigned o, EPWM_ActionQualifierSWOutput f) { assert(o == 0U); hw[b].force = (uint16_t)f; }
uint16_t EPWM_getTripZoneFlagStatus(uint32_t b) { return hw[b].flags; }
uint16_t EPWM_getTimeBaseCounterValue(uint32_t b) { return hw[b].counter; }
uint16_t EPWM_getTimeBaseCounterDirection(uint32_t b) { return hw[b].direction; }
void EPWM_clearTripZoneFlag(uint32_t b, uint16_t f) { assert(gpioValue[47] == 1U && gpioValue[48] == 1U); hw[b].flags &= (uint16_t)~f; }

static void Near(float actual, float expected, float tolerance)
{
    if(!(fabsf(actual - expected) <= tolerance))
    {
        fprintf(stderr, "Expected %.8g, got %.8g (tolerance %.8g)\n", expected, actual, tolerance);
        exit(1);
    }
}

static void SetAbc(float alpha, float beta, volatile float *a, volatile float *b, volatile float *c)
{
    *a = alpha;
    *b = -0.5f * alpha + 0.86602540378f * beta;
    *c = -0.5f * alpha - 0.86602540378f * beta;
}

static void Reset(void)
{
    unsigned i;
    memset(adcFlags, 0, sizeof(adcFlags));
    memset(adcOverflows, 0, sizeof(adcOverflows));
    memset(adcResults, 0, sizeof(adcResults));
    adcResultReads = adcFlagClears = 0U;
    adcReadyCount = adcNotReadyCount = adcOverflowCount = 0U;
    adcZeroCalState = 2U;
    offgridFrequencyHz = OFFGRID_FREQ_HZ;
    offgridVoltagePeakSet = OFFGRID_VOLTAGE_PEAK_V;
    offgridVoltageRamp = OFFGRID_VOLTAGE_RAMP_V_S;
    offgridDcBusVoltage = OFFGRID_VDC_V;
    offgridLf = OFFGRID_LF_H;
    offgridRf = OFFGRID_RF_OHM;
    offgridCf = OFFGRID_CF_F;
    offgridCurrentLimit = OFFGRID_CURRENT_LIMIT_A;
    offgridOvercurrent = OFFGRID_OVERCURRENT_A;
    offgridOvervoltage = OFFGRID_OVERVOLTAGE_V;
    offgridModulationLimit = OFFGRID_MODULATION_LIMIT;
    offgridVoltageKp = OFFGRID_VOLTAGE_KP;
    offgridVoltageKi = OFFGRID_VOLTAGE_KI;
    offgridCurrentKp = OFFGRID_CURRENT_KP;
    offgridCurrentKi = OFFGRID_CURRENT_KI;
    ua_cap = ub_cap = uc_cap = 0.0f;
    ia_inv = ib_inv = ic_inv = 0.0f;
    ia_filter = ib_filter = ic_filter = 0.0f;
    PCC_ua = PCC_ub = PCC_uc = NAN; // Off-grid must not depend on PCC.
    FeedbackDq_Init();
    OffgridControl_Init();
    memset(hw, 0, sizeof(hw));
    memset(gpioValue, 0, sizeof(gpioValue));
    for(i = 1; i <= 7; i++) { hw[i].period = 7500U; hw[i].counter = 3750U; }
    PwmOutput_Init();
    assert(gpioValue[47] == 1U && gpioValue[48] == 1U && gpioValue[21] == 1U && pwmBufferEnabled == 0U);
}

static void TestAdcConsumption(void)
{
    unsigned i;
    Reset();
    for(i = 0U; i < 5U; i++) adcFlags[i] = true;
    adcResults[0][0] = 2000U;
    assert(AdcMeasurement_Acquire());
    assert(adcReadyMask == 31U && adcOverflowMask == 0U && adcResultReads == 16U && adcFlagClears == 5U);
    assert(adcA0Raw == 2000U);
    Near(ua_cap, (2000.0f - 1854.67798f) * (3.3f / 4096.0f * (20.0f / 3.0f) / 50.0f * 1000.0f * 1.0074f), 0.0001f);
    // The next conversion may finish during control math: old flags are gone.
    for(i = 0U; i < 5U; i++)
    {
        if(adcFlags[i]) adcOverflows[i] = true;
        adcFlags[i] = true;
        assert(!adcOverflows[i]);
    }
    adcResultReads = adcFlagClears = 0U;
    assert(AdcMeasurement_Acquire() && adcOverflowCount == 0U);

    for(i = 0U; i < 5U; i++) adcFlags[i] = true;
    adcOverflows[1] = true;
    adcResultReads = adcFlagClears = 0U;
    assert(!AdcMeasurement_Acquire());
    assert(adcReadyMask == 31U && adcOverflowMask == 2U && adcResultReads == 0U);
    assert(adcOverflowCount == 1U && adcNotReadyCount == 1U && !adcOverflows[1]);
    for(i = 0U; i < 5U; i++) assert(!adcFlags[i]);
    puts("PASS ADC result snapshot, early flag consumption, next-frame readiness and overflow rejection");
}

static void TestModulationAndPwm(void)
{
    int n;
    unsigned i;
    ThreeLevelDuty d;
    Reset();
    for(n = -100; n <= 100; n++)
    {
        float m = (float)n * 0.01f;
        ThreeLevelModulation_Map(m, &d);
        assert(d.upper >= 0.0f && d.upper <= 1.0f && d.lower >= 0.0f && d.lower <= 1.0f);
        Near(d.upper + d.lower - 1.0f, m, 0.000001f);
    }
    assert(PwmOutput_Update(false, 0.4f, -0.6f, 0.0f));
    assert(PwmOutput_Update(true, 0.4f, -0.6f, 0.0f));
    assert(gpioValue[47] == 0U && gpioValue[48] == 0U && gpioValue[21] == 1U && pwmBufferEnabled == 1U);
    assert(hw[1].compare[0] == 3000U && hw[1].force == EPWM_AQ_SW_DISABLED);
    assert(hw[2].force == EPWM_AQ_SW_OUTPUT_HIGH);
    assert(hw[3].force == EPWM_AQ_SW_OUTPUT_LOW && hw[4].compare[0] == 3000U);
    assert(hw[5].force == EPWM_AQ_SW_OUTPUT_LOW && hw[6].force == EPWM_AQ_SW_OUTPUT_HIGH);
    for(i = 1; i <= 7; i++) assert(hw[i].flags == (i == 7 ? EPWM_TZ_FLAG_OST : 0U));
    hw[4].flags = EPWM_TZ_FLAG_OST;
    assert(!PwmOutput_Update(true, 0.0f, 0.0f, 0.0f) && pwmOutputFault == 2U);
    assert(gpioValue[47] == 1U && gpioValue[48] == 1U && gpioValue[21] == 1U && pwmBufferEnabled == 0U);
    for(i = 1; i <= 7; i++) assert(hw[i].flags & EPWM_TZ_FLAG_OST);
    Reset();
    hw[1].counter = 100U;
    assert(!PwmOutput_Update(true, 0.0f, 0.0f, 0.0f) && pwmDeadlineMissCount == 1U);
    Reset();
    hw[6].period = 7000U;
    PwmOutput_Init();
    assert(!PwmOutput_Update(true, 0.0f, 0.0f, 0.0f));
    puts("PASS three-level mapping, duty endpoints, PWM7 isolation, buffer GPIO sequencing, breaker isolation, trip/deadline checks");
}

static void TestStateAndFaults(void)
{
    Reset();
    OffgridControl_Update(false);
    assert(offgridState == OFFGRID_STOPPED && offgridPwmPermit == 0U);
    offgridEnable = 1U;
    OffgridControl_Update(true);
    assert(offgridState == OFFGRID_ARMING && offgridPwmPermit == 0U);
    OffgridControl_Update(true);
    assert(offgridState == OFFGRID_RUNNING && offgridPwmPermit == 1U);
    OffgridControl_Update(false);
    assert(offgridState == OFFGRID_FAULT && offgridFaultCode == OFFGRID_FAULT_ADC && offgridPwmPermit == 0U);
    offgridFaultReset = 1U;
    OffgridControl_Update(true);
    assert(offgridState == OFFGRID_FAULT);
    offgridEnable = 0U;
    offgridFaultReset = 1U;
    OffgridControl_Update(true);
    assert(offgridState == OFFGRID_STOPPED && offgridFaultCode == 0U);
    offgridEnable = 1U;
    ia_inv = 41.0f;
    OffgridControl_Update(true);
    assert(offgridFaultCode == OFFGRID_FAULT_CURRENT);
    Reset(); offgridEnable = 1U; ua_cap = NAN;
    OffgridControl_Update(true);
    assert(offgridFaultCode == OFFGRID_FAULT_VOLTAGE);
    Reset(); offgridEnable = 1U; offgridDcBusVoltage = 20.0f;
    OffgridControl_Update(true);
    assert(offgridFaultCode == OFFGRID_FAULT_VDC);
    Reset(); offgridEnable = 1U; offgridVoltagePeakSet = 195.0f;
    OffgridControl_Update(true);
    assert(offgridFaultCode == OFFGRID_FAULT_CONFIG);
    puts("PASS startup, no-PCC operation, fault latching/reset and invalid feedback/configuration");
}

static void TestDecouplingAndLimits(void)
{
    float omega = OFFGRID_TWO_PI * 50.0f;
    float iq = 3.0f + omega * OFFGRID_CF_F * 100.0f;
    Reset();
    offgridEnable = 1U;
    offgridState = OFFGRID_RUNNING;
    offgridVoltagePeakSet = offgridVoltagePeakRamp = 100.0f;
    SetAbc(100.0f, 0.0f, &ua_cap, &ub_cap, &uc_cap);
    SetAbc(2.0f, 3.0f, &ia_filter, &ib_filter, &ic_filter);
    SetAbc(2.0f, iq, &ia_inv, &ib_inv, &ic_inv);
    OffgridControl_Update(true);
    Near(offgridIdRef, 2.0f, 0.0001f);
    Near(offgridIqRef, iq, 0.0001f);
    Near(offgridUdRef, 100.0f + OFFGRID_RF_OHM * 2.0f - omega * OFFGRID_LF_H * iq, 0.001f);
    Near(offgridUqRef, OFFGRID_RF_OHM * iq + omega * OFFGRID_LF_H * 2.0f, 0.001f);
    Reset();
    offgridEnable = 1U;
    offgridCurrentLimit = 0.2f;
    SetAbc(5.0f, 5.0f, &ia_filter, &ib_filter, &ic_filter);
    OffgridControl_Update(true);
    assert(offgridCurrentLimited == 1U);
    assert(hypotf(offgridIdRef, offgridIqRef) <= 0.20001f);
    Reset();
    offgridEnable = 1U;
    offgridCurrentKp = 100.0f;
    SetAbc(-10.0f, -10.0f, &ia_inv, &ib_inv, &ic_inv);
    OffgridControl_Update(true);
    assert(hypotf(offgridUdRef, offgridUqRef) <= 190.001f);
    assert(fabsf(offgridMa) <= 0.95001f && fabsf(offgridMb) <= 0.95001f && fabsf(offgridMc) <= 0.95001f);
    offgridEnable = 0U;
    OffgridControl_Update(true);
    Near(offgridPiId.ui, 0.0f, 0.0f);
    Near(offgridVoltagePeakRamp, 0.0f, 0.0f);
    puts("PASS dq cross-coupling signs, current/voltage vector limits and disable reset");
}

static void PlantStep(float *current, float *voltage, float drive, float resistance, float h)
{
    float i = *current, v = *voltage;
    float a1 = (drive - v - OFFGRID_RF_OHM * i) / OFFGRID_LF_H;
    float b1 = (i - v / resistance) / OFFGRID_CF_F;
    float a2 = (drive - (v + h * b1 * 0.5f) - OFFGRID_RF_OHM * (i + h * a1 * 0.5f)) / OFFGRID_LF_H;
    float b2 = (i + h * a1 * 0.5f - (v + h * b1 * 0.5f) / resistance) / OFFGRID_CF_F;
    float a3 = (drive - (v + h * b2 * 0.5f) - OFFGRID_RF_OHM * (i + h * a2 * 0.5f)) / OFFGRID_LF_H;
    float b3 = (i + h * a2 * 0.5f - (v + h * b2 * 0.5f) / resistance) / OFFGRID_CF_F;
    float a4 = (drive - (v + h * b3) - OFFGRID_RF_OHM * (i + h * a3)) / OFFGRID_LF_H;
    float b4 = (i + h * a3 - (v + h * b3) / resistance) / OFFGRID_CF_F;
    *current += h * (a1 + 2.0f * a2 + 2.0f * a3 + a4) / 6.0f;
    *voltage += h * (b1 + 2.0f * b2 + 2.0f * b3 + b4) / 6.0f;
}

static void TestClosedLoopPlant(void)
{
    unsigned k, sub, samples = 0;
    float ia = 0.0f, ib = 0.0f, va = 0.0f, vb = 0.0f;
    float driveA = 0.0f, driveB = 0.0f;
    float peakError = 0.0f;
    double sumSquares = 0.0;
    Reset();
    offgridEnable = 1U;
    for(k = 0; k < 35000; k++)
    {
        float resistance = (k < 20000) ? 50.0f : 12.0f;
        float nextDriveA, nextDriveB;
        SetAbc(va, vb, &ua_cap, &ub_cap, &uc_cap);
        SetAbc(ia, ib, &ia_inv, &ib_inv, &ic_inv);
        SetAbc(va / resistance, vb / resistance, &ia_filter, &ib_filter, &ic_filter);
        OffgridControl_Update(true);
        if(offgridState == OFFGRID_FAULT)
        {
            fprintf(stderr, "Plant fault at sample %u: %u, V=(%g,%g), I=(%g,%g)\n", k, offgridFaultCode, va, vb, ia, ib);
            exit(1);
        }
        nextDriveA = offgridMa * OFFGRID_VDC_V * 0.5f;
        nextDriveB = (offgridMb - offgridMc) * OFFGRID_VDC_V * 0.28867513459f;
        if(offgridPwmPermit == 0U) nextDriveA = nextDriveB = 0.0f;
        // One sample delay: the present command loads at the next PWM zero.
        for(sub = 0; sub < 20; sub++)
        {
            PlantStep(&ia, &va, driveA, resistance, OFFGRID_TS_S / 20.0f);
            PlantStep(&ib, &vb, driveB, resistance, OFFGRID_TS_S / 20.0f);
        }
        driveA = nextDriveA;
        driveB = nextDriveB;
        if(k >= 30000)
        {
            float error = fabsf(hypotf(va, vb) - OFFGRID_VOLTAGE_PEAK_V);
            if(error > peakError) peakError = error;
            sumSquares += (double)va * va;
            samples++;
        }
    }
    printf("Plant: startup + 50-to-12 ohm step, phase RMS %.4f V, worst final amplitude error %.4f V\n", sqrt(sumSquares / samples), peakError);
    assert(peakError < OFFGRID_VOLTAGE_PEAK_V * 0.03f);
    Near((float)sqrt(sumSquares / samples), OFFGRID_VOLTAGE_PEAK_V * 0.70710678f, 3.0f);
}

int main(void)
{
    TestAdcConsumption();
    TestModulationAndPwm();
    TestStateAndFaults();
    TestDecouplingAndLimits();
    TestClosedLoopPlant();
    puts("ALL OFFGRID HOST TESTS PASSED");
    return 0;
}
