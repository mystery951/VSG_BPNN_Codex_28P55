#include "grid_pll.h"
#include "ABC_DQ0_POS_F.h"
#include "ABC_DQ0_NEG_F.h"
#include "app/system_config.h"
#include <math.h>

SPLL_3ph_DDSRF_F SPLL_GRID;
static ABC_DQ0_POS_F DQ0_POS_REF;
static ABC_DQ0_NEG_F DQ0_NEG_REF;

volatile uint16_t gridPllValid = 0U;
volatile float grid_theta = 0.0f;
static bool hadPcc = false;

static void ResetLoop(void)
{
    ABC_DQ0_POS_F_init(&DQ0_POS_REF);
    ABC_DQ0_NEG_F_init(&DQ0_NEG_REF);

    SPLL_3ph_DDSRF_F_init(50,0.0001f,0.00933678f,-0.9813264f,&SPLL_GRID);

    SPLL_GRID.fo = 50.0f;
    SPLL_GRID.sin_2theta = 0.0f;
    SPLL_GRID.cos_2theta = 1.0f;
}

void GridPll_Init(void)
{
    gridPllValid = 0U;
    grid_theta = 0.0f;
    hadPcc = false;
    ResetLoop();
}

void GridPll_Update(float ua, float ub, float uc, bool enabled)
{
    float theta;
    float sinTheta;
    float cosTheta;
    float alpha = 0.6666666667f * (ua - 0.5f * (ub + uc));
    float beta = 0.57735026913f * (ub - uc);

    gridPllValid = 0U;
    // Missing PCC is not a fault; reset stale PLL states once when it returns.
    if(!enabled || !(alpha * alpha + beta * beta > GRID_MIN_PEAK_V * GRID_MIN_PEAK_V))
    {
        hadPcc = false;
        return;
    }
    if(!hadPcc) ResetLoop();
    hadPcc = true;
    gridPllValid = 1U;
    theta = SPLL_GRID.theta[0];
    grid_theta = theta;
    sinTheta = sinf(theta);
    cosTheta = cosf(theta);

    // 正序坐标变换
    DQ0_POS_REF.a = ua;
    DQ0_POS_REF.b = ub;
    DQ0_POS_REF.c = uc;
    DQ0_POS_REF.sin_val = sinTheta;
    DQ0_POS_REF.cos_val = cosTheta;
    ABC_DQ0_POS_F_FUNC(&DQ0_POS_REF);

    // 负序坐标变换
    DQ0_NEG_REF.a = ua;
    DQ0_NEG_REF.b = ub;
    DQ0_NEG_REF.c = uc;
    DQ0_NEG_REF.sin_val = sinTheta;
    DQ0_NEG_REF.cos_val = cosTheta;
    ABC_DQ0_NEG_F_FUNC(&DQ0_NEG_REF);

    SPLL_GRID.d_p = DQ0_POS_REF.d;
    SPLL_GRID.q_p = DQ0_POS_REF.q;
    SPLL_GRID.d_n = DQ0_NEG_REF.d;
    SPLL_GRID.q_n = DQ0_NEG_REF.q;

    SPLL_GRID.sin_2theta = 2.0f * sinTheta * cosTheta;
    SPLL_GRID.cos_2theta = cosTheta * cosTheta - sinTheta * sinTheta;

    SPLL_3ph_DDSRF_F_FUNC(&SPLL_GRID);
}
