#include "ann_adaptive.h"
#include "ann_models.h"
#include "driverlib.h"
#include <math.h>

typedef struct { float Q, angle; uint32_t session; } ANN_INPUT;

volatile ANN_ADAPTIVE_DEF ANN_CTRL = {0};
static volatile ANN_INPUT pending;
static volatile uint32_t session;
static volatile bool active;
static float qSum, angleSum;
static uint32_t appliedResult;

void AnnAdaptive_Init(void)
{
    const ANN_ADAPTIVE_DEF zero = {0};
    ANN_CTRL = zero;
    session = 0U;
    active = false;
    qSum = angleSum = 0.0f;
    appliedResult = 0U;
}

void AnnAdaptive_Sample(bool enabled, float Q, float angle)
{
    if(!enabled)
    {
        if(active) session++; // Cancel inference started in the previous session.
        active = false;
        ANN_CTRL.ann_cnt = ANN_CTRL.ann_run_flag = ANN_CTRL.result_valid = 0U;
        qSum = angleSum = 0.0f;
        return;
    }
    active = true;
    qSum += Q;
    angleSum += angle;
    ANN_CTRL.ann_cnt++;
    if(ANN_CTRL.ann_cnt >= ANN_AVERAGE_SAMPLES)
    {
        // Latest complete window wins if the background has not taken the old one.
        pending.Q = qSum / (float)ANN_AVERAGE_SAMPLES;
        pending.angle = angleSum / (float)ANN_AVERAGE_SAMPLES;
        pending.session = session;
        ANN_CTRL.ann_run_flag = 1U;
        ANN_CTRL.ann_cnt = 0U;
        qSum = angleSum = 0.0f;
    }
}

void AnnAdaptive_Service(void)
{
    ANN_INPUT input;
    float L, R, J, D;
    bool wasDisabled, inputOk, impedanceOk, valid;
    // Do not call this service from an ISR or with interrupts deliberately masked.
    if(ANN_CTRL.ann_run_flag == 0U) return;
    wasDisabled = Interrupt_disableGlobal();
    if(wasDisabled) return; // Leave the caller's mask unchanged; defer expensive work.
    if(ANN_CTRL.ann_run_flag == 0U)
    {
        Interrupt_enableGlobal();
        return;
    }
    input.Q = pending.Q;
    input.angle = pending.angle;
    input.session = pending.session;
    ANN_CTRL.ann_run_flag = 0U;
    Interrupt_enableGlobal();

    // No clipping or retraining: these are the original two numerical models.
    ANN_ConstV_Predict(input.Q, input.angle, &L, &R);
    VSG_JD_ANN2_Predict(R, L / 1000.0f, &J, &D);
    inputOk = ANN_InputInRange(input.Q, input.angle);
    impedanceOk = ANN_ImpedanceInRange(L, R);
    valid = inputOk && impedanceOk && isfinite(J) && isfinite(D) && J > 0.0f && D > 0.0f;

    wasDisabled = Interrupt_disableGlobal();
    if(active && input.session == session)
    {
        ANN_CTRL.ann_Q_input = input.Q;
        ANN_CTRL.ann_Angle_input = input.angle;
        ANN_CTRL.L_est = L;
        ANN_CTRL.R_est = R;
        ANN_CTRL.J_apt = J;
        ANN_CTRL.D_apt = D;
        ANN_CTRL.input_in_range = inputOk ? 1U : 0U;
        ANN_CTRL.impedance_in_range = impedanceOk ? 1U : 0U;
        ANN_CTRL.result_valid = valid ? 1U : 0U;
        ANN_CTRL.inference_count++;
    }
    if(!wasDisabled) Interrupt_enableGlobal();
}

bool AnnAdaptive_Apply(volatile VSG_PARAM *cfg, bool automatic, bool manual)
{
    uint16_t div = cfg->power_loop_div > 0U ? cfg->power_loop_div : 1U;
    float J = ANN_CTRL.J_apt, D = ANN_CTRL.D_apt;
    if(!active || ANN_CTRL.result_valid != 1U || (!automatic && !manual)) return false;
    if(!manual && appliedResult == ANN_CTRL.inference_count) return false;
    // Minimum Euler damping condition: 0 < D*Ts/J < 2. Not a plant stability proof.
    if(!(J > 0.0f && D > 0.0f && D * CONTROL_TS * (float)div < 2.0f * J)) return false;
    cfg->h = J * 0.5f; // Old J_apt is m_pu=2H, NOT H or unscaled kg*m^2.
    cfg->dp_pu = D;
    appliedResult = ANN_CTRL.inference_count;
    ANN_CTRL.apply_count++;
    return true;
}
