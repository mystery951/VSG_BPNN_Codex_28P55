#ifndef ANN_ADAPTIVE_H_
#define ANN_ADAPTIVE_H_

#include <stdbool.h>
#include <stdint.h>
#include "app/inverter_settings.h"

#define ANN_AVERAGE_SAMPLES 100U

typedef struct
{
    uint16_t ann_cnt, ann_run_flag, result_valid, input_in_range, impedance_in_range;
    float ann_Q_input, ann_Angle_input;
    float L_est, R_est, J_apt, D_apt;
    uint32_t inference_count, apply_count;
} ANN_ADAPTIVE_DEF;

// Read-only monitoring. Operator inputs stay in INV_CMD.
extern volatile ANN_ADAPTIVE_DEF ANN_CTRL;
void AnnAdaptive_Init(void);
// ISR: collect one eligible Q(var)/virtual-angle(deg) pair per control tick.
void AnnAdaptive_Sample(bool enabled, float Q, float angle);
// Main loop only: short atomic mailboxes, interruptible FP32 inference.
void AnnAdaptive_Service(void);
// ISR only. Manual can reapply a valid result; automatic applies each new one once.
bool AnnAdaptive_Apply(volatile VSG_PARAM *cfg, bool automatic, bool manual);

#endif
