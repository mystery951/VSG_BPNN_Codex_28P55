#include "vsg.h"
#include "app/math/pi_controller.h"
#include <math.h>

volatile VSG_DEF VSG_CTRL = {0};
static PI_POS_DEF PI_QV;

void VSG_Reset(volatile VSG_DEF *v)
{
    v->omega_m = v->omega_m_pu = v->omega_sync = 0.0f;
    v->virtual_angle_int = v->virtual_angle_rad = v->virtual_angle_deg = 0.0f;
    v->power_loop_cnt = 0U;
    PI_Pos_Reset(&PI_QV);
}

void VSG_Init(volatile VSG_DEF *v)
{
    VSG_Reset(v);
    v->omega0 = v->v_nom = v->v_delta_pu = 0.0f;
    PI_Pos_Init(&PI_QV, 0.0f, 0.0f, VSG_QV_LIMIT_PU, -VSG_QV_LIMIT_PU);
}

void VSG_EnterGrid(volatile VSG_DEF *v, const volatile VSG_PARAM *cfg, float omega0, float omegaSync, float voltage, float qError)
{
    VSG_Reset(v);
    v->omega0 = omega0;
    v->omega_sync = omegaSync;
    v->v_nom = voltage;
    v->v_delta_pu = 0.0f;
    PI_QV.kp = cfg->Kp_QV;
    PI_QV.ki = cfg->Ki_QV;
    PI_QV.ui = -cfg->Kp_QV * qError;
}

float VSG_PowerLoop(volatile VSG_DEF *v, const volatile VSG_PARAM *cfg, float pRef, float qRef, float pe, float qe, float voltageMax, float Ts)
{
    float deviationMax, voltage;
    v->omega_m_pu += (pRef - pe - cfg->dp_pu * v->omega_m_pu) * Ts / (2.0f * cfg->h);
    deviationMax = cfg->omega_limit / v->omega0;
    if(v->omega_m_pu > deviationMax) v->omega_m_pu = deviationMax;
    if(v->omega_m_pu < -deviationMax) v->omega_m_pu = -deviationMax;
    v->omega_m = v->omega_m_pu * v->omega0;
    PI_QV.kp = cfg->Kp_QV;
    PI_QV.ki = cfg->Ki_QV;
    v->v_delta_pu = PI_Pos_Cal(&PI_QV, qRef - qe, Ts);
    voltage = v->v_nom + v->v_delta_pu * SYS_V_BASE_V;
    if(voltageMax > cfg->v_max) voltageMax = cfg->v_max;
    if(voltage > voltageMax) voltage = voltageMax;
    if(voltage < cfg->v_min) voltage = cfg->v_min;
    return voltage;
}

void VSG_VirtualAngleStep(volatile VSG_DEF *v, float omegaP, float Ts, bool enabled)
{
    if(!enabled)
    {
        v->virtual_angle_int = v->virtual_angle_rad = v->virtual_angle_deg = 0.0f;
        return;
    }
    if(omegaP <= 0.015f && omegaP >= -0.015f) omegaP = 0.0f;
    v->virtual_angle_int += omegaP * Ts;
    v->virtual_angle_rad = atan2f(sinf(v->virtual_angle_int), cosf(v->virtual_angle_int));
    v->virtual_angle_deg = v->virtual_angle_rad * 57.29577951308232f;
}
