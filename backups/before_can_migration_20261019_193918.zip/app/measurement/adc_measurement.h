#ifndef ADC_MEASUREMENT_H_
#define ADC_MEASUREMENT_H_

#include <stdbool.h>
#include <stdint.h>

extern volatile uint16_t adcA0Raw, adcA5Raw, adcA12Raw;
extern volatile uint16_t adcB1Raw, adcB8Raw, adcB10Raw;
extern volatile uint16_t adcC4Raw, adcC8Raw, adcC14Raw;
extern volatile uint16_t adcD11Raw, adcD12Raw; // D12 = P_filter.
extern volatile uint16_t adcE12Raw, adcE15Raw;

extern volatile float Va_cap, Vb_cap, Vc_cap;
extern volatile float PCC_ua, PCC_ub, PCC_uc;
extern volatile float Ia_inv, Ib_inv, Ic_inv;
extern volatile float Ia_filter, Ib_filter, Ic_filter;
extern volatile float P_filter; // D12 power measurement, W (not per-unit).

// Read thirteen inputs and apply fixed V/I/power offsets and scales.
void AdcMeasurement_Acquire(void);

#endif
