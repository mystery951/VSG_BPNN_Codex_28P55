#include "inner_loop.h"
#include "feedback_dq.h"
#include "presync.h"
#include <math.h>

volatile uint16_t offgridEnable = 0U;
volatile uint32_t offgridRunCount = 0U;
volatile float f_ref = 50.0f, omega = 314.15926536f, colse_loop_theta = 0.0f;
volatile float Vdc = 400.0f, Lf = 0.002f, Cf = 0.000012f;
volatile float Vd_ref = 155.56f, Vq_ref = 0.0f;
volatile float id_ref = 0.0f, iq_ref = 0.0f, ud_ref = 0.0f, uq_ref = 0.0f;
volatile float VaRef = 0.0f, VbRef = 0.0f, VcRef = 0.0f;
// Keep the last tuning; names now match the F28377 project.
volatile float Kpu = 0.7f, Kiu = 0.5f;
volatile float Kpi = 1.5f, Kii = 0.0f;
volatile float U_UpLimit = 300.0f, I_UpLimit = 100.0f;
PI_POS_DEF PI_UD, PI_UQ, PI_ID, PI_IQ;

static float Limit(float value, float limit)
{
    if(value > limit) value = limit;
    if(value < -limit) value = -limit;
    return value;
}

void CloseLoop_Init(void)
{
    PI_Pos_Init(&PI_UD, Kpu, Kiu, U_UpLimit, -U_UpLimit);
    PI_Pos_Init(&PI_UQ, Kpu, Kiu, U_UpLimit, -U_UpLimit);
    PI_Pos_Init(&PI_ID, Kpi, Kii, I_UpLimit, -I_UpLimit);
    PI_Pos_Init(&PI_IQ, Kpi, Kii, I_UpLimit, -I_UpLimit);
    offgridEnable = 0U;
}

void InnerLoop_Update(void)
{
    float thetaPwm, sine, cosine, alpha, beta;
    FeedbackDq_Update(colse_loop_theta);
    Presync_Calc(&PRESYNC_CTRL, CONTROL_TS);
    omega = TWO_PI * f_ref + PRESYNC_CTRL.omega_sync;
    if(offgridEnable != 1U)
    {
        PI_Pos_Reset(&PI_UD);
        PI_Pos_Reset(&PI_UQ);
        PI_Pos_Reset(&PI_ID);
        PI_Pos_Reset(&PI_IQ);
        colse_loop_theta = 0.0f;
        id_ref = iq_ref = ud_ref = uq_ref = 0.0f;
        VaRef = VbRef = VcRef = 0.0f;
        return;
    }

    PI_UD.kp = PI_UQ.kp = Kpu;
    PI_UD.ki = PI_UQ.ki = Kiu;
    PI_ID.kp = PI_IQ.kp = Kpi;
    PI_ID.ki = PI_IQ.ki = Kii;
    PI_UD.uplimit = PI_UQ.uplimit = U_UpLimit;
    PI_UD.lolimit = PI_UQ.lolimit = -U_UpLimit;
    PI_ID.uplimit = PI_IQ.uplimit = I_UpLimit;
    PI_ID.lolimit = PI_IQ.lolimit = -I_UpLimit;

    // Voltage PI + load-current feedforward + capacitor cross coupling.
    id_ref = PI_Pos_Cal(&PI_UD, Vd_ref - Vd_cap, CONTROL_TS) + Id_filter - omega * Cf * Vq_cap;
    iq_ref = PI_Pos_Cal(&PI_UQ, Vq_ref - Vq_cap, CONTROL_TS) + Iq_filter + omega * Cf * Vd_cap;
    id_ref = Limit(id_ref, U_UpLimit);
    iq_ref = Limit(iq_ref, U_UpLimit);

    // Current PI + capacitor-voltage feedforward + inductor cross coupling.
    // d uses Iq_inv, q uses Id_inv (corrected from the old project).
    ud_ref = PI_Pos_Cal(&PI_ID, id_ref - Id_inv, CONTROL_TS) + Vd_cap - omega * Lf * Iq_inv;
    uq_ref = PI_Pos_Cal(&PI_IQ, iq_ref - Iq_inv, CONTROL_TS) + Vq_cap + omega * Lf * Id_inv;
    ud_ref = Limit(ud_ref * 2.0f / Vdc, 0.95f);
    uq_ref = Limit(uq_ref * 2.0f / Vdc, 0.95f);

    // Sample at PWM zero; calculated shadows take effect at the next zero.
    thetaPwm = colse_loop_theta + omega * CONTROL_TS;
    if(thetaPwm >= TWO_PI) thetaPwm -= TWO_PI;
    sine = sinf(thetaPwm);
    cosine = cosf(thetaPwm);
    alpha = ud_ref * cosine - uq_ref * sine;
    beta = ud_ref * sine + uq_ref * cosine;
    VaRef = Limit(alpha, 0.95f);
    VbRef = Limit(-0.5f * alpha + 0.86602540378f * beta, 0.95f);
    VcRef = Limit(-0.5f * alpha - 0.86602540378f * beta, 0.95f);
    colse_loop_theta = thetaPwm;
    offgridRunCount++;
}
