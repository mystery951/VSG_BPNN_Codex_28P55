$ErrorActionPreference = 'Stop'
$projectPath = Split-Path -Parent $PSScriptRoot
$vswherePath = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
$vsInstallPath = & $vswherePath -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if(-not $vsInstallPath) { throw 'MSVC C compiler is required for host tests.' }
$vcvarsPath = Join-Path $vsInstallPath 'VC\Auxiliary\Build\vcvars64.bat'
$buildCheckPath = Join-Path ([System.IO.Path]::GetTempPath()) ('vsg-offgrid-host-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $buildCheckPath | Out-Null
$sources = @('tests/offgrid_host_test.c', 'app/measurement/adc_measurement.c', 'app/control/inner_loop.c', 'app/control/presync.c', 'app/control/pi_controller.c', 'app/control/feedback_dq.c', 'app/control/three_level_modulation.c', 'app/control/pwm_output.c', 'app/PLL/grid_pll.c', 'app/PLL/ABC_DQ0_POS_F.c', 'app/PLL/ABC_DQ0_NEG_F.c', 'app/PLL/SPLL_3ph_DDSRF_F.c')
$quotedSources = ($sources | ForEach-Object { '"' + (Join-Path $projectPath $_) + '"' }) -join ' '
$buildCommand = 'call "' + $vcvarsPath + '" >nul && cd /d "' + $buildCheckPath + '" && cl.exe /nologo /std:c17 /utf-8 /W3 /Od /I"' + (Join-Path $PSScriptRoot 'stubs') + '" /I"' + $projectPath + '" ' + $quotedSources + ' /Fe:offgrid_host_test.exe'
& $env:ComSpec /d /s /c $buildCommand
if($LASTEXITCODE -ne 0) { throw 'Host test build failed.' }
& (Join-Path $buildCheckPath 'offgrid_host_test.exe')
if($LASTEXITCODE -ne 0) { throw 'Host tests failed.' }
Write-Output "Host test executable: $buildCheckPath"
