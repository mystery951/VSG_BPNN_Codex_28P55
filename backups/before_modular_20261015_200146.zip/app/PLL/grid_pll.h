#ifndef GRID_PLL_H_
#define GRID_PLL_H_

#include <stdint.h>
#include <stdbool.h>
#include "ABC_DQ0_POS_F.h"
#include "ABC_DQ0_NEG_F.h"
#include "SPLL_3ph_DDSRF_F.h"

extern SPLL_3ph_DDSRF_F SPLL_GRID;
extern ABC_DQ0_POS_F DQ0_POS_REF;
extern ABC_DQ0_NEG_F DQ0_NEG_REF;
extern volatile uint16_t gridPllEnable;
extern volatile uint32_t gridPllRunCount;
extern volatile uint16_t gridPllValid;
extern volatile float grid_theta; // Sample-time angle; theta[0] advances one Ts.

void GridPll_Init(void);
// Inputs are physical volts; normalization remains inside the existing PLL.
void GridPll_Update(float ua, float ub, float uc);

#endif
