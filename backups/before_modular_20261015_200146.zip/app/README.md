# F28P55 VF / 预同步 / 手动并网VSG（仅用于半实物调试）

控制入口为 `epwm1_isr()`，每 100 us 执行：
ADC 原始码 → 固定零偏/物理量换算 → PCC锁相 → abc/dq → 预同步/手动并网模式选择 → VSG功率环（仅并网）→ 电压 PI → 电流 PI → dq/abc → 三电平调制 → PWM。

| 文件 | 内容 |
|---|---|
| measurement/adc_measurement.c | ADC读取、12路电压/电流换算 |
| measurement/adc_calibration.h | 保留实测固定零偏及比例系数 |
| control/feedback_dq.c | 电容电压、逆变侧电流、负载侧电流的dq变换 |
| control/inner_loop.c | 独立50Hz相角、四个基础位置式PI、前馈解耦、反变换 |
| control/pi_controller.c | 与28377旧工程一致的基础PI积分/输出限幅 |
| control/three_level_modulation.c | 三电平载波层叠占空比 |
| control/pwm_output.c | EPWM1~6输出，GPIO48/47低有效使能，GPIO21仅在手动并网被接受后输出1 |
| control/vsg.c/.h | VSG_CTRL、5000功率基准、pu有功惯量/阻尼、pu Q-V PI、连续相角 |
| control/inverter_state.c/.h | INV_CTRL手动并网模式切换及同步/三相差压准入，无故障状态机 |
| control/presync.c/.h | PRESYNC_CTRL相角PI、电压幅值跟踪及同步就绪标志，不自动合闸 |
| PLL/grid_pll.c/.h | PCC锁相，沿用旧工程SPLL_GRID、DQ0_POS_REF等命名 |
| isr/control_isr.c | 采样→计算→输出，无故障状态机 |

未改动SysConfig的采样触发、PWM同步、死区和引脚配置。
PLL已恢复初始化和运行；gridPllEnable默认1，PRESYNC_CTRL.enable默认0，不影响原离网给定。
旧current_loop单环测试、trip_test、offgrid_config及故障诊断代码已删除。
修改前源码/工程配置备份：../backups/before_basic_20261015_153034.zip。

离网操作见 control/OFFGRID_START.md；预同步操作见 control/PRESYNC_START.md；手动并网与VSG操作见 control/GRID_VSG_START.md。
功率基准5000，p_ref/q_ref使用pu；电压/电流双环继续使用V/A。默认功率给定0，不自动合闸。
该版本没有过流/过压/采样失败/超时/防孤岛保护，不用于功率硬件带电实验。

本次验证：当前SysConfig生成0错误（1条通用Device Support建议）；TI 25.11.0.LTS、F28P55、FPU32/TMU1、-O2/relaxed的RAM全源码编译链接通过。
主机测试全部通过；平均LC模型中20 V、155.56 V峰值给定及50→12欧姆负载变化可跟踪。
尚未下载到板卡，实际ISR耗时与半实物波形需重新验证。

手动并网/VSG版本验证：CPU1_RAM及CPU1_LAUNCHXL_RAM两种配置TI全源码编译链接通过；
主机49/50/51 Hz同步→手动合闸→VSG切换连续，500→1000 W理想电抗并网模型功率阶跃通过。
该模型不是实际LC双环和接触器的并网动态验证；正式半实物实验仍需观察电流及ISR时序。
本次修改前备份：../backups/before_grid_vsg_20261015_171502.zip。
