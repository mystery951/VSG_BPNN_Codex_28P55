# 半实物手动并网与VF→VSG切换

## 范围

这是半实物功能验证版本，不是具备并网认证或完整保护的功率硬件控制软件。
“就绪”仅指本工程的软件同步条件成立；没有过流/过压/防孤岛、接触器动作延迟预测或真实触点反馈。
并网后PCC失电不会自动开闸，不能用该版本直接做实际电网带电试验。

## 沿用的旧工程结构

- vsg.c/.h：VSG_DEF、VSG_CTRL、PI_QV、Kp_QV/Ki_QV、VSG_Init/PowerLoop/AngleStep、VF_AngleStep。
- inverter_state.c/.h：INV_CTRL、grid_connect_cmd、grid_zero_cross_ok，只有运行模式，无故障状态机。
- system_config.h：SYS_S_BASE_VA=5000，SYS_V_BASE_V=155.56（相电压峰值）。
- 原offgridEnable继续作为所有模式的总PWM使能，不另加重复的run_enable。
- 原PRESYNC_CTRL.enable继续作为预同步请求，不另加重复的presync_request。
- ADC、物理量换算、双环整定和EPWM5/6的C相映射不变。
- GPIO21：0=断路器断开，1=闭合；GPIO48/47仍低有效使能PWM缓冲器。

状态值（仅观察，不手动改state）：
0 INV_STANDBY；1 INV_OFFGRID_VF；2 INV_PRESYNC；3 INV_GRID_READY；4 INV_GRID_CONNECTED。
旧工程INV_OFFGRID_VSG的名称在此改为INV_OFFGRID_VF，反映当前真正运行的VF模式。

## 第一次调试顺序

1. CCS刷新工程，Clean/Rebuild正在使用的RAM配置；确认vsg.c和inverter_state.c参与编译，下载新out。
   offgridEnable=0，INV_CTRL.grid_connect_cmd=0，PRESYNC_CTRL.enable=0。
   确认GPIO21=0（平台断路器断开）、GPIO48/47=1。
2. 检查Vdc/Lf/Cf及固定零偏与已验证离网配置一致，Vq_ref保持0；平台使用正确的PCC三相正相序。
   首次并网将VSG_CTRL.p_ref=0、VSG_CTRL.q_ref=0，避免一次给入大功率阶跃。
   设置offgridEnable=1，先确认VF运行；再设PRESYNC_CTRL.enable=1，完成原预同步操作。
3. 等待PRESYNC_CTRL.sync_ready=1、INV_CTRL.state=3、INV_CTRL.grid_zero_cross_ok=1。
   同时在平台查看两侧三相电压、相位和频率；不要仅靠一个软件标志判断物理硬件安全。
4. 手动设置INV_CTRL.grid_connect_cmd=1。
   代码用当前拍的同步结果重新判断，不采用上一拍遗留的sync_ready。
   条件成立：state=4，GPIO21=1；保持PWM输出，切换到VSG功率控制，预同步环退出。
   条件不成立：grid_connect_cmd自动回0，grid_connect_rejected=1，不排队、不延迟自动合闸。
   排除原因并重新达到state=3后，再手动置1。拒绝标志在成功接受或总停机时清零。
5. 并网稳定后，先测试VSG_CTRL.p_ref=0.1（500 W），再测试0.2（1000 W）。
   观察Pe、Pe_pu、Qe、Qe_pu、VSG_CTRL.omega_m、omega、Vd_ref和平台电流。
   初始Q-V是下垂控制，不保证稳态Q精确等于q_ref；需要闭环调参后再考虑启用Ki_QV。
6. 开闸返回VF：INV_CTRL.grid_connect_cmd=0，GPIO21回0，PWM继续运行。
   相角/电压保持；f_ref自动接续开闸前的实际输出频率，避免频率突变（例如可能从50变为49）。
   不自动重启预同步，不自动重合闸；需要再次预同步时重新置PRESYNC_CTRL.enable=1。
7. 总停机：offgridEnable=0，下一控制中断开闸、关闭PWM缓冲器并封锁PWM。
   并网命令和预同步请求清零。p_ref/q_ref是用户给定，停机不会覆盖；重启前请自行设为所需值。
   停机后的再次运行仍从VF开始，必须重新预同步并手动并网。

INV_GRID_CONNECTED表示软件已接受并输出合闸命令，不表示已经读取到真实接触器闭合反馈。

## 合闸软件判据

- PRESYNC_CTRL.enable=1且当前同步条件连续满足：
  相角差小于约5度、频差小于0.5 Hz、幅值差小于10 V峰值；
  同时检查实际电容电压相位和PLL正序有效性，详见PRESYNC_START.md。
- gridPllValid=1，总PWM使能为1。
- 三相瞬时差压都小于grid_zero_cross_threshold，默认0.05*155.56=7.778 V。
  Va_sync_diff=PCC_ua-Va_cap，B/C同理；全部使用真实伏特。
- 旧名称grid_zero_cross_ok在这里表示“三相差压均足够小”，不是只检测A相电网过零。
  也没有照搬旧工程真实电压与0.05直接比较的单位错误。
- 就绪标志不会自行合闸，必须有手动grid_connect_cmd=1。

这些是半实物调试判据，不声称满足某个国家/地区正式并网标准。

## VF→VSG连续切换

合闸时执行VSG_EnterGrid：
- VSG_CTRL.theta=colse_loop_theta。该相角已经包含预同步期间积分得到的全部相位补偿。
  不能再把PLL角度或所谓相角补偿重复加上去，否则会跳相。
- VSG_CTRL.omega_sync锁存当拍PRESYNC_CTRL.omega_sync，随后保持不变。
  不照搬旧工程固定-0.0265 rad/s的临时调试值。
- VSG_CTRL.omega_m及omega_m_pu初值为0。
  并网首拍频率与预同步末拍连续，之后omega=omega0+omega_sync+omega_m。
- VSG_CTRL.v_nom/v_ref接续当前Vd_ref，Q-V PI预置积分状态抵消初始比例项。
- 不复位四个电压/电流环PI。并网首拍跳过一次功率更新，随后按设定周期执行功率环。
- PLL并网后仅继续监视，不再直接操纵VSG角度；预同步PRESYNC_CTRL.omega_sync清零，
  其最终补偿已保存在VSG_CTRL.omega_sync中。PRESYNC_CTRL.sync_ready清零是正常的。

## 标幺量和真实值

| 变量 | 单位/含义 |
|---|---|
| Va_cap等采样、Vd_cap/Vq_cap | V，未标幺化 |
| Ia_inv等采样、Id_inv/Id_filter等 | A，未标幺化 |
| Vd_ref/VSG_CTRL.v_ref/v_nom/v_delta | V，相电压峰值 |
| Pe/Qe | W/var，沿用电容电压与滤波电流测量边界 |
| Pe_pu/Qe_pu、VSG_CTRL.p_ref/q_ref | pu，统一基准5000 |
| VSG_CTRL.omega_m_pu | omega_m/omega0，pu频率偏移 |
| omega、omega0、omega_m、omega_sync | rad/s |
| PI_QV输出、VSG_CTRL.v_delta_pu | pu电压调节量，乘155.56才变成真实V |
| ud_ref/uq_ref、VaRef/VbRef/VcRef | 原PWM归一化调制量，接口不变 |

沿用旧工程功率符号：
Pe=1.5*(Vd_cap*Id_filter+Vq_cap*Iq_filter)；
Qe=1.5*(Vq_cap*Id_filter-Vd_cap*Iq_filter)。
Pe_pu=Pe/5000，Qe_pu=Qe/5000。
电流方向按原工程假定为电容节点流向滤波/电网侧；平台方向反了会变成错误反馈，必须先验证。
如果ia_filter等测量包含本地负载而非纯并网支路，Pe就包含对应负载功率，需按实际测量边界理解。

p_ref=0.1→500 W，0.2→1000 W，1→5000 W；q_ref=0.1→500 var。
不要把500或5000直接写入p_ref来表示瓦特。

## VSG参数与方程

有功全部在pu下：
d(omega_m_pu)/dt=(p_ref-Pe_pu-dp_pu*omega_m_pu)/m_pu；
omega_m=omega_m_pu*omega0，实际相角每100 us连续积分。
默认h=2.5、m_pu=2*h=5、dp_pu=50、omega_m限幅+/-2 Hz。
h用于初始化m_pu；需要在线改惯量时调m_pu，不是只改h字段。
power_loop_div默认1，与旧工程实际设置一致，为10 kHz；设10则功率环1 kHz，相角和双环仍10 kHz。

无功在pu下：
v_delta_pu=PI_QV(q_ref-Qe_pu)，v_ref=v_nom+155.56*v_delta_pu。
默认Kp_QV=0.05、Ki_QV=0，PI输出限幅+/-0.3 pu（约+/-46.668 V）。
旧工程Kp_QV/Ki_QV曾为0/0（等于未启用无功调节），没有原样照搬成无功环完全关闭。
当前0.05为归一化5%初始Q-V下垂，不是已经验证过的HIL无功环整定，也不能照搬旧“V/pu”增益。
最终电压参考限于v_min和min(v_max,0.475*Vdc)。
冻结的omega_sync是并网基频偏置；电网频率随后变化时，有功环按阻尼下垂响应，不保证Pe仍严格等于给定。
初次实验保持小功率给定和Ki_QV=0，HIL验证后再调参；这不是功率硬件调试指导。

## 验证与备份

tests/run_host_tests.ps1验证实际C代码：
- 5000基准、真实P/Q公式、pu惯量/阻尼和限幅、Q-V归一化及无扰预置；
- 无效/过早/失效同步命令拒绝、三相差压检查、就绪不自动闭合；
- 49/50/51 Hz预同步→手动合闸→VSG切换，频率/相角/电压连续，预同步补偿不丢失、不重复；
- 理想电压源串联电抗并网模型中500→1000 W功率阶跃；
- 手动开闸返回VF连续、总停机开闸关闭PWM，原采样/双环/调制回归。

理想电压源模型不包含实际LC双环动态、死区、平台断路器延迟与采样误差，不能替代HIL并网验证。
未下载或操作板卡，新增控制环后的实际ISR耗时需实测。
修改前源码与配置备份：backups/before_grid_vsg_20261015_171502.zip。
