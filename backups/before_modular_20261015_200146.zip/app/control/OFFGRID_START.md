# 基础离网双闭环操作

## 当前版本的边界

这是优先验证半实物功能的精简版，没有故障锁存、过流/过压判定、ADC就绪判定、PWM更新时间窗拦截或故障复位命令。
删除保护并不能修复真实电流异常；不会再因原故障码4停机，但仍需在半实物平台观察波形。
保留PI积分/输出限幅、电流给定限幅及调制限幅。这些是控制器和调制器的基本数值约束，不是故障保护。
本版不含软启动：Vd_ref直接进入电压PI。仅用于半实物，不直接驱动功率硬件。

## 文件与命名

沿用28377旧工程的变量：
- 物理采样：Va_cap/Vb_cap/Vc_cap、Ia_inv/Ib_inv/Ic_inv、Ia_filter/Ib_filter/Ic_filter；单位V/A。
- PCC采样仍为PCC_ua/PCC_ub/PCC_uc，用于PLL及可选预同步；PRESYNC_CTRL.enable=0时不影响离网给定。
- 变换对象：DQ0_POS_VCAP、DQ0_POS_IINV、DQ0_POS_IFILTER。
- dq反馈：Vd_cap/Vq_cap、Id_inv/Iq_inv、Id_filter/Iq_filter。
- 四个PI：PI_UD、PI_UQ、PI_ID、PI_IQ。
- PI增益：Kpu/Kiu（电压环）、Kpi/Kii（电流环）。
- 电流参考：id_ref/iq_ref，单位A。
- ud_ref/uq_ref：电流环电压输出乘2/Vdc后的归一化dq调制量，与旧工程最终变量含义一致。
- VaRef/VbRef/VcRef：反变换后的归一化三相调制波。
- da_upper/da_lower、db_upper/db_lower、dc_upper/dc_lower：六路0~1占空比。
- colse_loop_theta：保留旧工程的拼写，独立离网相角，单位rad。

当前保留用户已验证整定：Kpu=0.7、Kiu=0.5、Kpi=1.5、Kii=0。
U_UpLimit=300 A，限制电压PI输出及总电流给定；I_UpLimit=100 V，限制电流PI自身输出。
电流环d轴交叉项使用Iq_inv，q轴交叉项使用Id_inv，没有照抄旧代码的同轴交叉项。

## 初始化与运行

1. CCS刷新工程（删除的源文件不能残留在构建列表），对CPU1_LAUNCHXL_RAM执行Clean/Rebuild。
   构建使用-O2和--fp_mode=relaxed，下载新out。旧监视项故障码/状态/掩码/计时器已删除，应从监视窗口移除。
2. 连续运行CPU，保持offgridEnable=0、PRESYNC_CTRL.enable=0。确认12路物理采样正确；GPIO48/47高、pwmBufferEnabled=0；GPIO21低（断路器断开）。
3. 停机时设置f_ref=50、Vdc=400（必须等于平台总直流母线电压）、Vd_ref=20、Vq_ref=0。
   Lf=0.002 H、Cf=0.000012 F必须与平台模型一致。Vdc必须为正，频率/参数需自行保证有效，本版不做参数故障检查。
4. 设置offgridEnable=1。中断继续采样、计算双环并更新PWM。
   第一拍写入占空比，经过下一次计数器零点加载后第二拍释放EPWM1~6，GPIO48/47低、pwmBufferEnabled=1。
   EPWM7始终手动封锁；没有有效手动并网命令时GPIO21保持低，不自动合闸。
5. 平台观察三相电容电压和电流；Vd_cap应趋近20 V，Vq_cap趋近0。20 V为相电压峰值，对应约14.14 Vrms。
   这是控制目标，不保证未经HIL调参就达到。确认波形正常后再逐渐提高Vd_ref。
6. 停机：offgridEnable=0。下一次控制中断将GPIO48/47拉高，PWM手动封锁、PI积分及调制给定清零，无需故障复位。

GPIO21不使用：如果平台中的断路器切断的是逆变器到LC滤波器的路径，保持断开将无法建立电压；需先确认平台连接位置。

## 采样与PWM关系

PWM1 SOCA在计数器零点触发ADC；计数到PRD进入控制中断（50 us后）。
读取16个已配置SOC，其中12个用于物理量。清ADC标志仅做外围寄存器维护，不判定故障，不跳过换算。
固定零偏和3.3 V量程比例不变。A9/B0/C14/D11不参与闭环。
新占空比在下一零点加载，反变换使用提前一个采样周期的相角。

EPWM1/2=A，EPWM3/4=B，EPWM5/6=C；每组A/B互补，保留死区。
PWM仍使用软件OST执行手动启停（不是故障判定）；不能删除这一手动输出封锁，否则停机语义改变。
0%/100%仍使用死区前AQ强制，避免端点比较事件重合导致错误占空比。

## 验证与限制

运行tests/run_host_tests.ps1可验证实际C代码的12路换算、dq/PI公式、调制、启停和GPIO顺序。
主机平均LC模型测试只验证数学链，不代替F28P55实测时序、PWM死区、硬件接线与HIL启动验证。
当前没有CAN指令接收；offgridEnable仍通过CCS监视窗口设置。

预同步新增说明见PRESYNC_START.md。当前Vd_ref默认155.56 V，上面的20 V步骤为低幅值初次调试建议，并非程序默认值。
