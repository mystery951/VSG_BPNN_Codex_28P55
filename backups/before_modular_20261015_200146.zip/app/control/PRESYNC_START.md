# 预同步调试（半实物，断路器不自动闭合）

## 运行顺序

1. CCS刷新工程、Clean/Rebuild当前RAM配置，下载新程序。
   构建日志应包含presync.c、grid_pll.c，仍使用-O2及--fp_mode=relaxed。
   保持PRESYNC_CTRL.enable=0，设置offgridEnable=1，先确认原离网双环正常。
2. 平台PCC端输入正相序三相交流电压；保持GPIO21=0（平台断路器断开）。
   gridPllEnable默认1，PLL在待机和离网状态都可运行。
   观察SPLL_GRID.fo接近PCC频率，PRESYNC_CTRL.v_grid_mag接近PCC相电压峰值。
   原gridPll/gridDqPos/gridDqNeg改为旧工程名称SPLL_GRID/DQ0_POS_REF/DQ0_NEG_REF。
3. 设置PRESYNC_CTRL.enable=1。等待200 ms有效PCC输入后开始相角PI和电压幅值跟踪。
   观察theta_err、freq_err_hz、volt_err逐渐接近0，sync_ready最终为1。
   这只表示当前软件同步条件成立，不是合闸命令，也不是功率硬件并网许可。
4. 平台分别测试49、50、51 Hz。f_ref仍是基础频率50 Hz，不被预同步改写；
   实际控制角频率omega=2*pi*f_ref+PRESYNC_CTRL.omega_sync，omega/2/pi才是当前输出频率。
5. 退出预同步：PRESYNC_CTRL.enable=0，频率补偿和就绪标志清零，继续基础离网运行。
   Vd_ref保留最后跟踪值，不自动跳回启用前值；需要时自行重新设置电压给定。
   停止全部PWM仍使用offgridEnable=0。

注意：预同步会把Vd_ref从现有值缓慢调到PCC的相电压峰值。
例如先用20 V验证离网、PCC为155.56 V峰值时，启用预同步后给定会逐步升高，不会保持20 V。
Vq_ref在该流程应保持0，Vdc及Lf/Cf、相序、采样方向应与已验证离网模型一致。

## 模块和调用

- app/PLL/grid_pll.c：PCC正/负序变换及原DDSRF PLL，沿用SPLL_GRID命名。
- app/control/presync.h/.c：沿用PRESYNC_DEF/PRESYNC_CTRL、Presync_Init/Reset/Calc命名。
  合闸前直接调节现有Vd_ref及频率补偿；手动并网后由VSG_CTRL接管，详见GRID_VSG_START.md。
- epwm1_isr：ADC读取 → PCC PLL → InnerLoop_Update → PWM。
- InnerLoop_Update：当前采样dq变换 → 预同步 → 电压/电流PI → 下一PWM零点角度预测及调制。
- Presync_Calc使用grid_theta（PLL更新前的当前采样时刻角度），不使用已提前一拍的SPLL_GRID.theta[0]直接比较。
- 不直接把PLL角度赋给colse_loop_theta，因此启用预同步不发生相位跳变。

## 默认参数（与旧工程一致）

| 参数 | 默认值及含义 |
|---|---|
| PRESYNC_CTRL.kp/ki | 4 / 10，相角误差PI |
| omega_sync_max/min | +/-12.5663706 rad/s，即+/-2 Hz |
| v_track_k | 0.001，每100 us一步的幅值跟踪系数 |
| pll_wait_cnt_limit | 2000，10 kHz下200 ms；是等待时间，不等同于锁相证明 |
| theta_ok | 0.0872665 rad，约5度 |
| freq_ok | 0.5 Hz |
| volt_ok | 10 V相电压峰值差，不是RMS |
| sync_ok_cnt_limit | 连续10拍，约1 ms；仅沿用旧工程初始值，不自动合闸 |

电压参考另外受0~0.475*Vdc限制，与现有0.95调制上限一致。
如果PCC幅值超出当前母线可实现的范围，不能依靠预同步把电压强行跟到该值。
如频差超出+/-2 Hz补偿能力，需要先检查基础频率设定。

## 有效性和边界

PCC相电压幅值低于30 V或gridPllEnable=0时，不输出预同步补偿，不停止离网PWM。
PCC恢复时重新初始化PLL的旧滤波/积分状态，然后重新等待和同步。
sync_ready逐拍重新判断，不锁存；还要求实际电容电压相位满足5度条件、PLL正序d为正且q足够小。
不满足时仅清零就绪标志，不触发故障、不封锁PWM。

未发出有效手动并网命令时GPIO21保持0，平台断路器断开，不自动合闸。
有效手动并网命令INV_CTRL.grid_connect_cmd=1被接受后GPIO21置1，切换VSG；详见GRID_VSG_START.md。
原GPIO48/47低有效使能、EPWM5/6的C相映射、固定零偏与换算均未改变。
用户已验证的双环参数仍为Kpu=0.7、Kiu=0.5、Kpi=1.5、Kii=0、U_UpLimit=300，Vd_ref初始155.56 V。

## 验证

tests/run_host_tests.ps1运行实际PLL、预同步、采样、双环、PWM模块的主机测试：
- 49/50/51 Hz锁相及预同步；相角连续、补偿限幅、幅值跟踪。
- 缺失PCC、退出/重入、400 ms PCC消失后重新锁相和预同步。
- 同步标志的连续判定、失配撤销及实际电压相位检查。
- GPIO21全程为0，PWM使能顺序及C相EPWM5/6映射。
- 原12路换算及平均LC模型回归（LC回归使用原测试整定，不代表当前用户整定的HIL验证）。

同步跟踪测试采用理想已稳定电压内环，不能代替HIL动态验证。
尚未下载板卡或测量新增PLL后的实际ISR耗时。没有恢复过流/过压等功率硬件保护。
修改前备份在backups/before_presync_20261015_164526.zip。
