#include "feedback_dq.h"
#include "app/measurement/adc_measurement.h"
#include <math.h>

ABC_DQ0_POS_F DQ0_POS_VCAP, DQ0_POS_IINV, DQ0_POS_IFILTER;
volatile float Vd_cap, Vq_cap, Id_inv, Iq_inv, Id_filter, Iq_filter;

void FeedbackDq_Init(void)
{
    ABC_DQ0_POS_F_init(&DQ0_POS_VCAP);
    ABC_DQ0_POS_F_init(&DQ0_POS_IINV);
    ABC_DQ0_POS_F_init(&DQ0_POS_IFILTER);
}

static void Transform(ABC_DQ0_POS_F *v, float a, float b, float c, float sine, float cosine)
{
    v->a = a;
    v->b = b;
    v->c = c;
    v->sin_val = sine;
    v->cos_val = cosine;
    ABC_DQ0_POS_F_FUNC(v);
}

void FeedbackDq_Update(float theta)
{
    float sine = sinf(theta), cosine = cosf(theta);
    Transform(&DQ0_POS_VCAP, Va_cap, Vb_cap, Vc_cap, sine, cosine);
    Transform(&DQ0_POS_IINV, Ia_inv, Ib_inv, Ic_inv, sine, cosine);
    Transform(&DQ0_POS_IFILTER, Ia_filter, Ib_filter, Ic_filter, sine, cosine);
    Vd_cap = DQ0_POS_VCAP.d;
    Vq_cap = DQ0_POS_VCAP.q;
    Id_inv = DQ0_POS_IINV.d;
    Iq_inv = DQ0_POS_IINV.q;
    Id_filter = DQ0_POS_IFILTER.d;
    Iq_filter = DQ0_POS_IFILTER.q;
}
