#ifndef FEEDBACK_DQ_H_
#define FEEDBACK_DQ_H_
#include "app/PLL/ABC_DQ0_POS_F.h"
extern ABC_DQ0_POS_F DQ0_POS_VCAP, DQ0_POS_IINV, DQ0_POS_IFILTER;
extern volatile float Vd_cap, Vq_cap, Id_inv, Iq_inv, Id_filter, Iq_filter;
void FeedbackDq_Init(void);
void FeedbackDq_Update(float theta);
#endif
