#ifndef INNER_LOOP_H_
#define INNER_LOOP_H_
#include <stdint.h>
#include "pi_controller.h"

#define CONTROL_TS 0.0001f
#define TWO_PI 6.28318530718f
#define PWM_PERIOD 7500U

// Physical units: V, A, H, F, rad/s. Command: 0=stop, 1=run (HIL only).
extern volatile uint16_t offgridEnable;
extern volatile uint32_t offgridRunCount;
extern volatile float f_ref, omega, colse_loop_theta;
extern volatile float Vdc, Lf, Cf;
extern volatile float Vd_ref, Vq_ref, id_ref, iq_ref, ud_ref, uq_ref;
extern volatile float Kpu, Kiu, Kpi, Kii, U_UpLimit, I_UpLimit;
extern volatile float VaRef, VbRef, VcRef;
extern PI_POS_DEF PI_UD, PI_UQ, PI_ID, PI_IQ;

void CloseLoop_Init(void);
void InnerLoop_Update(void);
#endif
