#include "inverter_state.h"
#include "inner_loop.h"
#include "presync.h"
#include "vsg.h"
#include "app/system_config.h"
#include "app/measurement/adc_measurement.h"
#include "app/PLL/grid_pll.h"
#include <math.h>

volatile INV_STATE_CTRL INV_CTRL = { INV_STANDBY, INV_STANDBY, 0U, 0U, 0U };
volatile float Va_sync_diff, Vb_sync_diff, Vc_sync_diff;
// Physical volts: the old 0.05 pu criterion must not become 0.05 V by mistake.
volatile float grid_zero_cross_threshold = 0.05f * SYS_V_BASE_V;

void InvState_Init(volatile INV_STATE_CTRL *s)
{
    s->state = s->last_state = INV_STANDBY;
    s->grid_connect_cmd = s->grid_zero_cross_ok = s->grid_connect_rejected = 0U;
}

void InvState_Step(volatile INV_STATE_CTRL *s)
{
    s->last_state = s->state;
    Va_sync_diff = PCC_ua - Va_cap;
    Vb_sync_diff = PCC_ub - Vb_cap;
    Vc_sync_diff = PCC_uc - Vc_cap;
    s->grid_zero_cross_ok = (fabsf(Va_sync_diff) < grid_zero_cross_threshold
        && fabsf(Vb_sync_diff) < grid_zero_cross_threshold
        && fabsf(Vc_sync_diff) < grid_zero_cross_threshold) ? 1U : 0U;
    if(offgridEnable != 1U)
    {
        s->state = INV_STANDBY;
        s->grid_connect_cmd = s->grid_zero_cross_ok = s->grid_connect_rejected = 0U;
        PRESYNC_CTRL.enable = 0U;
        Presync_Reset(&PRESYNC_CTRL);
        VSG_CTRL.omega_m = VSG_CTRL.omega_m_pu = VSG_CTRL.omega_sync = 0.0f;
        VSG_CTRL.power_loop_cnt = 0U;
        return;
    }
    if(s->state == INV_GRID_CONNECTED)
    {
        PRESYNC_CTRL.enable = 0U; // VSG owns the angle after the transfer.
        if(s->grid_connect_cmd == 1U) return;
        // Open to VF without resetting angle, frequency, voltage or inner PIs.
        f_ref = (VSG_CTRL.omega0 + VSG_CTRL.omega_sync + VSG_CTRL.omega_m) / TWO_PI;
        Vd_ref = VSG_CTRL.v_ref;
        PRESYNC_CTRL.enable = 0U;
        Presync_Reset(&PRESYNC_CTRL);
        s->state = INV_OFFGRID_VF;
        return;
    }
    s->state = (PRESYNC_CTRL.enable == 1U) ? INV_PRESYNC : INV_OFFGRID_VF;
    if(PRESYNC_CTRL.enable == 1U && PRESYNC_CTRL.sync_ready == 1U && gridPllValid == 1U && s->grid_zero_cross_ok == 1U)
        s->state = INV_GRID_READY;

    if(s->grid_connect_cmd == 1U)
    {
        if(s->state == INV_GRID_READY)
        {
            VSG_EnterGrid(&VSG_CTRL, colse_loop_theta, PRESYNC_CTRL.omega_sync, Vd_ref);
            PRESYNC_CTRL.enable = 0U;
            Presync_Reset(&PRESYNC_CTRL);
            s->grid_connect_rejected = 0U;
            s->state = INV_GRID_CONNECTED;
        }
        else
        {
            s->grid_connect_cmd = 0U; // No pending request / delayed auto-close.
            s->grid_connect_rejected = 1U;
        }
    }
}
