#ifndef INVERTER_STATE_H_
#define INVERTER_STATE_H_
#include <stdint.h>

typedef enum
{
    INV_STANDBY = 0, INV_OFFGRID_VF = 1, INV_PRESYNC = 2,
    INV_GRID_READY = 3, INV_GRID_CONNECTED = 4
} INV_STATE;

typedef struct
{
    INV_STATE state, last_state;
    uint16_t grid_connect_cmd, grid_zero_cross_ok, grid_connect_rejected;
} INV_STATE_CTRL;

extern volatile INV_STATE_CTRL INV_CTRL;
extern volatile float Va_sync_diff, Vb_sync_diff, Vc_sync_diff;
extern volatile float grid_zero_cross_threshold;
void InvState_Init(volatile INV_STATE_CTRL *s);
void InvState_Step(volatile INV_STATE_CTRL *s);
#endif
