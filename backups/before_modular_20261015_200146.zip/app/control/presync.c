#include "presync.h"
#include "inner_loop.h"
#include "feedback_dq.h"
#include "app/PLL/grid_pll.h"
#include <math.h>

volatile PRESYNC_DEF PRESYNC_CTRL = {0};

static float WrapPi(float angle)
{
    while(angle > 3.14159265359f) angle -= TWO_PI;
    while(angle < -3.14159265359f) angle += TWO_PI;
    return angle;
}

void Presync_Reset(volatile PRESYNC_DEF *p)
{
    p->sync_ready = p->sync_ok_cnt = 0U;
    p->pll_wait_cnt = p->pll_ready = 0U;
    p->theta_err = p->freq_err_hz = p->volt_err = 0.0f;
    p->omega_sync = p->omega_sync_ui = 0.0f;
}

void Presync_Init(volatile PRESYNC_DEF *p)
{
    p->enable = 0U;
    p->sync_ok_cnt_limit = 10U;      // 10 consecutive samples, same as old code.
    p->pll_wait_cnt_limit = 2000U;   // 200 ms at 10 kHz.
    p->kp = 4.0f;
    p->ki = 10.0f;
    p->omega_sync_max = 12.5663706f; // +/-2 Hz, in rad/s.
    p->omega_sync_min = -12.5663706f;
    p->v_track_k = 0.001f;
    p->theta_ok = 0.0872665f;       // 5 degrees.
    p->freq_ok = 0.5f;              // Hz.
    p->volt_ok = 10.0f;             // Phase peak volts, not RMS.
    p->theta_grid = p->theta_vsg = 0.0f;
    p->v_grid_mag = p->v_inv_mag = 0.0f;
    Presync_Reset(p);
}

void Presync_Calc(volatile PRESYNC_DEF *p, float Ts)
{
    float output, voltageMax, phaseError;
    p->theta_grid = grid_theta; // PLL angle BEFORE advancing: same sample time.
    p->theta_vsg = colse_loop_theta;
    p->v_grid_mag = (gridPllValid == 1U) ? sqrtf(SPLL_GRID.d_p_decoupl_lpf * SPLL_GRID.d_p_decoupl_lpf + SPLL_GRID.q_p_decoupl_lpf * SPLL_GRID.q_p_decoupl_lpf) : 0.0f;
    p->v_inv_mag = sqrtf(Vd_cap * Vd_cap + Vq_cap * Vq_cap);

    // Not a fault: no PCC / disabled presync simply leaves island control alone.
    if(p->enable != 1U || offgridEnable != 1U || gridPllValid != 1U || !(p->v_grid_mag > 30.0f))
    {
        Presync_Reset(p);
        return;
    }
    if(p->pll_wait_cnt < p->pll_wait_cnt_limit)
    {
        p->pll_wait_cnt++;
        p->pll_ready = p->sync_ready = 0U;
        return;
    }
    p->pll_ready = 1U;
    p->theta_err = WrapPi(p->theta_grid - p->theta_vsg);
    p->omega_sync_ui += p->ki * p->theta_err * Ts;
    output = p->kp * p->theta_err + p->omega_sync_ui;
    if(output > p->omega_sync_max) output = p->omega_sync_max;
    if(output < p->omega_sync_min) output = p->omega_sync_min;
    p->omega_sync = output;
    p->omega_sync_ui = output - p->kp * p->theta_err;

    // Track from the present reference: no phase or voltage-reference jump.
    Vd_ref += p->v_track_k * (p->v_grid_mag - Vd_ref);
    voltageMax = 0.475f * Vdc; // Available phase peak with modulation limit 0.95.
    if(Vd_ref > voltageMax) Vd_ref = voltageMax;
    if(Vd_ref < 0.0f) Vd_ref = 0.0f;
    p->freq_err_hz = SPLL_GRID.fo - (TWO_PI * f_ref + p->omega_sync) / TWO_PI;
    p->volt_err = p->v_grid_mag - p->v_inv_mag;
    // Also check measured capacitor-voltage phase, not just oscillator phase.
    phaseError = WrapPi(p->theta_err - atan2f(Vq_cap, Vd_cap));
    if(fabsf(p->theta_err) < p->theta_ok && fabsf(phaseError) < p->theta_ok
       && fabsf(p->freq_err_hz) < p->freq_ok && fabsf(p->volt_err) < p->volt_ok
       && SPLL_GRID.d_p_decoupl_lpf > 30.0f
       && fabsf(SPLL_GRID.q_p_decoupl_lpf) < 0.05f * p->v_grid_mag)
    {
        if(p->sync_ok_cnt < p->sync_ok_cnt_limit) p->sync_ok_cnt++;
        p->sync_ready = (p->sync_ok_cnt >= p->sync_ok_cnt_limit) ? 1U : 0U;
    }
    else
    {
        p->sync_ok_cnt = p->sync_ready = 0U;
    }
}
