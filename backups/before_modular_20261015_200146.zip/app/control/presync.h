#ifndef PRESYNC_H_
#define PRESYNC_H_
#include <stdint.h>

// Same names and physical units as the F28377D presynchronizer.
typedef struct
{
    uint16_t enable, sync_ready, sync_ok_cnt, sync_ok_cnt_limit;
    uint16_t pll_wait_cnt, pll_wait_cnt_limit, pll_ready;
    float theta_grid, theta_vsg, theta_err, freq_err_hz, volt_err;
    float omega_sync, omega_sync_ui, kp, ki, omega_sync_max, omega_sync_min;
    float v_grid_mag, v_inv_mag, v_track_k;
    float theta_ok, freq_ok, volt_ok;
} PRESYNC_DEF;

extern volatile PRESYNC_DEF PRESYNC_CTRL;
void Presync_Init(volatile PRESYNC_DEF *p);
void Presync_Reset(volatile PRESYNC_DEF *p);
void Presync_Calc(volatile PRESYNC_DEF *p, float Ts);
#endif
