#ifndef PWM_OUTPUT_H_
#define PWM_OUTPUT_H_
#include <stdbool.h>
#include <stdint.h>
extern volatile uint16_t pwmOutputEnabled, pwmBufferEnabled;
extern volatile float da_upper, da_lower, db_upper, db_lower, dc_upper, dc_lower;
void PwmOutput_Init(void);
void PwmOutput_Disable(void);
void PwmOutput_Update(bool enable, float ma, float mb, float mc);
#endif
