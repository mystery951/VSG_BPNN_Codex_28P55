#include "vsg.h"
#include "inner_loop.h"
#include "feedback_dq.h"
#include "app/system_config.h"

volatile VSG_DEF VSG_CTRL = {0};
const float SBase = SYS_S_BASE_VA;
volatile float Pe = 0.0f, Qe = 0.0f, Pe_pu = 0.0f, Qe_pu = 0.0f;
// pu voltage / pu reactive power: 5% Q-V droop; integral starts disabled.
volatile float Kp_QV = 0.05f, Ki_QV = 0.0f;
PI_POS_DEF PI_QV;

void VSG_Init(volatile VSG_DEF *v)
{
    v->theta = v->omega_m = v->omega_sync = v->omega_m_pu = 0.0f;
    v->omega0 = TWO_PI * f_ref;
    v->p_ref = v->q_ref = 0.0f;
    v->s_base = SBase;
    v->h = 2.5f;
    v->m_pu = 2.0f * v->h;
    v->dp_pu = 50.0f;
    v->v_nom = v->v_ref = Vd_ref;
    v->v_delta = v->v_delta_pu = 0.0f;
    v->omega_m_max = 12.5663706f;
    v->omega_m_min = -12.5663706f;
    v->v_min = 0.0f;
    v->v_max = 250.0f;
    v->power_loop_div = 1U; // Same as the old executable setting: 10 kHz.
    v->power_loop_cnt = 0U;
    PI_Pos_Init(&PI_QV, Kp_QV, Ki_QV, 0.3f, -0.3f);
}

void VSG_MeasurePower(void)
{
    // Same capacitor-voltage / filter-current boundary and signs as F28377D.
    Pe = 1.5f * (Vd_cap * Id_filter + Vq_cap * Iq_filter);
    Qe = 1.5f * (Vq_cap * Id_filter - Vd_cap * Iq_filter);
    Pe_pu = Pe / VSG_CTRL.s_base;
    Qe_pu = Qe / VSG_CTRL.s_base;
}

void VSG_EnterGrid(volatile VSG_DEF *v, float theta, float omegaSync, float voltage)
{
    v->theta = theta; // Already contains the entire accumulated presync phase.
    v->omega0 = TWO_PI * f_ref;
    v->omega_sync = omegaSync; // Capture actual correction, never a magic value.
    v->omega_m = v->omega_m_pu = 0.0f;
    v->v_nom = v->v_ref = voltage;
    v->v_delta = v->v_delta_pu = 0.0f;
    v->power_loop_cnt = 0U;
    PI_Pos_Reset(&PI_QV);
    PI_QV.kp = Kp_QV;
    PI_QV.ki = Ki_QV;
    // Bumpless Q-V transfer: cancel the initial proportional term.
    PI_QV.ui = -Kp_QV * (v->q_ref - Qe_pu);
}

void VSG_PowerLoop(volatile VSG_DEF *v, float pe, float qe, float Ts)
{
    float voltageMax, deviationMax, deviationMin;
    // Entire active-power swing equation uses pu quantities.
    v->omega_m_pu += (v->p_ref - pe - v->dp_pu * v->omega_m_pu) * Ts / v->m_pu;
    deviationMax = v->omega_m_max / v->omega0;
    deviationMin = v->omega_m_min / v->omega0;
    if(v->omega_m_pu > deviationMax) v->omega_m_pu = deviationMax;
    if(v->omega_m_pu < deviationMin) v->omega_m_pu = deviationMin;
    v->omega_m = v->omega_m_pu * v->omega0;

    PI_QV.kp = Kp_QV;
    PI_QV.ki = Ki_QV;
    v->v_delta_pu = PI_Pos_Cal(&PI_QV, v->q_ref - qe, Ts);
    v->v_delta = v->v_delta_pu * SYS_V_BASE_V;
    v->v_ref = v->v_nom + v->v_delta;
    voltageMax = 0.475f * Vdc;
    if(voltageMax > v->v_max) voltageMax = v->v_max;
    if(v->v_ref > voltageMax) v->v_ref = voltageMax;
    if(v->v_ref < v->v_min) v->v_ref = v->v_min;
}

void VF_AngleStep(volatile VSG_DEF *v, float Ts)
{
    v->theta += (v->omega0 + v->omega_sync) * Ts;
    if(v->theta >= TWO_PI) v->theta -= TWO_PI;
    if(v->theta < 0.0f) v->theta += TWO_PI;
}

void VSG_AngleStep(volatile VSG_DEF *v, float Ts)
{
    v->theta += (v->omega0 + v->omega_sync + v->omega_m) * Ts;
    if(v->theta >= TWO_PI) v->theta -= TWO_PI;
    if(v->theta < 0.0f) v->theta += TWO_PI;
}
