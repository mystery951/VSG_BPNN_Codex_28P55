#ifndef VSG_H_
#define VSG_H_
#include <stdint.h>
#include "pi_controller.h"

// Power references/feedback and swing-equation frequency deviations are pu.
// theta, omega*, v_ref/v_nom/v_delta remain rad, rad/s and physical volts.
typedef struct
{
    float theta, omega0, omega_m, omega_sync, omega_m_pu;
    float p_ref, q_ref, s_base, h, m_pu, dp_pu;
    float v_ref, v_nom, v_delta, v_delta_pu;
    float omega_m_max, omega_m_min, v_max, v_min;
    uint16_t power_loop_div, power_loop_cnt;
} VSG_DEF;

extern volatile VSG_DEF VSG_CTRL;
extern const float SBase;
extern volatile float Pe, Qe, Pe_pu, Qe_pu, Kp_QV, Ki_QV;
extern PI_POS_DEF PI_QV;
void VSG_Init(volatile VSG_DEF *v);
void VSG_EnterGrid(volatile VSG_DEF *v, float theta, float omegaSync, float voltage);
void VSG_MeasurePower(void);
void VSG_PowerLoop(volatile VSG_DEF *v, float pe, float qe, float Ts);
void VF_AngleStep(volatile VSG_DEF *v, float Ts);
void VSG_AngleStep(volatile VSG_DEF *v, float Ts);
#endif
