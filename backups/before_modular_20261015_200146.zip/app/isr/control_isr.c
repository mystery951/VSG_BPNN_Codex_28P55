#include "control_isr.h"
#include "board.h"
#include "app/measurement/adc_measurement.h"
#include "app/control/inner_loop.h"
#include "app/control/pwm_output.h"
#include "app/PLL/grid_pll.h"

volatile uint32_t timer1Count = 0U, pwm1IntCount = 0U;

void ControlIsr_Init(void)
{
    Interrupt_register(INT_TIMER1, &cpu_timer1_isr);
    Interrupt_enable(INT_TIMER1);
    Interrupt_register(INT_EPWM1, &epwm1_isr);
    Interrupt_enable(INT_EPWM1);
}

__interrupt void cpu_timer1_isr(void)
{
    timer1Count++;
}

__interrupt void epwm1_isr(void)
{
    AdcMeasurement_Acquire();
    GridPll_Update(PCC_ua, PCC_ub, PCC_uc);
    InnerLoop_Update();
    PwmOutput_Update(offgridEnable == 1U, VaRef, VbRef, VcRef);
    pwm1IntCount++;
    EPWM_clearEventTriggerInterruptFlag(PWM1_BASE);
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP3);
}
