#include "adc_measurement.h"
#include "adc_calibration.h"
#include "driverlib.h"
#include "board.h"

volatile uint16_t adcB0Raw = 0, adcB1Raw = 0;
volatile uint16_t adcB8Raw = 0, adcB10Raw = 0;
volatile uint16_t adcC4Raw = 0, adcC8Raw = 0, adcC14Raw = 0;
volatile uint16_t adcD11Raw = 0, adcD12Raw = 0, adcD14Raw = 0;
volatile uint16_t adcE12Raw = 0, adcE15Raw = 0;
volatile uint16_t adcA0Raw = 0, adcA5Raw = 0, adcA9Raw = 0, adcA12Raw = 0;

volatile float Va_cap = 0, Vb_cap = 0, Vc_cap = 0;
volatile float PCC_ua = 0, PCC_ub = 0, PCC_uc = 0;
volatile float Ia_inv = 0, Ib_inv = 0, Ic_inv = 0;
volatile float Ia_filter = 0, Ib_filter = 0, Ic_filter = 0;

// PWM1 SOCA starts conversion at zero; the period ISR reads the results.
void AdcMeasurement_Acquire(void)
{
    uint16_t i;
    const uint32_t bases[5] = { ADC_A_BASE, ADC_B_BASE, ADC_C_BASE, ADC_D_BASE, ADC_E_BASE };
    adcA0Raw  = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER0);
    adcA5Raw  = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER1);
    adcA9Raw  = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER2);
    adcA12Raw = ADC_readResult(ADCARESULT_BASE, ADC_SOC_NUMBER3);

    adcB0Raw  = ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER0);
    adcB1Raw  = ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER1);
    adcB8Raw  = ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER2);
    adcB10Raw = ADC_readResult(ADCBRESULT_BASE, ADC_SOC_NUMBER3);

    adcC4Raw  = ADC_readResult(ADCCRESULT_BASE, ADC_SOC_NUMBER0);
    adcC8Raw  = ADC_readResult(ADCCRESULT_BASE, ADC_SOC_NUMBER1);
    adcC14Raw = ADC_readResult(ADCCRESULT_BASE, ADC_SOC_NUMBER2);

    adcD11Raw = ADC_readResult(ADCDRESULT_BASE, ADC_SOC_NUMBER0);
    adcD12Raw = ADC_readResult(ADCDRESULT_BASE, ADC_SOC_NUMBER1);
    adcD14Raw = ADC_readResult(ADCDRESULT_BASE, ADC_SOC_NUMBER2);

    adcE12Raw = ADC_readResult(ADCERESULT_BASE, ADC_SOC_NUMBER0);
    adcE15Raw = ADC_readResult(ADCERESULT_BASE, ADC_SOC_NUMBER1);

    // Clear housekeeping flags without rejecting samples or stopping control.
    for(i = 0U; i < 5U; i++)
    {
        ADC_clearInterruptOverflowStatus(bases[i], ADC_INT_NUMBER1);
        ADC_clearInterruptStatus(bases[i], ADC_INT_NUMBER1);
    }

    Va_cap = ((float)adcA0Raw  - adcZeroOffset[0]) * VOL_SCALE;
    PCC_ua = ((float)adcA5Raw  - adcZeroOffset[1]) * VOL_SCALE;
    Ia_inv = ((float)adcA12Raw - adcZeroOffset[2]) * CUR_SCALE;
    
    Vb_cap = ((float)adcB1Raw  - adcZeroOffset[3]) * VOL_SCALE;
    PCC_ub = ((float)adcB8Raw  - adcZeroOffset[4]) * VOL_SCALE;
    Ib_inv = ((float)adcB10Raw - adcZeroOffset[5]) * CUR_SCALE;
    
    Vc_cap = ((float)adcC4Raw  - adcZeroOffset[6]) * VOL_SCALE;
    PCC_uc = ((float)adcC8Raw  - adcZeroOffset[7]) * VOL_SCALE;
    
    Ic_inv    = ((float)adcD12Raw - adcZeroOffset[8])  * CUR_SCALE;
    Ia_filter = ((float)adcD14Raw - adcZeroOffset[9])  * CUR_SCALE;
    Ib_filter = ((float)adcE12Raw - adcZeroOffset[10]) * CUR_SCALE;
    Ic_filter = ((float)adcE15Raw - adcZeroOffset[11]) * CUR_SCALE;
}
