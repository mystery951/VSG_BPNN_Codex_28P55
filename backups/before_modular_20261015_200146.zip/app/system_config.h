#ifndef SYSTEM_CONFIG_H_
#define SYSTEM_CONFIG_H_
#define SYS_S_BASE_VA 5000.0f
#define SYS_V_BASE_V 155.56f // Nominal phase peak volts.
#endif
