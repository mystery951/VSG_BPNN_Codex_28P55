#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stubs/driverlib.h"
#include "app/control/inner_loop.h"
#include "app/control/presync.h"
#include "app/PLL/grid_pll.h"
#include "app/control/vsg.h"
#include "app/control/inverter_state.h"

#include "app/control/feedback_dq.h"
#include "app/control/three_level_modulation.h"
#include "app/control/pwm_output.h"
#include "app/measurement/adc_measurement.h"

// Real measurement/controller code, with ADC and PWM registers simulated below.
static bool adcFlags[5], adcOverflows[5];
static uint16_t adcResults[5][4];
static unsigned adcResultReads, adcFlagClears;
bool ADC_getInterruptStatus(uint32_t base, unsigned interrupt) { (void)interrupt; return adcFlags[base - 10U]; }
bool ADC_getInterruptOverflowStatus(uint32_t base, unsigned interrupt) { (void)interrupt; return adcOverflows[base - 10U]; }
void ADC_clearInterruptStatus(uint32_t base, unsigned interrupt)
{
    (void)interrupt;
    assert(adcResultReads == 0U || adcResultReads == 16U);
    adcFlags[base - 10U] = false;
    adcFlagClears++;
}
void ADC_clearInterruptOverflowStatus(uint32_t base, unsigned interrupt) { (void)interrupt; adcOverflows[base - 10U] = false; }
uint16_t ADC_readResult(uint32_t base, unsigned soc)
{
    assert(adcFlagClears == 0U); // Do not clear flags before the full result copy.
    adcResultReads++;
    return adcResults[base - 20U][soc];
}

typedef struct { uint16_t period, compare[2], force, flags, counter, direction; } FakePwm;
static FakePwm hw[8];
static uint32_t gpioValue[64];
void GPIO_writePin(uint32_t pin, uint32_t value)
{
    unsigned i;
    assert(pin < 64U);
    if(pin == 21U && value == 1U)
    {
        assert(INV_CTRL.state == INV_GRID_CONNECTED && INV_CTRL.grid_connect_cmd == 1U);
        assert(offgridEnable == 1U && pwmOutputEnabled == 1U && pwmBufferEnabled == 1U);
    }
    if((pin == 47U || pin == 48U) && value == 0U)
    {
        // Both buffers may only be enabled after every used bridge is released.
        for(i = 1U; i <= 6U; i++) assert(hw[i].flags == 0U);
        assert(hw[7].flags & EPWM_TZ_FLAG_OST);
    }
    gpioValue[pin] = value;
}
void EPWM_setTripZoneAction(uint32_t b, unsigned e, unsigned a) { (void)b; (void)e; assert(a == EPWM_TZ_ACTION_LOW); }
void EPWM_forceTripZoneEvent(uint32_t b, uint16_t e) { assert(gpioValue[47] == 1U && gpioValue[48] == 1U); hw[b].flags |= e; }
uint16_t EPWM_getTimeBasePeriod(uint32_t b) { return hw[b].period; }
void EPWM_setCounterCompareShadowLoadMode(uint32_t b, unsigned c, unsigned m) { (void)b; (void)c; assert(m == 0U); }
void EPWM_setActionQualifierContSWForceShadowMode(uint32_t b, unsigned m) { (void)b; assert(m == 0U); }
void EPWM_setRisingEdgeDeadBandDelayInput(uint32_t b, uint16_t i) { (void)b; assert(i == 0U); }
void EPWM_setFallingEdgeDeadBandDelayInput(uint32_t b, uint16_t i) { (void)b; assert(i == 0U); }
void EPWM_setCounterCompareValue(uint32_t b, unsigned c, uint16_t v) { hw[b].compare[c] = v; }
void EPWM_setActionQualifierContSWForceAction(uint32_t b, unsigned o, EPWM_ActionQualifierSWOutput f) { assert(o == 0U); hw[b].force = (uint16_t)f; }
uint16_t EPWM_getTripZoneFlagStatus(uint32_t b) { return hw[b].flags; }
uint16_t EPWM_getTimeBaseCounterValue(uint32_t b) { return hw[b].counter; }
uint16_t EPWM_getTimeBaseCounterDirection(uint32_t b) { return hw[b].direction; }
void EPWM_clearTripZoneFlag(uint32_t b, uint16_t f) { assert(gpioValue[47] == 1U && gpioValue[48] == 1U); hw[b].flags &= (uint16_t)~f; }

static void Near(float actual, float expected, float tolerance)
{
    if(!(fabsf(actual - expected) <= tolerance))
    {
        fprintf(stderr, "Expected %.8g, got %.8g (tolerance %.8g)\n", expected, actual, tolerance);
        exit(1);
    }
}

static void SetAbc(float alpha, float beta, volatile float *a, volatile float *b, volatile float *c)
{
    *a = alpha;
    *b = -0.5f * alpha + 0.86602540378f * beta;
    *c = -0.5f * alpha - 0.86602540378f * beta;
}

#include "app/measurement/adc_calibration.h"

static void Reset(void)
{
    memset(hw, 0, sizeof(hw));
    memset(gpioValue, 0, sizeof(gpioValue));
    Va_cap = Vb_cap = Vc_cap = 0.0f;
    Ia_inv = Ib_inv = Ic_inv = 0.0f;
    Ia_filter = Ib_filter = Ic_filter = 0.0f;
    colse_loop_theta = 0.0f;
    Vd_ref = 20.0f; Vq_ref = 0.0f;
    f_ref = 50.0f; Vdc = 400.0f; Lf = 0.002f; Cf = 0.000012f;
    Kpu = 0.0053314595f; Kiu = 1.1843525f;
    Kpi = 6.2831853f; Kii = 0.31415927f;
    U_UpLimit = 30.0f; I_UpLimit = 100.0f;
    FeedbackDq_Init();
    CloseLoop_Init();
    GridPll_Init();
    gridPllEnable = 1U;
    Presync_Init(&PRESYNC_CTRL);
    VSG_Init(&VSG_CTRL);
    InvState_Init(&INV_CTRL);
    PwmOutput_Init();
}

static void TestAdc(void)
{
    unsigned i, j;
    volatile float *physical[12] = { &Va_cap, &PCC_ua, &Ia_inv, &Vb_cap, &PCC_ub, &Ib_inv, &Vc_cap, &PCC_uc, &Ic_inv, &Ia_filter, &Ib_filter, &Ic_filter };
    const unsigned banks[12] = {0,0,0,1,1,1,2,2,3,3,4,4};
    const unsigned socs[12] = {0,1,3,1,2,3,0,1,1,2,0,1};
    Reset();
    for(i = 0; i < 5; i++)
    {
        adcFlags[i] = false;
        adcOverflows[i] = true; // Housekeeping must not suppress sampling.
        for(j = 0; j < 4; j++) adcResults[i][j] = (uint16_t)(2000 + i * 20 + j);
    }
    adcResultReads = adcFlagClears = 0U;
    AdcMeasurement_Acquire();
    assert(adcResultReads == 16U && adcFlagClears == 5U);
    for(i = 0; i < 12; i++)
    {
        float scale = (i == 0 || i == 1 || i == 3 || i == 4 || i == 6 || i == 7) ? VOL_SCALE : CUR_SCALE;
        Near(*physical[i], ((float)adcResults[banks[i]][socs[i]] - adcZeroOffset[i]) * scale, 0.0001f);
    }
    for(i = 0; i < 5; i++) assert(!adcFlags[i] && !adcOverflows[i]);
    puts("PASS all twelve fixed-offset conversions; no ready/overflow gating");
}

static void TestControl(void)
{
    Reset();
    PI_UD.ui = 2.0f;
    InnerLoop_Update();
    assert(PI_UD.ui == 0.0f && VaRef == 0.0f);
    offgridEnable = 1U;
    Kpu = Kiu = Kpi = Kii = 0.0f;
    SetAbc(10.0f, 2.0f, &Va_cap, &Vb_cap, &Vc_cap);
    SetAbc(3.0f, 4.0f, &Ia_inv, &Ib_inv, &Ic_inv);
    SetAbc(1.0f, 0.5f, &Ia_filter, &Ib_filter, &Ic_filter);
    InnerLoop_Update();
    Near(Vd_cap, 10.0f, 0.0001f);
    Near(Vq_cap, 2.0f, 0.0001f);
    Near(id_ref, 1.0f - omega * Cf * 2.0f, 0.0001f);
    Near(iq_ref, 0.5f + omega * Cf * 10.0f, 0.0001f);
    Near(ud_ref, (10.0f - omega * Lf * 4.0f) * 2.0f / Vdc, 0.0001f);
    Near(uq_ref, (2.0f + omega * Lf * 3.0f) * 2.0f / Vdc, 0.0001f);
    Ia_inv = 50.0f; // Requested basic controller has no overcurrent latch.
    InnerLoop_Update();
    assert(offgridEnable == 1U && isfinite(VaRef));
    offgridEnable = 0U;
    InnerLoop_Update();
    assert(colse_loop_theta == 0.0f && id_ref == 0.0f && VaRef == 0.0f);
    puts("PASS dq, PI reset, cross coupling, normalization and stop/restart");
}

static void TestPwm(void)
{
    unsigned i;
    ThreeLevelDuty duty;
    Reset();
    for(i = 0; i <= 200; i++)
    {
        float m = (float)i * 0.01f - 1.0f;
        ThreeLevelModulation_Map(m, &duty);
        Near(duty.upper - (1.0f - duty.lower), m, 0.0001f);
    }
    PwmOutput_Update(true, 0.2f, -0.3f, 0.4f);
    assert(pwmBufferEnabled == 0U);
    PwmOutput_Update(true, 0.2f, -0.3f, 0.4f);
    assert(pwmOutputEnabled == 1U && gpioValue[47] == 0U && gpioValue[48] == 0U);
    assert(hw[1].compare[0] == 1500U && hw[5].compare[0] == 3000U);
    assert(hw[2].force == EPWM_AQ_SW_OUTPUT_HIGH && hw[3].force == EPWM_AQ_SW_OUTPUT_LOW);
    for(i = 1; i <= 6; i++) assert(hw[i].flags == 0U);
    assert(hw[7].flags & EPWM_TZ_FLAG_OST);
    assert(gpioValue[21] == 0U);
    PwmOutput_Update(false, 0.0f, 0.0f, 0.0f);
    assert(gpioValue[47] == 1U && gpioValue[48] == 1U && pwmOutputEnabled == 0U);
    PwmOutput_Update(true, 0.0f, 0.0f, 0.0f);
    assert(pwmOutputEnabled == 0U);
    PwmOutput_Update(true, 0.0f, 0.0f, 0.0f);
    assert(pwmOutputEnabled == 1U);
    puts("PASS three-level duties, EPWM5/6 C phase, shadow priming, buffer ordering, stop and unused EPWM7");
}

static void PlantStep(float *current, float *voltage, float drive, float resistance, float h)
{
    float i = *current, v = *voltage;
    float a1 = (drive - v - 0.0001f * i) / 0.002f;
    float b1 = (i - v / resistance) / 0.000012f;
    float a2 = (drive - (v + h * b1 * 0.5f) - 0.0001f * (i + h * a1 * 0.5f)) / 0.002f;
    float b2 = (i + h * a1 * 0.5f - (v + h * b1 * 0.5f) / resistance) / 0.000012f;
    float a3 = (drive - (v + h * b2 * 0.5f) - 0.0001f * (i + h * a2 * 0.5f)) / 0.002f;
    float b3 = (i + h * a2 * 0.5f - (v + h * b2 * 0.5f) / resistance) / 0.000012f;
    float a4 = (drive - (v + h * b3) - 0.0001f * (i + h * a3)) / 0.002f;
    float b4 = (i + h * a3 - (v + h * b3) / resistance) / 0.000012f;
    *current += h * (a1 + 2.0f * a2 + 2.0f * a3 + a4) / 6.0f;
    *voltage += h * (b1 + 2.0f * b2 + 2.0f * b3 + b4) / 6.0f;
}

static void TestClosedLoopPlant(float reference)
{
    unsigned k, sub, samples = 0;
    float ia = 0.0f, ib = 0.0f, va = 0.0f, vb = 0.0f;
    float driveA = 0.0f, driveB = 0.0f;
    float peakError = 0.0f;
    double sumSquares = 0.0;
    Reset();
    Vd_ref = reference;
    offgridEnable = 1U;
    for(k = 0; k < 35000; k++)
    {
        float resistance = (k < 20000) ? 50.0f : 12.0f;
        float nextDriveA, nextDriveB;
        SetAbc(va, vb, &Va_cap, &Vb_cap, &Vc_cap);
        SetAbc(ia, ib, &Ia_inv, &Ib_inv, &Ic_inv);
        SetAbc(va / resistance, vb / resistance, &Ia_filter, &Ib_filter, &Ic_filter);
        InnerLoop_Update();
        nextDriveA = VaRef * Vdc * 0.5f;
        nextDriveB = (VbRef - VcRef) * Vdc * 0.28867513459f;
        // One sample delay: the present command loads at the next PWM zero.
        for(sub = 0; sub < 20; sub++)
        {
            PlantStep(&ia, &va, driveA, resistance, CONTROL_TS / 20.0f);
            PlantStep(&ib, &vb, driveB, resistance, CONTROL_TS / 20.0f);
        }
        driveA = nextDriveA;
        driveB = nextDriveB;
        if(k >= 30000)
        {
            float error = fabsf(hypotf(va, vb) - Vd_ref);
            if(error > peakError) peakError = error;
            sumSquares += (double)va * va;
            samples++;
        }
    }
    printf("Plant: startup + 50-to-12 ohm step, phase RMS %.4f V, worst final amplitude error %.4f V\n", sqrt(sumSquares / samples), peakError);
    assert(peakError < Vd_ref * 0.03f);
    Near((float)sqrt(sumSquares / samples), Vd_ref * 0.70710678f, 3.0f);
}

static float AngleError(float a, float b)
{
    float x = a - b;
    while(x > 3.14159265359f) x -= TWO_PI;
    while(x < -3.14159265359f) x += TWO_PI;
    return x;
}

static void TestPresyncRules(void)
{
    unsigned i;
    float before;
    Reset();
    offgridEnable = 1U;
    PRESYNC_CTRL.enable = 1U;
    // Missing PCC must not interrupt island control or change the reference.
    GridPll_Update(0.0f, 0.0f, 0.0f);
    before = Vd_ref;
    InnerLoop_Update();
    assert(PRESYNC_CTRL.pll_ready == 0U && PRESYNC_CTRL.sync_ready == 0U);
    assert(PRESYNC_CTRL.omega_sync == 0.0f && Vd_ref == before);
    assert(offgridEnable == 1U && offgridRunCount > 0U);

    // Phase-wrap direction, bounded frequency correction, bumpless reference.
    gridPllValid = 1U;
    SPLL_GRID.d_p_decoupl_lpf = 155.56f;
    SPLL_GRID.q_p_decoupl_lpf = 0.0f;
    SPLL_GRID.fo = 50.0f;
    PRESYNC_CTRL.pll_wait_cnt_limit = 0U;
    grid_theta = TWO_PI - 0.02f;
    colse_loop_theta = 0.02f;
    Vd_cap = 20.0f; Vq_cap = 0.0f;
    before = colse_loop_theta;
    Presync_Calc(&PRESYNC_CTRL, CONTROL_TS);
    Near(PRESYNC_CTRL.theta_err, -0.04f, 0.00001f);
    assert(PRESYNC_CTRL.omega_sync < 0.0f && colse_loop_theta == before);
    Near(Vd_ref, 20.0f + 0.001f * (155.56f - 20.0f), 0.00001f);
    grid_theta = 3.0f;
    PRESYNC_CTRL.kp = 100.0f;
    Presync_Calc(&PRESYNC_CTRL, CONTROL_TS);
    Near(PRESYNC_CTRL.omega_sync, PRESYNC_CTRL.omega_sync_max, 0.00001f);

    // Readiness is consecutive and revalidated, not a latched close command.
    Presync_Init(&PRESYNC_CTRL);
    PRESYNC_CTRL.enable = 1U;
    PRESYNC_CTRL.pll_wait_cnt_limit = 0U;
    grid_theta = colse_loop_theta = 0.0f;
    Vd_cap = Vd_ref = 155.56f; Vq_cap = 0.0f;
    for(i = 0; i < 9U; i++) Presync_Calc(&PRESYNC_CTRL, CONTROL_TS);
    assert(PRESYNC_CTRL.sync_ready == 0U);
    Presync_Calc(&PRESYNC_CTRL, CONTROL_TS);
    assert(PRESYNC_CTRL.sync_ready == 1U);
    Vq_cap = 30.0f; // Oscillator alone is not sufficient if measured phase lags.
    Presync_Calc(&PRESYNC_CTRL, CONTROL_TS);
    assert(PRESYNC_CTRL.sync_ready == 0U);
    before = colse_loop_theta;
    gridPllValid = 0U;
    Presync_Calc(&PRESYNC_CTRL, CONTROL_TS);
    assert(PRESYNC_CTRL.omega_sync == 0.0f && PRESYNC_CTRL.pll_wait_cnt == 0U);
    assert(colse_loop_theta == before && offgridEnable == 1U);
    PRESYNC_CTRL.enable = 0U;
    before = Vd_ref;
    Presync_Calc(&PRESYNC_CTRL, CONTROL_TS);
    assert(Vd_ref == before);
    // Every entry waits again, and stopping clears compensation without a trip.
    PRESYNC_CTRL.enable = 1U;
    gridPllValid = 1U;
    PRESYNC_CTRL.pll_wait_cnt_limit = 3U;
    for(i = 0; i < 3U; i++) Presync_Calc(&PRESYNC_CTRL, CONTROL_TS);
    assert(PRESYNC_CTRL.pll_ready == 0U);
    Presync_Calc(&PRESYNC_CTRL, CONTROL_TS);
    assert(PRESYNC_CTRL.pll_ready == 1U);
    offgridEnable = 0U;
    InnerLoop_Update();
    assert(PRESYNC_CTRL.pll_ready == 0U && PRESYNC_CTRL.omega_sync == 0.0f);
    puts("PASS presync no-PCC fallback, phase wrap, PI bounds, measured phase and readiness reset");
}

static void TestPresyncTracking(float frequency)
{
    unsigned k, readyCount = 0U;
    float theta = 1.2f;
    Reset();
    offgridEnable = 1U;
    Vd_ref = 120.0f;
    PRESYNC_CTRL.enable = 1U;
    // Actual migrated PLL and presync, ideal settled voltage inner loop.
    // This isolates synchronization from an unvalidated HIL power-stage model.
    for(k = 0; k < 120000U; k++)
    {
        float oldTheta = colse_loop_theta;
        float sine = sinf(theta), cosine = cosf(theta);
        SetAbc(155.56f * cosine, 155.56f * sine, &PCC_ua, &PCC_ub, &PCC_uc);
        SetAbc(Vd_ref * cosf(oldTheta), Vd_ref * sinf(oldTheta), &Va_cap, &Vb_cap, &Vc_cap);
        GridPll_Update(PCC_ua, PCC_ub, PCC_uc);
        InnerLoop_Update();
        PwmOutput_Update(true, VaRef, VbRef, VcRef);
        Near(AngleError(colse_loop_theta, oldTheta), omega * CONTROL_TS, 0.00001f);
        assert(fabsf(PRESYNC_CTRL.omega_sync) <= PRESYNC_CTRL.omega_sync_max + 0.0001f);
        theta += TWO_PI * frequency * CONTROL_TS;
        if(theta >= TWO_PI) theta -= TWO_PI;
        if(k > 110000U && PRESYNC_CTRL.sync_ready) readyCount++;
    }
    printf("Presync %.1f Hz: PLL %.5f Hz, output %.5f Hz, phase %.6f rad, voltage %.4f V, ready %u/9999\n", frequency, SPLL_GRID.fo, omega / TWO_PI, PRESYNC_CTRL.theta_err, Vd_ref, readyCount);
    Near(SPLL_GRID.fo, frequency, 0.02f);
    Near(omega / TWO_PI, frequency, 0.02f);
    assert(fabsf(PRESYNC_CTRL.theta_err) < 0.01f && readyCount > 9900U);
    Near(Vd_ref, 155.56f, 0.02f);
    assert(gpioValue[21] == 0U);
    // Remove PCC without stopping PWM; then restore it and reacquire.
    GridPll_Update(0.0f, 0.0f, 0.0f);
    InnerLoop_Update();
    PwmOutput_Update(true, VaRef, VbRef, VcRef);
    assert(PRESYNC_CTRL.sync_ready == 0U && PRESYNC_CTRL.omega_sync == 0.0f);
    assert(pwmBufferEnabled == 1U && gpioValue[21] == 0U);
    // Continue the grid angle through a 400 ms dropout and reacquire.
    for(k = 0; k < 100000U; k++)
    {
        float oldTheta = colse_loop_theta;
        SetAbc(Vd_ref * cosf(oldTheta), Vd_ref * sinf(oldTheta), &Va_cap, &Vb_cap, &Vc_cap);
        if(k < 4000U) GridPll_Update(0.0f, 0.0f, 0.0f);
        else
        {
            SetAbc(155.56f * cosf(theta), 155.56f * sinf(theta), &PCC_ua, &PCC_ub, &PCC_uc);
            GridPll_Update(PCC_ua, PCC_ub, PCC_uc);
        }
        InnerLoop_Update();
        PwmOutput_Update(true, VaRef, VbRef, VcRef);
        if(k < 4000U) assert(PRESYNC_CTRL.sync_ready == 0U);
        theta += TWO_PI * frequency * CONTROL_TS;
        if(theta >= TWO_PI) theta -= TWO_PI;
    }
    printf("Recovery %.1f: PLL=%g Hz, output=%g Hz, phase=%g rad, ready=%u\n", frequency, SPLL_GRID.fo, omega / TWO_PI, PRESYNC_CTRL.theta_err, PRESYNC_CTRL.sync_ready);
    assert(PRESYNC_CTRL.sync_ready == 1U && gpioValue[21] == 0U);
    Near(omega / TWO_PI, frequency, 0.02f);
    printf("PASS %.1f Hz PCC dropout/reacquisition; breaker remains open\n", frequency);
    PRESYNC_CTRL.enable = 0U;
    InnerLoop_Update();
    Near(omega, TWO_PI * f_ref, 0.0001f);
}

static void TestVsgPowerUnits(void)
{
    float expected;
    Reset();
    Near(SBase, 5000.0f, 0.0f);
    Vd_cap = 100.0f; Vq_cap = 20.0f;
    Id_filter = 10.0f; Iq_filter = -2.0f;
    VSG_MeasurePower();
    Near(Pe, 1440.0f, 0.001f);
    Near(Qe, 600.0f, 0.001f);
    Near(Pe_pu, 0.288f, 0.000001f);
    Near(Qe_pu, 0.12f, 0.000001f);
    VSG_CTRL.p_ref = 0.1f;
    expected = 0.1f * CONTROL_TS / 5.0f;
    VSG_PowerLoop(&VSG_CTRL, 0.0f, 0.0f, CONTROL_TS);
    Near(VSG_CTRL.omega_m_pu, expected, 0.00000001f);
    Near(VSG_CTRL.omega_m, expected * VSG_CTRL.omega0, 0.000001f);
    VSG_CTRL.p_ref = 1000.0f;
    VSG_PowerLoop(&VSG_CTRL, 0.0f, 0.0f, 1.0f);
    Near(VSG_CTRL.omega_m_pu, VSG_CTRL.omega_m_max / VSG_CTRL.omega0, 0.000001f);
    VSG_CTRL.p_ref = -1000.0f;
    VSG_PowerLoop(&VSG_CTRL, 0.0f, 0.0f, 1.0f);
    Near(VSG_CTRL.omega_m_pu, VSG_CTRL.omega_m_min / VSG_CTRL.omega0, 0.000001f);
    VSG_CTRL.q_ref = 0.2f;
    Qe_pu = 0.1f;
    VSG_EnterGrid(&VSG_CTRL, 2.0f, -TWO_PI, 150.0f);
    VSG_CTRL.p_ref = 0.0f;
    VSG_PowerLoop(&VSG_CTRL, 0.0f, 0.1f, CONTROL_TS);
    Near(VSG_CTRL.v_ref, 150.0f, 0.00001f);
    VSG_PowerLoop(&VSG_CTRL, 0.0f, 0.0f, CONTROL_TS);
    Near(VSG_CTRL.v_delta_pu, 0.005f, 0.000001f);
    Near(VSG_CTRL.v_delta, 0.005f * 155.56f, 0.00001f);
    puts("PASS 5000 W power normalization, pu swing equation/limits and bumpless normalized Q-V PI");
}

static void TestGridCommandInterlock(void)
{
    unsigned i;
    Reset();
    offgridEnable = 1U;
    INV_CTRL.grid_connect_cmd = 1U;
    InnerLoop_Update();
    assert(INV_CTRL.grid_connect_cmd == 0U && INV_CTRL.grid_connect_rejected == 1U);
    assert(INV_CTRL.state != INV_GRID_CONNECTED && gpioValue[21] == 0U);
    // Stale sync_ready is recalculated and cannot close after PCC disappears.
    PRESYNC_CTRL.enable = PRESYNC_CTRL.sync_ready = 1U;
    gridPllValid = 0U;
    INV_CTRL.grid_connect_cmd = 1U;
    InnerLoop_Update();
    assert(INV_CTRL.grid_connect_cmd == 0U && INV_CTRL.state != INV_GRID_CONNECTED);
    // A lone phase-A match does not bypass B/C voltage mismatch.
    gridPllValid = 1U;
    PRESYNC_CTRL.enable = PRESYNC_CTRL.sync_ready = 1U;
    PCC_ua = Va_cap = 100.0f;
    PCC_ub = 30.0f; Vb_cap = -50.0f;
    PCC_uc = Vc_cap = -50.0f;
    INV_CTRL.grid_connect_cmd = 1U;
    InvState_Step(&INV_CTRL);
    assert(INV_CTRL.grid_zero_cross_ok == 0U && INV_CTRL.grid_connect_cmd == 0U);
    for(i = 0; i < 20U; i++) InvState_Step(&INV_CTRL);
    assert(INV_CTRL.state != INV_GRID_CONNECTED);
    puts("PASS premature/stale commands rejected, all-three-phase mismatch check and no delayed automatic closure");
}

static void SetGridModel(float thetaGrid, float reactance, bool connected)
{
    float a = Vd_ref * cosf(colse_loop_theta);
    float b = Vd_ref * sinf(colse_loop_theta);
    float ga = 155.56f * cosf(thetaGrid), gb = 155.56f * sinf(thetaGrid);
    float ia = connected ? (b - gb) / reactance : 0.0f;
    float ib = connected ? -(a - ga) / reactance : 0.0f;
    SetAbc(a, b, &Va_cap, &Vb_cap, &Vc_cap);
    SetAbc(ga, gb, &PCC_ua, &PCC_ub, &PCC_uc);
    SetAbc(ia, ib, &Ia_filter, &Ib_filter, &Ic_filter);
    SetAbc(ia - omega * Cf * b, ib + omega * Cf * a, &Ia_inv, &Ib_inv, &Ic_inv);
}

static void TestGridVsgSwitch(float gridFrequency)
{
    unsigned k;
    float thetaGrid = 1.0f;
    float thetaBefore, voltageBefore, heldCorrection, frequencyBefore;
    Reset();
    offgridEnable = 1U;
    Vd_ref = 120.0f;
    PRESYNC_CTRL.enable = 1U;
    for(k = 0; k < 120000U; k++)
    {
        SetGridModel(thetaGrid, 1.0f, false);
        GridPll_Update(PCC_ua, PCC_ub, PCC_uc);
        InnerLoop_Update();
        PwmOutput_Update(true, VaRef, VbRef, VcRef);
        assert(gpioValue[21] == 0U); // Readiness alone never closes the breaker.
        thetaGrid += TWO_PI * gridFrequency * CONTROL_TS;
        if(thetaGrid >= TWO_PI) thetaGrid -= TWO_PI;
    }
    assert(INV_CTRL.state == INV_GRID_READY);
    assert(PRESYNC_CTRL.sync_ready == 1U);
    thetaBefore = colse_loop_theta;
    voltageBefore = Vd_ref;
    frequencyBefore = omega / TWO_PI;
    PI_UD.ui = 0.123f;
    INV_CTRL.grid_connect_cmd = 1U;
    SetGridModel(thetaGrid, 1.0f, false);
    GridPll_Update(PCC_ua, PCC_ub, PCC_uc);
    InnerLoop_Update();
    heldCorrection = VSG_CTRL.omega_sync;
    assert(INV_CTRL.state == INV_GRID_CONNECTED && INV_CTRL.grid_connect_rejected == 0U);
    assert(PRESYNC_CTRL.enable == 0U && PRESYNC_CTRL.omega_sync == 0.0f);
    Near(VSG_CTRL.omega_m, 0.0f, 0.0f);
    Near(AngleError(colse_loop_theta, thetaBefore), omega * CONTROL_TS, 0.00001f);
    Near(omega / TWO_PI, frequencyBefore, 0.001f);
    Near(Vd_ref, voltageBefore, 0.0001f);
    assert(fabsf(PI_UD.ui) > 0.1f); // The transfer did not reset inner-loop PIs.
    PwmOutput_Update(true, VaRef, VbRef, VcRef);
    assert(gpioValue[21] == 1U);
    thetaGrid += TWO_PI * gridFrequency * CONTROL_TS;
    if(thetaGrid >= TWO_PI) thetaGrid -= TWO_PI;

    // Ideal voltage-source / reactance grid tests actual migrated VSG dynamics.
    for(k = 0; k < 60000U; k++)
    {
        VSG_CTRL.p_ref = (k < 30000U) ? 0.1f : 0.2f;
        SetGridModel(thetaGrid, 1.0f, true);
        GridPll_Update(PCC_ua, PCC_ub, PCC_uc);
        thetaBefore = colse_loop_theta;
        InnerLoop_Update();
        PwmOutput_Update(true, VaRef, VbRef, VcRef);
        Near(AngleError(colse_loop_theta, thetaBefore), omega * CONTROL_TS, 0.00001f);
        Near(VSG_CTRL.omega_sync, heldCorrection, 0.0f); // Frozen, no PLL steering.
        assert(INV_CTRL.state == INV_GRID_CONNECTED && gpioValue[21] == 1U);
        if(k == 29999U) Near(Pe_pu, 0.1f, 0.003f);
        thetaGrid += TWO_PI * gridFrequency * CONTROL_TS;
        if(thetaGrid >= TWO_PI) thetaGrid -= TWO_PI;
    }
    Near(Pe_pu, 0.2f, 0.003f);
    Near(Pe, 1000.0f, 15.0f);
    Near(omega / TWO_PI, gridFrequency, 0.02f);
    printf("Grid %.1f Hz: continuous VF->VSG, captured correction %.6f rad/s, P %.3f W, Q %.3f var\n", gridFrequency, heldCorrection, Pe, Qe);

    // Manual open retains angle/frequency/voltage and does not auto-presync.
    thetaBefore = colse_loop_theta;
    frequencyBefore = omega / TWO_PI;
    voltageBefore = Vd_ref;
    INV_CTRL.grid_connect_cmd = 0U;
    InnerLoop_Update();
    PwmOutput_Update(true, VaRef, VbRef, VcRef);
    assert(INV_CTRL.state == INV_OFFGRID_VF && gpioValue[21] == 0U);
    Near(omega / TWO_PI, frequencyBefore, 0.0001f);
    Near(AngleError(colse_loop_theta, thetaBefore), omega * CONTROL_TS, 0.00001f);
    Near(Vd_ref, voltageBefore, 0.0001f);
    assert(PRESYNC_CTRL.enable == 0U);
    offgridEnable = 0U;
    INV_CTRL.grid_connect_cmd = 1U;
    InnerLoop_Update();
    PwmOutput_Update(false, VaRef, VbRef, VcRef);
    assert(INV_CTRL.state == INV_STANDBY && INV_CTRL.grid_connect_cmd == 0U);
    assert(gpioValue[21] == 0U && pwmBufferEnabled == 0U);
    puts("PASS manual-open VF continuity, master stop opens breaker, no automatic reconnection");
}

int main(void)
{
    TestAdc();
    TestControl();
    TestPwm();
    TestVsgPowerUnits();
    TestGridCommandInterlock();
    TestGridVsgSwitch(49.0f);
    TestGridVsgSwitch(50.0f);
    TestGridVsgSwitch(51.0f);
    TestPresyncRules();
    TestPresyncTracking(49.0f);
    TestPresyncTracking(50.0f);
    TestPresyncTracking(51.0f);
    TestClosedLoopPlant(20.0f);
    TestClosedLoopPlant(155.56f);
    puts("ALL BASIC OFFGRID HOST TESTS PASSED");
    return 0;
}
