#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stubs/driverlib.h"
#include "app/control/inner_loop.h"

#include "app/control/feedback_dq.h"
#include "app/control/three_level_modulation.h"
#include "app/control/pwm_output.h"
#include "app/measurement/adc_measurement.h"

// Real measurement/controller code, with ADC and PWM registers simulated below.
static bool adcFlags[5], adcOverflows[5];
static uint16_t adcResults[5][4];
static unsigned adcResultReads, adcFlagClears;
bool ADC_getInterruptStatus(uint32_t base, unsigned interrupt) { (void)interrupt; return adcFlags[base - 10U]; }
bool ADC_getInterruptOverflowStatus(uint32_t base, unsigned interrupt) { (void)interrupt; return adcOverflows[base - 10U]; }
void ADC_clearInterruptStatus(uint32_t base, unsigned interrupt)
{
    (void)interrupt;
    assert(adcResultReads == 0U || adcResultReads == 16U);
    adcFlags[base - 10U] = false;
    adcFlagClears++;
}
void ADC_clearInterruptOverflowStatus(uint32_t base, unsigned interrupt) { (void)interrupt; adcOverflows[base - 10U] = false; }
uint16_t ADC_readResult(uint32_t base, unsigned soc)
{
    assert(adcFlagClears == 0U); // Do not clear flags before the full result copy.
    adcResultReads++;
    return adcResults[base - 20U][soc];
}

typedef struct { uint16_t period, compare[2], force, flags, counter, direction; } FakePwm;
static FakePwm hw[8];
static uint32_t gpioValue[64];
void GPIO_writePin(uint32_t pin, uint32_t value)
{
    unsigned i;
    assert(pin < 64U);
    if(pin == 21U) assert(value == 1U); // No breaker closure in this version.
    if((pin == 47U || pin == 48U) && value == 0U)
    {
        // Both buffers may only be enabled after every used bridge is released.
        for(i = 1U; i <= 6U; i++) assert(hw[i].flags == 0U);
        assert(hw[7].flags & EPWM_TZ_FLAG_OST);
    }
    gpioValue[pin] = value;
}
void EPWM_setTripZoneAction(uint32_t b, unsigned e, unsigned a) { (void)b; (void)e; assert(a == EPWM_TZ_ACTION_LOW); }
void EPWM_forceTripZoneEvent(uint32_t b, uint16_t e) { assert(gpioValue[47] == 1U && gpioValue[48] == 1U); hw[b].flags |= e; }
uint16_t EPWM_getTimeBasePeriod(uint32_t b) { return hw[b].period; }
void EPWM_setCounterCompareShadowLoadMode(uint32_t b, unsigned c, unsigned m) { (void)b; (void)c; assert(m == 0U); }
void EPWM_setActionQualifierContSWForceShadowMode(uint32_t b, unsigned m) { (void)b; assert(m == 0U); }
void EPWM_setRisingEdgeDeadBandDelayInput(uint32_t b, uint16_t i) { (void)b; assert(i == 0U); }
void EPWM_setFallingEdgeDeadBandDelayInput(uint32_t b, uint16_t i) { (void)b; assert(i == 0U); }
void EPWM_setCounterCompareValue(uint32_t b, unsigned c, uint16_t v) { hw[b].compare[c] = v; }
void EPWM_setActionQualifierContSWForceAction(uint32_t b, unsigned o, EPWM_ActionQualifierSWOutput f) { assert(o == 0U); hw[b].force = (uint16_t)f; }
uint16_t EPWM_getTripZoneFlagStatus(uint32_t b) { return hw[b].flags; }
uint16_t EPWM_getTimeBaseCounterValue(uint32_t b) { return hw[b].counter; }
uint16_t EPWM_getTimeBaseCounterDirection(uint32_t b) { return hw[b].direction; }
void EPWM_clearTripZoneFlag(uint32_t b, uint16_t f) { assert(gpioValue[47] == 1U && gpioValue[48] == 1U); hw[b].flags &= (uint16_t)~f; }

static void Near(float actual, float expected, float tolerance)
{
    if(!(fabsf(actual - expected) <= tolerance))
    {
        fprintf(stderr, "Expected %.8g, got %.8g (tolerance %.8g)\n", expected, actual, tolerance);
        exit(1);
    }
}

static void SetAbc(float alpha, float beta, volatile float *a, volatile float *b, volatile float *c)
{
    *a = alpha;
    *b = -0.5f * alpha + 0.86602540378f * beta;
    *c = -0.5f * alpha - 0.86602540378f * beta;
}

#include "app/measurement/adc_calibration.h"

static void Reset(void)
{
    memset(hw, 0, sizeof(hw));
    memset(gpioValue, 0, sizeof(gpioValue));
    Va_cap = Vb_cap = Vc_cap = 0.0f;
    Ia_inv = Ib_inv = Ic_inv = 0.0f;
    Ia_filter = Ib_filter = Ic_filter = 0.0f;
    colse_loop_theta = 0.0f;
    Vd_ref = 20.0f; Vq_ref = 0.0f;
    f_ref = 50.0f; Vdc = 400.0f; Lf = 0.002f; Cf = 0.000012f;
    Kpu = 0.0053314595f; Kiu = 1.1843525f;
    Kpi = 6.2831853f; Kii = 0.31415927f;
    U_UpLimit = 30.0f; I_UpLimit = 100.0f;
    FeedbackDq_Init();
    CloseLoop_Init();
    PwmOutput_Init();
}

static void TestAdc(void)
{
    unsigned i, j;
    volatile float *physical[12] = { &Va_cap, &PCC_ua, &Ia_inv, &Vb_cap, &PCC_ub, &Ib_inv, &Vc_cap, &PCC_uc, &Ic_inv, &Ia_filter, &Ib_filter, &Ic_filter };
    const unsigned banks[12] = {0,0,0,1,1,1,2,2,3,3,4,4};
    const unsigned socs[12] = {0,1,3,1,2,3,0,1,1,2,0,1};
    Reset();
    for(i = 0; i < 5; i++)
    {
        adcFlags[i] = false;
        adcOverflows[i] = true; // Housekeeping must not suppress sampling.
        for(j = 0; j < 4; j++) adcResults[i][j] = (uint16_t)(2000 + i * 20 + j);
    }
    adcResultReads = adcFlagClears = 0U;
    AdcMeasurement_Acquire();
    assert(adcResultReads == 16U && adcFlagClears == 5U);
    for(i = 0; i < 12; i++)
    {
        float scale = (i == 0 || i == 1 || i == 3 || i == 4 || i == 6 || i == 7) ? VOL_SCALE : CUR_SCALE;
        Near(*physical[i], ((float)adcResults[banks[i]][socs[i]] - adcZeroOffset[i]) * scale, 0.0001f);
    }
    for(i = 0; i < 5; i++) assert(!adcFlags[i] && !adcOverflows[i]);
    puts("PASS all twelve fixed-offset conversions; no ready/overflow gating");
}

static void TestControl(void)
{
    Reset();
    PI_UD.ui = 2.0f;
    InnerLoop_Update();
    assert(PI_UD.ui == 0.0f && VaRef == 0.0f);
    offgridEnable = 1U;
    Kpu = Kiu = Kpi = Kii = 0.0f;
    SetAbc(10.0f, 2.0f, &Va_cap, &Vb_cap, &Vc_cap);
    SetAbc(3.0f, 4.0f, &Ia_inv, &Ib_inv, &Ic_inv);
    SetAbc(1.0f, 0.5f, &Ia_filter, &Ib_filter, &Ic_filter);
    InnerLoop_Update();
    Near(Vd_cap, 10.0f, 0.0001f);
    Near(Vq_cap, 2.0f, 0.0001f);
    Near(id_ref, 1.0f - omega * Cf * 2.0f, 0.0001f);
    Near(iq_ref, 0.5f + omega * Cf * 10.0f, 0.0001f);
    Near(ud_ref, (10.0f - omega * Lf * 4.0f) * 2.0f / Vdc, 0.0001f);
    Near(uq_ref, (2.0f + omega * Lf * 3.0f) * 2.0f / Vdc, 0.0001f);
    Ia_inv = 50.0f; // Requested basic controller has no overcurrent latch.
    InnerLoop_Update();
    assert(offgridEnable == 1U && isfinite(VaRef));
    offgridEnable = 0U;
    InnerLoop_Update();
    assert(colse_loop_theta == 0.0f && id_ref == 0.0f && VaRef == 0.0f);
    puts("PASS dq, PI reset, cross coupling, normalization and stop/restart");
}

static void TestPwm(void)
{
    unsigned i;
    ThreeLevelDuty duty;
    Reset();
    for(i = 0; i <= 200; i++)
    {
        float m = (float)i * 0.01f - 1.0f;
        ThreeLevelModulation_Map(m, &duty);
        Near(duty.upper - (1.0f - duty.lower), m, 0.0001f);
    }
    PwmOutput_Update(true, 0.2f, -0.3f, 0.4f);
    assert(pwmBufferEnabled == 0U);
    PwmOutput_Update(true, 0.2f, -0.3f, 0.4f);
    assert(pwmOutputEnabled == 1U && gpioValue[47] == 0U && gpioValue[48] == 0U);
    assert(hw[1].compare[0] == 1500U && hw[5].compare[0] == 3000U);
    assert(hw[2].force == EPWM_AQ_SW_OUTPUT_HIGH && hw[3].force == EPWM_AQ_SW_OUTPUT_LOW);
    for(i = 1; i <= 6; i++) assert(hw[i].flags == 0U);
    assert(hw[7].flags & EPWM_TZ_FLAG_OST);
    assert(gpioValue[21] == 1U);
    PwmOutput_Update(false, 0.0f, 0.0f, 0.0f);
    assert(gpioValue[47] == 1U && gpioValue[48] == 1U && pwmOutputEnabled == 0U);
    PwmOutput_Update(true, 0.0f, 0.0f, 0.0f);
    assert(pwmOutputEnabled == 0U);
    PwmOutput_Update(true, 0.0f, 0.0f, 0.0f);
    assert(pwmOutputEnabled == 1U);
    puts("PASS three-level duties, EPWM5/6 C phase, shadow priming, buffer ordering, stop and unused EPWM7");
}

static void PlantStep(float *current, float *voltage, float drive, float resistance, float h)
{
    float i = *current, v = *voltage;
    float a1 = (drive - v - 0.0001f * i) / 0.002f;
    float b1 = (i - v / resistance) / 0.000012f;
    float a2 = (drive - (v + h * b1 * 0.5f) - 0.0001f * (i + h * a1 * 0.5f)) / 0.002f;
    float b2 = (i + h * a1 * 0.5f - (v + h * b1 * 0.5f) / resistance) / 0.000012f;
    float a3 = (drive - (v + h * b2 * 0.5f) - 0.0001f * (i + h * a2 * 0.5f)) / 0.002f;
    float b3 = (i + h * a2 * 0.5f - (v + h * b2 * 0.5f) / resistance) / 0.000012f;
    float a4 = (drive - (v + h * b3) - 0.0001f * (i + h * a3)) / 0.002f;
    float b4 = (i + h * a3 - (v + h * b3) / resistance) / 0.000012f;
    *current += h * (a1 + 2.0f * a2 + 2.0f * a3 + a4) / 6.0f;
    *voltage += h * (b1 + 2.0f * b2 + 2.0f * b3 + b4) / 6.0f;
}

static void TestClosedLoopPlant(float reference)
{
    unsigned k, sub, samples = 0;
    float ia = 0.0f, ib = 0.0f, va = 0.0f, vb = 0.0f;
    float driveA = 0.0f, driveB = 0.0f;
    float peakError = 0.0f;
    double sumSquares = 0.0;
    Reset();
    Vd_ref = reference;
    offgridEnable = 1U;
    for(k = 0; k < 35000; k++)
    {
        float resistance = (k < 20000) ? 50.0f : 12.0f;
        float nextDriveA, nextDriveB;
        SetAbc(va, vb, &Va_cap, &Vb_cap, &Vc_cap);
        SetAbc(ia, ib, &Ia_inv, &Ib_inv, &Ic_inv);
        SetAbc(va / resistance, vb / resistance, &Ia_filter, &Ib_filter, &Ic_filter);
        InnerLoop_Update();
        nextDriveA = VaRef * Vdc * 0.5f;
        nextDriveB = (VbRef - VcRef) * Vdc * 0.28867513459f;
        // One sample delay: the present command loads at the next PWM zero.
        for(sub = 0; sub < 20; sub++)
        {
            PlantStep(&ia, &va, driveA, resistance, CONTROL_TS / 20.0f);
            PlantStep(&ib, &vb, driveB, resistance, CONTROL_TS / 20.0f);
        }
        driveA = nextDriveA;
        driveB = nextDriveB;
        if(k >= 30000)
        {
            float error = fabsf(hypotf(va, vb) - Vd_ref);
            if(error > peakError) peakError = error;
            sumSquares += (double)va * va;
            samples++;
        }
    }
    printf("Plant: startup + 50-to-12 ohm step, phase RMS %.4f V, worst final amplitude error %.4f V\n", sqrt(sumSquares / samples), peakError);
    assert(peakError < Vd_ref * 0.03f);
    Near((float)sqrt(sumSquares / samples), Vd_ref * 0.70710678f, 3.0f);
}

int main(void)
{
    TestAdc();
    TestControl();
    TestPwm();
    TestClosedLoopPlant(20.0f);
    TestClosedLoopPlant(155.56f);
    puts("ALL BASIC OFFGRID HOST TESTS PASSED");
    return 0;
}
