#ifndef ADC_CALIBRATION_H_
#define ADC_CALIBRATION_H_

// Fixed offsets measured with the platform at zero physical input.
// Valid for the internal 3.3 V ADC range and the current platform gains.
#define ADC_ZERO_CHANNELS  12U

static const float adcZeroOffset[ADC_ZERO_CHANNELS] =
{
    1854.67798f, // [0]  ua_cap
    1856.20679f, // [1]  PCC_ua
    1854.26489f, // [2]  ia_inv
    1854.18359f, // [3]  ub_cap
    1855.58789f, // [4]  PCC_ub
    1856.92847f, // [5]  ib_inv
    1855.67401f, // [6]  uc_cap
    1854.95142f, // [7]  PCC_uc
    1855.92847f, // [8]  ic_inv
    1856.62915f, // [9]  ia_filter
    1857.75366f, // [10] ib_filter
    1856.86426f  // [11] ic_filter
};

#define VOL_SCALE \
    (3.3f / 4096.0f * (20.0f / 3.0f) \
     / 50.0f * 1000.0f * 1.003f)
//1.0074
#define CUR_SCALE \
    (3.3f / 4096.0f * (20.0f / 3.0f) \
     / 200.0f * 1000.0f * 1.002f)

#endif
